export const environment = {
  production: true,
  API_INSS_SERVER_NAME: 'http://10.203.146.23',
  API_PESSOA_SERVER_NAME: 'http://10.203.146.22',
  API_FILA: 'http://10.203.146.23:8093',
  API_BENEFICIO: 'http://10.0.146.29/',
  API_CONTA_CORRENTE: 'http://10.203.146.23:8080',
  PLUGINS: {
    TECLADO_VIRTUAL: {
      name: 'TecladoVirtual',
      VERSAO: 'v4.0',
      PARAMETROS: [
        '8083', // PORTA
        '61033106000186', // CNPJ
        '626064', // ID_CARTAO
        'OP_PWD_4' // OPERACAO
      ]
    }
  }
};
