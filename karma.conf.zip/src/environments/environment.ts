export const environment = {
    production: false,
    API_INSS_SERVER_NAME  : 'http://localhost:59922' /*'http://localhost:59922/'*/,
    API_CONTA_CORRENTE : '',
    API_PESSOA_SERVER_NAME: 'https://api-corp-cuc-d.local/',
    API_FILA              : 'https://nfc-fila-api-d.local:441/',
    API_BENEFICIO         : 'http://10.0.146.29/',
    PLUGINS               : {
        TECLADO_VIRTUAL: {
            name      : 'TecladoVirtual',
            VERSAO    : 'v4.0',
            PARAMETROS: [
                '8083', // PORTA
                '61033106000186', // CNPJ
                '626064', // ID_CARTAO
                'OP_PWD_4' // OPERACAO
            ]
        }
    }
};
