import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BeneficioInssMainComponent } from './modulos/beneficio/components/beneficio-inss-main/beneficio-inss-main.component';

import { TratamentoComponent } from './modulos/filas/tratamento/tratamento.component';
import { FichaCadastralComponent } from './shared/modulos/ficha-cadastral/components/ficha-cadastral/ficha-cadastral.component';
import { CadastroComponent } from './shared/modulos/cadastro/cadastro.component';
import { ConsultaHistoricoComponent } from './shared/modulos/consulta-historico/consulta-historico.component';
import { filasAnaliseRoutes } from './modulos/filas/filas-analise.module';
import { contaCorrenteRoutes } from './modulos/conta-corrente/conta-corrente.module';
import { TreeComponent } from './modulos/testes/tree/tree.component';

import {DigitalizacaoComponent} from './modulos/digitalizacao/components/digitalizacao/digitalizacao.component';
import { BeneficioComponent } from './modulos/beneficio/pages/beneficio/beneficio.component';

const routes: Routes = [
  { path: 'beneficio-inss-main', component: BeneficioInssMainComponent, data: { title: 'Beneficio INSS'} },
  { path: 'beneficio', component: BeneficioComponent, data: { title: 'Beneficio INSS'} },
  { path: 'filas-analise', children: filasAnaliseRoutes },
  { path: 'conta-corrente', children: contaCorrenteRoutes },
  { path: 'filas-tratamento', component: TratamentoComponent, data: { title: 'Filas Tratamento' } },
  { path: 'ficha-cadastral', component: FichaCadastralComponent, data: { title: 'Filas Tratamento' } },
  { path: 'cadastro', component: CadastroComponent, data: { title: 'Cadastro' } },
  { path: 'consulta-historico-analise', component: ConsultaHistoricoComponent, data: { title: 'Consulta Historico Analise'}},
  { path: 'digitalizacao/:parametro', component: DigitalizacaoComponent, data: { title: 'Digitalizacao' } },
  { path : '', redirectTo: '/beneficio', pathMatch: 'full' },
  { path : '**', redirectTo: '/beneficio', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
