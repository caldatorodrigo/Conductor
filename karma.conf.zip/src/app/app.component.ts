import {
  Component,
  OnInit,
  ChangeDetectorRef,
  AfterViewChecked
} from '@angular/core';
import { AlertService } from './shared/services/alert.service';
import { Observable, of } from 'rxjs';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, AfterViewChecked {
  title = 'nfc-conta-beneficio';
  loading$: Observable<boolean>;


  constructor(
    private alertService: AlertService,
    private cdRef: ChangeDetectorRef,
  ) {
  }

  ngOnInit() {}

  ngAfterViewChecked() {
    this.loading$ = this.alertService.getLoading();
    this.cdRef.detectChanges();
  }
}
