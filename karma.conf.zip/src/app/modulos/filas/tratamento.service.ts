import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { TreeNode } from 'src/app/shared/models/tree-node';

const httpOptions = {
  headers: new HttpHeaders({'Content-Type': 'application/json'})
};

@Injectable({
  providedIn: 'root'
})
export class TratamentoService {

  constructor(private httpClient: HttpClient) { }

  getFilasTratamento() {
    return this.httpClient.get('./assets/fila-tratamento.json');;
  }

}
