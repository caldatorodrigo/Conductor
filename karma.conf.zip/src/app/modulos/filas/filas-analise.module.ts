import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { AnaliseComponent } from './components/analise/analise.component';
import { AnaliseBeneficiarioComponent } from './components/analise-beneficio/analise-beneficio.component';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule } from '@angular/forms';


export const filasAnaliseRoutes = [
  {
    path: '',
    component: AnaliseComponent,
    data: { title: 'Filas Analise' }
  },
  {
    path: 'beneficio/:tpFila/:codExterno',
    component: AnaliseBeneficiarioComponent,
    data: { title: 'Análise Beneficiário' }
  }
];

@NgModule({
  declarations: [
    AnaliseComponent,
    AnaliseBeneficiarioComponent
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    ReactiveFormsModule
  ],
  exports: [
    AnaliseComponent,
    AnaliseBeneficiarioComponent
  ],
  providers: []
})
export class FilasAnaliseModule {}
