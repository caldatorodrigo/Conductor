import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ITENS_FILAS_ANALISE } from './components/analise/example-data';
import { environment } from 'src/environments/environment';
import { Observable, throwError } from 'rxjs';
import { map, isEmpty, retry, catchError } from 'rxjs/operators';
import { isNullOrUndefined } from 'util';

@Injectable({
  providedIn: 'root'
})
export class FilasService {
  URL_FILA = 'api/Fila/v1';
  URL_FILA_ANALISE = '/api/FilaAnalise/v1';
  URL_TIPO_FILA = 'api/TpFila/v1';
  URL_COMPARA_DOC_FILA = 'api/FilaComparaDoc/v1';
  URL_MOTIVO_RECUSA = 'api/MotivoRecusa/v1';

  constructor(private httpClient: HttpClient) {}

  getUrl(url) {
    return this.httpClient.get<any>(url);
  }

  public getItemFila(url: string) {
    // return this.httpClient.get(url);
    return ITENS_FILAS_ANALISE;
  }

  acaoAnalise(url, data) {
    console.log(JSON.stringify(data));
    return this.httpClient.post<any>(url, data);
  }

  getFilaCentralizadora(): Observable<any> {
    return this.httpClient.get(
      `${environment.API_FILA}/${this.URL_FILA}/consultar-filacentralizadora`
    );
  }

  getMotivosRecusa(): Observable<any> {
    return this.httpClient.get(
      `${environment.API_FILA}/${this.URL_MOTIVO_RECUSA}/consultar`
    );
  }

  public dadosComparaDocByTpFila(tpFila){
    return this.httpClient.get<any>(
      `${environment.API_FILA}/${this.URL_COMPARA_DOC_FILA}/consultar-por-tipofila/${tpFila}`
    );
  }

  getFilaStatus(tpFila, codStatus): Promise<any> {
    return this.httpClient
      .get<any>(
        `${environment.API_FILA}/${this.URL_FILA}/consultar-por-tipofilastatus/${tpFila}/${codStatus}`
      )
      .pipe(map(res => (res.data ? res.data : [])))
      .toPromise();
  }

  getFilaPorTipo(url): Promise<any> {
    return this.httpClient
      .get<any>(url)
      .pipe(map(res => (res.data ? res.data : [])))
      .toPromise();
  }

  getHistoricoFilaAnalise(  dtIni: string,
                            dtFim: string,
                            cpf: string,
                            tipoFila: string ): Promise<any> {

    if ( !isNullOrUndefined(dtIni) && dtIni != '' &&
         !isNullOrUndefined(dtFim) && dtFim != '' &&
         !isNullOrUndefined(cpf) && cpf != '' &&
         !isNullOrUndefined(tipoFila) && tipoFila != '' ) {
      return this.getHistoricoFilaAnaliseTodosFiltros( dtIni, dtFim, cpf, tipoFila );
    }

    if ( !isNullOrUndefined(dtIni) && dtIni != '' &&
        !isNullOrUndefined(dtFim) && dtFim != '' ) {
      return this.getHistoricoFilaAnalisePorData(dtIni, dtFim);
    }

    if (!isNullOrUndefined(cpf) && cpf != '') {
      return this.getHistoricoFilaAnalisePorCpf(this.getDigitos(cpf));
    }

    if (!isNullOrUndefined(tipoFila) && tipoFila != '') {
      return this.getHistoricoFilaAnalisePorTipoFila(tipoFila);
    }
  }

  public getHistoricoFilaAnaliseTodosFiltros(
    dtIni: string,
    dtFim: string,
    cpf: string,
    tipoFila: string
  ): Promise<any> {
    return this.httpClient
      .get<any>(
        `${environment.API_FILA}/${this.URL_FILA}/consultarhistorico-todos/${dtIni}/${dtFim}/${cpf}/${tipoFila}`
      )
      .pipe(map(res => (res.data ? res.data : {})))
      .toPromise();
  }

  public getHistoricoFilaAnalisePorData(
    dtIni: string,
    dtFim: string
  ): Promise<any> {
    return this.httpClient
      .get<any>(
        `${environment.API_FILA}/${this.URL_FILA}/consultar-hist-por-data/${dtIni}/${dtFim}`
      )
      .pipe(map(res => (res.data ? res.data : {})))
      .toPromise();
  }

  public getHistoricoFilaAnalisePorCpf(cpf: string): Promise<any> {
    return this.httpClient
      .get<any>(
        `${environment.API_FILA}/${this.URL_FILA}/consultar-hist-por-cpf/${cpf}`
      )
      .pipe(map(res => (res.data ? res.data : {})))
      .toPromise();
  }

  public getHistoricoFilaAnalisePorTipoFila(tipoFila: string): Promise<any> {
    return this.httpClient
      .get<any>(
        `${environment.API_FILA}/${this.URL_FILA}/consultar-hist-por-tipofila/${tipoFila}`
      )
      .pipe(map(res => ( res.data ? res.data : [] ) ))
      .toPromise();
  }

  public getTiposFila(): Observable<any> {
    return this.httpClient
      .get(`${environment.API_FILA}/${this.URL_TIPO_FILA}/consultar-todos`)
      .pipe(retry(3));
  }

  getDigitos(value) {
    return value.replace(/\D/g, '');
  }

  public atualizarFilaAnalise(filaAnalise: any) {
    console.log(
      'atualizarFilaAnalise filaAnalise=' +
        JSON.stringify(filaAnalise)
    );
    this.httpClient
      .put(
        `${environment.API_FILA}/${this.URL_FILA_ANALISE}/atualizar`,
        filaAnalise
      )
      .subscribe(
        resp => {
          console.log(
            'respPost atualizarFilaAnalise=' +
              JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em atualizarFilaAnalise' + JSON.stringify(err)
          )
      );
  }

  public getHistoricoFilaAnalisePorCodigoExternoAndTipoFila(codigoExterno: string, tipoFila: string): Promise<any> {
    return this.httpClient
      .get<any>(
        `${environment.API_FILA}/${this.URL_FILA}/consultar-por-codexterno-tpfila/${codigoExterno}/${tipoFila}`
      )
      .pipe(map(res => ( res.data ? res.data : [] ) ))
      .toPromise();
  }

}
