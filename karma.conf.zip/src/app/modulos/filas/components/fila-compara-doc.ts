export const filaComparaDoc = [
  {
    codSequencia: 0,
    desPosicao: 'string',
    codOrdem: 0,
    flgAtivo: 0,
    filaComparaTipoDoc: {
      codTipoDoc: 0,
      desTipoDoc: 'string'
    },
    tpFila: {
      codTpfila: 0,
      nomFila: 'string',
      desFila: 'string',
      desMetodoconsulta: 'string',
      desMetodolock: 'string',
      desMetodopre: 'string',
      desMetodopos: 'string',
      flgAtivo: {},
      dtaInclusao: 'string',
      codUsuarioinclusao: 'string',
      dtaAlteracao: 'string',
      codUsuarioalteracao: 'string',
      descMetodoCentralizadora: 'string',
      flgMetodoCentralizadora: 'string',
      descMetodoCentralizadoraDet: 'string'
    }
  }
];
