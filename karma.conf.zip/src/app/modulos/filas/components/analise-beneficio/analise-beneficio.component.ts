import { Component, OnInit, ɵConsole } from '@angular/core';
import { BeneficioSolicitacaoService } from 'src/app/modulos/beneficio/services/beneficio-solicitacao.service';
import {
  ActivatedRouteSnapshot,
  ActivatedRoute,
  Router
} from '@angular/router';
import { map } from 'rxjs/operators';
import { PessoaDocumentoModel } from 'src/app/model/pessoa/pessoa-documento.model';
import { TipoDocumentoModel } from 'src/app/model/tipos/tipo-documento.model';
import { SolicitacaoBeneficioDataModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-data.model';
import { PessoaRelativoModel } from 'src/app/model/pessoa/pessoa-relativo.model';
import { PessoaFisicaModel } from 'src/app/model/pessoa/pessoa-fisica.model';
import { PessoaModel } from 'src/app/model/pessoa/pessoa.model';
import { AlertService } from 'src/app/shared/services/alert.service';
import { FilasService } from '../../filas.service';
import { Util } from 'src/app/core/utils/util';
import { MatDialog } from '@angular/material';
import { FormBuilder } from '@angular/forms';
import { ModalComponentComponent } from 'src/app/shared/modulos/modal-component/modal-component.component';
import { ModalReprovaComponent } from 'src/app/shared/modulos/modal-reprova/modal-reprova.component';
import { PessoaService } from 'src/app/modulos/pessoa/services/pessoa.service';

@Component({
  selector: 'app-analise-beneficio',
  templateUrl: './analise-beneficio.component.html',
  styleUrls: ['./analise-beneficio.component.scss']
})
export class AnaliseBeneficiarioComponent implements OnInit {
  fechaAbas;
  show4;
  codExterno = '';
  codTpFila = '';
  propertyAnalise;
  dataFilaComparaDoc = [];

  dadosEnderecos = [];
  dadosPessoais;
  dadosAnalise;

  motivosRecusa = [];

  util = new Util();

  displayedColumnsDocuments: string[] = [
    'docEsquerdo',
    'docDireito',
    'compara'
    // 'remove'
  ];

  salvarModel = {
    enderecos: model => {
      this.dadosAnalise.pessoa.enderecos = model;
      const promises = [];
      model.forEach(end => {
        this.alertService.setLoading(true);
        promises.push(this.pessoaService.atualizarPessoaEndereco(end));
      });

      Promise.all(promises)
        .then(res => {
          this.alertService.dispatch('Atualização de endereço concluída');
          this.alertService.setLoading(false);
        })
        .catch(err => {
          this.alertService.dispatch(err);
          this.alertService.setLoading(false);
        });
    },
    dadospessoa: model => {
      this.dadosAnalise.pessoa = model;
      this.alertService.setLoading(true);
      this.pessoaService
        .atualizarPessoa(model)
        .toPromise()
        .then((res: any) => {
          if (res.status) {
            this.atualizarDadaosSolicitacao();
            this.alertService.dispatch(
              'Atualização dos dados pessoais concluída'
            );
          }
        })
        .catch(err => this.alertService.dispatch(err))
        .finally(() => this.alertService.setLoading(false));
    }
  };

  dialogMetodos = {
    buscarUFs: () =>
      this.pessoaService
        .getAllUF()
        .pipe(map(res => (res.data ? res.data : [])))
        .toPromise(),
    buscarCidadesPorUF: uf =>
      this.pessoaService
        .getCidadePorUF(uf)
        .pipe(map(res => (res.data ? res.data : [])))
        .toPromise(),
    buscarTiposResidencia: () =>
      this.pessoaService
        .getAllTipoResidencia()
        .pipe(map(res => (res.data ? res.data : [])))
        .toPromise()
  };

  constructor(
    private beneficioSolicitacaoService: BeneficioSolicitacaoService,
    private filaService: FilasService,
    private route: ActivatedRoute,
    private alertService: AlertService,
    private fb: FormBuilder,
    private dialog: MatDialog,
    private pessoaService: PessoaService,
    private router: Router
  ) {}

  openDialog(item): void {
    const desDados = item.docEsquerdo.desDados || item.docDireito.desDados;
    const srcImg = {
      dir: undefined,
      esq: undefined
    };

    const esq = item.docEsquerdo;
    const dir = item.docDireito;

    const promisesImg = [];

    if (
      esq.filaComparaTipoDoc.desComparaDocTipo === 'IMAGEM' ||
      esq.filaComparaTipoDoc.desComparaDocTipo === 'PDF'
    ) {
      const url = `${esq.desMetodoConsultaImg}${this.dadosAnalise.codSolicbeneficio}/${esq.documento.codigo}/true`;
      promisesImg.push(
        new Promise((resolve, reject) => {
          this.filaService
            .getUrl(url)
            .pipe(map(res => (res.data ? res.data : undefined)))
            .toPromise()
            .then(res => {
              if (res) {
                srcImg.esq = res.urlArquivo;
                resolve();
              } else {
                reject('No file received!');
              }
            })
            .catch(err => reject(err));
        })
      );
    }

    if (
      dir.filaComparaTipoDoc.desComparaDocTipo === 'IMAGEM' ||
      dir.filaComparaTipoDoc.desComparaDocTipo === 'PDF'
    ) {
      const url = `${dir.desMetodoConsultaImg}${this.dadosAnalise.codSolicbeneficio}/${dir.documento.codigo}/true`;
      promisesImg.push(
        new Promise((resolve, reject) => {
          this.filaService
            .getUrl(url)
            .pipe(map(res => (res.data ? res.data : undefined)))
            .toPromise()
            .then(res => {
              if (res) {
                srcImg.dir = res.urlArquivo;
                resolve();
              } else {
                reject('No file received!');
              }
            })
            .catch(err => reject(err));
        })
      );
    }

    this.alertService.setLoading(true);
    Promise.all(promisesImg)
      .then(res => {
        console.log(res);
      })
      .finally(() => {
        this.alertService.setLoading(false);
        let model;
        switch (desDados) {
          case 'enderecos':
            model = this.dadosAnalise.pessoa.enderecos;
            break;
          case 'dadospessoa':
            model = this.dadosAnalise.pessoa;
            break;
          default:
            break;
        }

        const dialogRef = this.dialog.open(ModalComponentComponent, {
          data: {
            docs: item,
            model,
            tipoDados: desDados,
            dialogMetodos: this.dialogMetodos,
            srcImg
          },
          height: 'auto'
        });
        dialogRef.afterClosed().subscribe(result => {
          if (result) {
            this.salvarModel[result.tipoDados](result.model);
          }
        });
      });
  }

  modalReprova(): void {
    const dialogRef = this.dialog.open(ModalReprovaComponent, {
      data: {
        motivosRecusa: this.motivosRecusa
      }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const payload = {
          contexto: {
            codSolicbeneficio: this.dadosAnalise.codSolicbeneficio,
            codBeneficio: this.dadosAnalise.codBeneficio,
            motivosRecusa: result.motivosRecusa,
            desObservacao: result.desObservacao
          }
        };
        this.alertService.setLoading(true);
        this.beneficioSolicitacaoService
          .reprovarAnalise(payload)
          .toPromise()
          .then(res => {
            if (res.status) {
              this.alertService.dispatch('Análise Recusada!');
            } else {
              this.alertService.dispatch('Erro na solicitação!');
            }
            this.router.navigate([`/filas-analise`]);
          })
          .finally(() => this.alertService.setLoading(false));
      }
    });
  }

  getMatrizDocs(resolve, reject) {
    this.filaService
      .dadosComparaDocByTpFila(this.codTpFila)
      .pipe(
        map(res => {
          return res.data ? res.data : [];
        })
      )
      .toPromise()
      .then(res => {
        this.dataFilaComparaDoc = res;
        resolve();
      })
      .finally(() => {
        this.alertService.setLoading(false);
        resolve();
      });
  }

  atualizarDadaosSolicitacao() {
    return new Promise((resolve, reject) => {
      this.beneficioSolicitacaoService
        .getSolicitacaoBeneficioByCodigoSolicitacao(this.codExterno)
        .pipe(map(res => (res.data ? res.data : [])))
        .toPromise()
        .then(res => {
          if ((res as any).length > 0) {
            this.dadosAnalise = res[0];
            this.dadosPessoais = this.getDadosPessoais(this.dadosAnalise);
            this.dadosEnderecos = this.dadosAnalise.pessoa.enderecos;

            this.getMatrizDocs(resolve, reject);
          }
        })
        .catch(err => reject(err));
    });
  }

  ngOnInit() {
    this.codExterno = this.route.snapshot.paramMap.get('codExterno');
    this.codTpFila = this.route.snapshot.paramMap.get('tpFila');
    this.alertService.setLoading(true);
    const motivoRecusaPromise = new Promise((resolve, reject) => {
      this.filaService
        .getMotivosRecusa()
        .pipe(
          map(res => {
            return res.data ? res.data : [];
          })
        )
        .toPromise()
        .then(res => {
          this.motivosRecusa = res;
          resolve();
        });
    });

    Promise.all([
      this.atualizarDadaosSolicitacao(),
      motivoRecusaPromise
    ]).then(res => this.alertService.setLoading(false));
  }

  mapFilaComparaDoc(arr) {
    const mapRes = Util.groupBy(arr, 'codSequencia');
    return Object.keys(mapRes).map(data => mapRes[data]);
  }

  aprovar() {
    const payload = {
      contexto: {
        codSolicbeneficio: this.dadosAnalise.codSolicbeneficio,
        codBeneficio: this.dadosAnalise.codBeneficio
      }
    };
    this.alertService.setLoading(true);
    this.beneficioSolicitacaoService
      .aprovarAnalise(payload)
      .toPromise()
      .then(res => {
        if (res.status) {
          this.alertService.dispatch('Análise Aprovada!');
        } else {
          this.alertService.dispatch('Erro na solicitação!');
        }
        this.router.navigate([`/filas-analise`]);
      })
      .finally(() => this.alertService.setLoading(false));
  }

  getDadosPessoais(solicitacao: SolicitacaoBeneficioDataModel) {
    const pessoaDocumentoRG = {} as PessoaDocumentoModel;
    const pessoaFisica = {} as PessoaFisicaModel;
    const tipoDocumentoRG = {} as TipoDocumentoModel;
    const pessoa = {} as PessoaModel;
    tipoDocumentoRG.ativo = false;
    tipoDocumentoRG.codigo = 0;
    tipoDocumentoRG.descricao = '';
    pessoaDocumentoRG.numDocumento = '';
    pessoaDocumentoRG.digDocumento = '';
    pessoaDocumentoRG.slgOrgemissor = '';
    pessoaDocumentoRG.dtaEmissao = new Date('01/01/1900');
    pessoaDocumentoRG.tpoDocumento = Object.assign({}, tipoDocumentoRG);
    pessoaDocumentoRG.slgUf = '';
    pessoaFisica.numCpf = '';
    pessoa.nomPessoa = '';

    let relativoMae: PessoaRelativoModel;
    let relativoPai: PessoaRelativoModel;

    if (
      solicitacao.pessoa.documentos &&
      solicitacao.pessoa.documentos.length > 0
    ) {
      const personalDoc = solicitacao.pessoa.documentos.find(
        doc => doc.tpoDocumento.descricao === 'RG'
      );

      pessoaDocumentoRG.numDocumento = personalDoc.numDocumento
        ? personalDoc.numDocumento
        : '';
      pessoaDocumentoRG.digDocumento = personalDoc.digDocumento
        ? personalDoc.digDocumento
        : '';
      pessoaDocumentoRG.slgOrgemissor = personalDoc.slgOrgemissor
        ? personalDoc.slgOrgemissor
        : '';
      pessoaDocumentoRG.dtaEmissao = personalDoc.dtaEmissao
        ? personalDoc.dtaEmissao
        : new Date();

      relativoMae = solicitacao.pessoa.relativos.find(
        rel => rel.tpoRelacao.codTiporelacao === 254
      );
      relativoPai = solicitacao.pessoa.relativos.find(
        rel => rel.tpoRelacao.codTiporelacao === 253
      );

      relativoMae = relativoMae ? relativoMae : { nomPessoarelativo: '' };
      relativoPai = relativoPai ? relativoPai : { nomPessoarelativo: '' };

      if (personalDoc.tpoDocumento) {
        pessoaDocumentoRG.tpoDocumento = Object.assign(
          {},
          personalDoc.tpoDocumento
        );
      }
      pessoaDocumentoRG.slgUf = personalDoc.slgUf ? personalDoc.slgUf : '';
      pessoaFisica.numCpf = solicitacao.pessoa.dadosPessoaFisica.numCpf;
      pessoaFisica.dtaNascimento =
        solicitacao.pessoa.dadosPessoaFisica.dtaNascimento;
      pessoa.nomPessoa = solicitacao.pessoa.nomPessoa;
    }

    return {
      pessoaDoc: pessoaDocumentoRG,
      pessoaFisica,
      pessoa,
      relativos: { relativoMae, relativoPai }
    };
  }
}
