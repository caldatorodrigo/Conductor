import { Component } from '@angular/core';
import { FilasAnalise } from './example-data';
import { AgrupamentoFilas } from 'src/app/model/fila/agrupamento-filas';
import { Fila } from 'src/app/model/fila/fila';
import { FilasService } from '../../filas.service';
import { NestedTreeControl } from '@angular/cdk/tree';
import { map } from 'rxjs/operators';
import { ArrayDataSource } from '@angular/cdk/collections';
import { AlertService } from 'src/app/shared/services/alert.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-analise',
  templateUrl: './analise.component.html',
  styleUrls: ['./analise.component.scss']
})
export class AnaliseComponent {
  fechaAbas;
  show4;
  show;
  consultaHistorico;
  itemFilaSelecionada;
  public filas: Fila[];
  public filaResponse: AgrupamentoFilas;
  // public filasSolicitacoes : Map<string, any>;
  public filasSolicitacoes: any;
  public itemByStatusSelecionado: string;
  public filaSelecionada: string;
  public isItemFilaSelecinadoExpanded: Boolean;
  public isSubItemFilaSelecinadoExpanded: Boolean;
  public mapFilasExpanded: Map<string, Boolean>;
  public mapFilasItemExpanded: Map<string, Boolean>;

  showAberturaContaBeneficioEmFila: Boolean = false;
  showAnaliseFila: Boolean = false;

  treeControl = new NestedTreeControl<FilasAnalise>(node => node.filaStatus);
  dataSources = [];
  filasContext = [];
  solicitacoes = [];

  showBlock = {
    analiseBeneficio: false,
    analiseContaCorrente: false,
    analiseProvaDeVida: false,
    analiseAlteracaoFormaPgmto: false,
    analiseRecadastramentoCenso: false
  };

  constructor(
    public filasService: FilasService,
    private alertService: AlertService,
    private router: Router
  ) {}

  atualizarFila() {
    this.solicitacoes = [];
    this.itemFilaSelecionada = undefined;
    this.dataSources = [];
    this.alertService.setLoading(true);
    this.filasService
      .getFilaCentralizadora()
      .pipe(
        map(res => {
          return res.data ? this.mapContext(res.data) : [];
        })
      )
      .subscribe(context => {
        this.filasContext = context;
        this.filasContext.map(contextMap => {
          this.dataSources.push(new ArrayDataSource(contextMap.filas));
          return { contexto: contextMap.context };
        });
        this.alertService.setLoading(false);
      });
  }

  ngOnInit(): void {
    this.atualizarFila();
  }

  hasChild = (_: number, node: FilasAnalise) =>
    !!node.filaStatus && node.filaStatus.length > 0;

  mapContext(contexts) {
    return contexts.map(item => {
      return {
        contexto: item.contexto,
        filas: this.mapFilas(item.filas)
      };
    });
  }

  mapFilas(filas: FilasAnalise[], nomTpFila?, codTpfila?, urlAPI?) {
    return filas.map(fila => {
      if (fila.filaStatus && fila.filaStatus.length > 0) {
        this.mapFilas(
          fila.filaStatus,
          fila.nomTpFila,
          fila.codTpfila,
          fila.urlAPI
        );
      } else if (codTpfila && urlAPI) {
        fila.codTpfila = codTpfila;
        fila.urlAPI = urlAPI;
        fila.nomTpFila = nomTpFila;
      }
      return fila;
    });
  }

  consultar(urlApi, codTpFila, codStatus, nomTpFila, nomStatus, totStatus) {
    this.itemFilaSelecionada = undefined;
    this.solicitacoes = [];
    this.alertService.setLoading(true);
    this.filasService
      .getFilaPorTipo(`${urlApi}${codTpFila}/${codStatus}`)
      .then(solicitacoes => {
        this.solicitacoes = solicitacoes;
        this.showBlock.analiseBeneficio = true;
        this.itemFilaSelecionada = {
          nomTpFila,
          nomStatus,
          totStatus,
          codStatus,
          codTpFila
        };
      })
      .finally(() => this.alertService.setLoading(false));
  }

  iniciarAnalise(item) {
    this.alertService.setLoading(true);
    const urlAPI =
      this.itemFilaSelecionada.codStatus !== 2
        ? item.urlIniciarFilaAnalise
        : item.urlCancelarFilaAnalise;
    this.filasService
      .acaoAnalise(urlAPI, {
        fila: {
          codIdfila: item.codIdFila,
          pessoaFuncionario: {
            codPessoa: 0
          }
        }
      })
      .toPromise()
      .then(data => {
        if (data.status) {
          if (this.itemFilaSelecionada.codStatus !== 2) {
            this.alertService.dispatch('Análise iniciada');
            this.router.navigate([`filas-analise/beneficio/${this.itemFilaSelecionada.codTpFila}/${item.codExterno}`]);
          } else {
            this.alertService.dispatch('Análise cancelada!');
            this.atualizarFila();
          }
        } else {
          this.alertService.dispatch(data.exceptionMessage);
        }
      })
      .finally(() => this.alertService.setLoading(false));
  }
}
