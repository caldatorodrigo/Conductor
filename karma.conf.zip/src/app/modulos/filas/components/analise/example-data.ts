export interface FilasAnalise {
  codTpfila?: number;
  nomTpFila?: string;
  totTpFila?: number;
  urlAPI?: string;
  filaStatus?: FilasAnalise[];
  codStatus?: number;
  nomStatus?: string;
  totStatus?: number;
}

export const FILAS_ANALISE = {
  data: [
    {
      codTpfila: 1,
      nomTpFila: "Abertura de Conta Beneficio",
      totTpFila: 10,
      urlAPI: "string",
      filaStatus: [
        {
          codStatus: 1,
          nomStatus: "Em Fila",
          totStatus: 78
        },
        {
          codStatus: 2,
          nomStatus: "Em Analise",
          totStatus: 8
        }
      ]
    },
    {
      codTpfila: 2,
      nomTpFila: "Abertura de Conta Corrente",
      totTpFila: 20,
      urlAPI: "string",
      filaStatus: [
        {
          codStatus: 1,
          nomStatus: "Em Fila",
          totStatus: 15
        },
        {
          codStatus: 2,
          nomStatus: "Em Analise",
          totStatus: 5
        }
      ]
    },
    {
      codTpfila: 3,
      nomTpFila: "Prova de Vida",
      totTpFila: 33,
      urlAPI: "string",
      filaStatus: [
        {
          codStatus: 1,
          nomStatus: "Em Fila",
          totStatus: 15
        },
        {
          codStatus: 2,
          nomStatus: "Em Analise",
          totStatus: 18
        }
      ]
    },
    {
      codTpfila: 4,
      nomTpFila: "Alteração da Forma de Recebimento Beneficio",
      totTpFila: 100,
      urlAPI: "string",
      filaStatus: [
        {
          codStatus: 2,
          nomStatus: "Em Fila",
          totStatus: 78
        },
        {
          codStatus: 2,
          nomStatus: "Em Analise",
          totStatus: 22
        }
      ]
    },
    {
      codTpfila: 5,
      nomTpFila: "Cadastramento de Censo",
      totTpFila: 22,
      urlAPI: "string",
      filaStatus: [
        {
          codStatus: 1,
          nomStatus: "Em Fila",
          totStatus: 10
        },
        {
          codStatus: 2,
          nomStatus: "Em Analise",
          totStatus: 12
        }
      ]
    },
    {
      codTpfila: 1,
      nomTpFila: "Abertura de Conta Beneficio",
      totTpFila: 10,
      urlAPI: "string",
      filaStatus: [
        {
          codStatus: 1,
          nomStatus: "Em Fila",
          totStatus: 2
        },
        {
          codStatus: 2,
          nomStatus: "Em Analise",
          totStatus: 8
        }
      ]
    }
  ],
  exceptionMessage: "string",
  hostname: "string",
  message: "string",
  status: true
};

export const ITENS_FILAS_ANALISE = {
  data: [
    {
      dtaIniAnalise: "10/10/2018 15:30:31",
      cpf: "218.222.338-10",
      atendente: "232102 - Maria Conceicao"
    },
    {
      dtaIniAnalise: "11/11/2018 16:31:32",
      cpf: "254.222.338-10",
      atendente: "245502 - Maria de Jesus"
    },
    {
      dtaIniAnalise: "07/12/2018 09:45:23",
      cpf: "218.222.338-10",
      atendente: "897897 - Lourdes dos Santos"
    },
    {
      dtaIniAnalise: "27/01/2019 17:04:54",
      cpf: "097.789.321-97",
      atendente: "789123 - Fatima dos Santos"
    }
  ]
};

export const SOLICITACOES_FILA = {
  data: [
    {
      codFilaAnalise: 0,
      codIdfilaAnalise: 0,
      codIdfila: 0,
      codUsuAnalise: "string",
      dtaIniAnalise: "string",
      dtaFimAnalise: "string",
      desObservacao: "string",
      motivosRecusa: [
        {
          codMotivorecusa: 0,
          codTpfila: 0,
          desMotivorecusa: "string",
          flgBiometria: {},
          flgGeratermo: {},
          flgAlteradados: {}
        }
      ]
    },
    {
      codFilaAnalise: 0,
      codIdfilaAnalise: 0,
      codIdfila: 0,
      codUsuAnalise: "string",
      dtaIniAnalise: "string",
      dtaFimAnalise: "string",
      desObservacao: "string",
      motivosRecusa: [
        {
          codMotivorecusa: 0,
          codTpfila: 0,
          desMotivorecusa: "string",
          flgBiometria: {},
          flgGeratermo: {},
          flgAlteradados: {}
        }
      ]
    }
  ],
  exceptionMessage: "string",
  hostname: "string",
  message: "string",
  status: true
};

/* --------------------------------------------------- */

export const CENTRALIZADORA_FILAS_ANALISE_JSON = [
  {
    codTpfila: "1000",
    nomTpFila: "Abertura de Conta Beneficio",
    totTpFila: "10",
    filaStatus: [
      {
        codStatus: "1",
        nomStatus: "Em Fila",
        totStatus: "7"
      },
      {
        codStatus: "2",
        nomStatus: "Em Analise",
        totStatus: "3"
      }
    ]
  },
  {
    codTpfila: "1001",
    nomTpFila: "Abertura de Conta Corrente",
    totTpFila: "20",
    filaStatus: [
      {
        codStatus: "1",
        nomStatus: "Em Fila",
        totStatus: "10"
      },
      {
        codStatus: "2",
        nomStatus: "Em Analise",
        totStatus: "10"
      }
    ]
  },
  {
    codTpfila: "1002",
    nomTpFila: "Prova de Vida",
    totTpFila: "30",
    filaStatus: [
      {
        codStatus: "1",
        nomStatus: "Em Fila",
        totStatus: "15"
      },
      {
        codStatus: "2",
        nomStatus: "Em Analise",
        totStatus: "15"
      }
    ]
  },
  {
    codTpfila: "1003",
    nomTpFila: "Alteração da Forma de Recebimento Beneficio",
    totTpFila: "40",
    filaStatus: [
      {
        codStatus: "1",
        nomStatus: "Em Fila",
        totStatus: "22"
      },
      {
        codStatus: "2",
        nomStatus: "Em Analise",
        totStatus: "18"
      }
    ]
  },
  {
    codTpfila: "1004",
    nomTpFila: "Cadastramento de Censo",
    totTpFila: "50",
    filaStatus: [
      {
        codStatus: "1",
        nomStatus: "Em Fila",
        totStatus: "30"
      },
      {
        codStatus: "2",
        nomStatus: "Em Analise",
        totStatus: "20"
      }
    ]
  }
];

export const files = [
  {
    name: "Abertura de Conta Beneficio",
    children: [{ name: "Em Fila" }, { name: "Em Analise" }]
  },
  {
    name: "Abertura de Conta Corrente",
    children: [{ name: "Em Fila" }, { name: "Em Analise" }]
  },
  {
    name: "Prova de Vida",
    children: [{ name: "Em Fila" }, { name: "Em Analise" }]
  },
  {
    name: "Alteração da Forma de Recebimento Beneficio",
    children: [{ name: "Em Fila" }, { name: "Em Analise" }]
  },
  {
    name: "Cadastramento de Censo",
    children: [{ name: "Em Fila" }, { name: "Em Analise" }]
  }
];

// export const files = [
//   {
//     name: 'components',
//     type: 'folder',
//     children: [
//       {
//         name: 'src',
//         type: 'folder',
//         children: [
//           {
//             name: 'cdk',
//             type: 'folder',
//             children: [
//               { name: 'package.json', type: 'file' },
//               { name: 'BUILD.bazel', type: 'file' },
//             ]
//           },
//           { name: 'material', type: 'folder' }
//         ]
//       }
//     ]
//   },
//   {
//     name: 'angular',
//     type: 'folder',
//     children: [
//       {
//         name: 'packages',
//         type: 'folder',
//         children: [
//           { name: '.travis.yml', type: 'file' },
//           { name: 'firebase.json', type: 'file' }
//         ]
//       },
//       { name: 'package.json', type: 'file' }
//     ]
//   },
//   {
//     name: 'angularjs',
//     type: 'folder',
//     children: [
//       { name: 'gulpfile.js', type: 'file' },
//       { name: 'README.md', type: 'file' }
//     ]
//   }
// ];
