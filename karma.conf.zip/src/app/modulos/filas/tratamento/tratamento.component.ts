import { Component, OnInit, ViewChild } from '@angular/core';
import { faSearch, faAngleUp, faAngleDown, 
         faPlay, faHeartbeat, faAngleRight,
         faCreditCard, faCog } from "@fortawesome/free-solid-svg-icons";

const CARS = [
                {"vin":"Abertura de Conta Beneficio","brand":"VW","year":1998,"color":"White","price":10000},
                {"vin":"Abertura de Conta Corrente","brand":"Mercedes","year":1985,"color":"Green","price":25000},
                {"vin":"Prova de Vida","brand":"Jaguar","year":1979,"color":"Silver","price":30000},
                {"vin":"Alteracao Forma de Recebimento Beneficio","brand":"Audi","year":1970,"color":"Black","price":12000},
                {"vin":"Antecipacao de Renda","brand":"Volvo","year":1992,"color":"Red","price":15500},
                {"vin":"Cadastramento de Censo","brand":"VW","year":1993,"color":"Maroon","price":40000}
];

@Component({
  selector: 'app-tratamento',
  templateUrl: './tratamento.component.html',
  styleUrls: ['./tratamento.component.scss']
})
export class TratamentoComponent implements OnInit {

  fechaAbas;
  show;

  public cars:any[];
  public cols: any[];
  public isExpanded:boolean = false;
  public rows:number =10;
  public expandedRows = {};
  public temDataLength:number = 0;

  public faAngleUp = faAngleUp;
  public faAngleDown = faAngleDown;
  public faSearch = faSearch;
  public faPlay = faPlay;
  public faHeartbeat = faHeartbeat;
  public faAngleRight = faAngleRight;
  public faCreditCard = faCreditCard;
  public faCog = faCog;

  constructor() { }

  ngOnInit() {
    
    this.cols = [
      { field: 'vin', header: 'Filas de Analise' }
    ];

    this.cars = CARS;
    this.cars.length < this.rows ? this.temDataLength = this.cars.length : this.temDataLength = this.rows;
  }

  expandAll() {

    if(!this.isExpanded){

      this.cars.forEach(data =>{
        this.expandedRows[data.vin] = 1;
      })

    } else {

      this.expandedRows={};
      
    }
    this.isExpanded = !this.isExpanded;
  }

  onRowExpand() {
    console.log("row expanded", Object.keys(this.expandedRows).length);
    if(Object.keys(this.expandedRows).length === this.temDataLength){
      this.isExpanded = true;
    }
  }
  
  onRowCollapse() {
    console.log("row collapsed",Object.keys(this.expandedRows).length);
    if(Object.keys(this.expandedRows).length === 0){
      this.isExpanded = false;
    }
  }
  
  onPage(event: any) {
    this.temDataLength = this.cars.slice(event.first, event.first + 10).length;
    console.log(this.temDataLength);
    this.isExpanded = false;
    this.expandedRows={};
  }

}




