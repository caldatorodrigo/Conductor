import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable }              from "@angular/core";
import { map }                     from "rxjs/operators";

@Injectable() 
export class CapturaImagemService{

    constructor(private http: HttpClient){
    }

    public SalvarCapturaApi(pUrl:string, parametro:any) { /// Gravar documento na base de dados.
        console.log('SalvarCapturaApi parametro=' + JSON.stringify(parametro));
        return this.http.post(pUrl, parametro).pipe(map(data => {return data}));
    }
    
}