import { Component, OnInit, Inject } from "@angular/core";
import { Observable, Subject }     from "rxjs";
import { WebcamImage }             from "../../shared/modulos/webcam/domain/webcam-image";
import { WebcamUtil }              from "../../shared/modulos/webcam/util/webcam.util";
import { WebcamInitError}          from "../../shared/modulos/webcam/domain/webcam-init-error";
import { ActivatedRoute }          from "@angular/router";
import { MatSnackBar, MAT_DIALOG_DATA, MatDialogRef } from "@angular/material";
import { capturaImagem }           from "src/app/model/capturaimagem/capturaimagem";
import { capturaImagemSerializer } from "src/app/model/capturaimagem/capturaimagem.Serialize";
import { CapturaImagemService }    from "./services/captura-imagem.service";
import { environment }             from "src/environments/environment";

@Component( { 
    selector: 'app-captura-imagem', 
    templateUrl: './captura-imagem.component.html', 
    styleUrls: ['./captura-imagem.component.scss'] 
}) 
export class CapturaImagemComponent implements OnInit {
    
    public showWebcam               = true; // toggle webcam on/off
    public allowCameraSwitch        = true;
    public multipleWebcamsAvailable = false;
    public deviceId:string;
    public facingMode:string        = 'environment';
    public errors:WebcamInitError[] = [];

    private paramtroEntrada:string; ///Variaveis
    private _capturaImagem            = new capturaImagem();
    private _capturaImagemSerializer  = new capturaImagemSerializer();
    public  tirouFoto:boolean         = false;
    public  finalizouCaptura:boolean  = false;
    private _environment;
    private API_CAPTURA_IMAGEM:string = "/api/CapturaImagem/v1/CapturaImagem";
    
    public  webcamImage:WebcamImage            = null; // latest snapshot
    private trigger:Subject<void>              = new Subject<void>(); // webcam snapshot trigger
    private nextWebcam:Subject<boolean|string> = new Subject<boolean|string>(); // switch to next / previous / specific webcam; true/false: forward/backwards, string: deviceId

    constructor(@Inject(MAT_DIALOG_DATA) public dados:any, private route: ActivatedRoute, public  snackBar: MatSnackBar, private capturaImagemService: CapturaImagemService, public modal:MatDialogRef<CapturaImagemComponent>) {
        this._environment = environment;
        this.paramtroEntrada = window.atob(dados.dadosBase64); // decode do base64
    }

    public ngOnInit():void {
        WebcamUtil.getAvailableVideoInputs().then((mediaDevices: MediaDeviceInfo[]) => {
            this.multipleWebcamsAvailable = mediaDevices && mediaDevices.length > 1;
        });
        try {
            this._capturaImagem = this._capturaImagemSerializer.fromJson(JSON.parse(this.paramtroEntrada));  /// Cria a classe digitaliza��o para armazenar os dados deserializados.
        } 
        catch (error) {
            this.EnviarMensagem(error, "Erro"); /// Desabilitar os botoes do formulario para n�o ser possivel digitalizar.
        }
    }

    teste() {
        let teste:string = "{ \"codigoSolicitacao\": \"161\", \"codigoDocumento\": \"11\" }";
        var enc = btoa(teste); //Encode
        var dec = atob(enc); //Decode
        console.info("Encoded String: " + enc + "<br>" + "Decoded String: " + dec);
    }

    finalizarCaptura() {
        try {
            this._capturaImagem.imageBase64 = this.webcamImage.imageAsBase64;
            this.capturaImagemService.SalvarCapturaApi(this._environment.API_INSS_SERVER_NAME + this.API_CAPTURA_IMAGEM, this._capturaImagemSerializer.toJson(this._capturaImagem)).subscribe(
                resp => {
                    this.EnviarMensagem("Imagem Salva com sucesso!", "X");
                    console.log('respPost SalvarCapturaApi=' + JSON.stringify(resp));
                    this.modal.close("o componente de captura de imagem foi fechado");
                },
                err => {
                    console.error('erro em SalvarCapturaApi'+JSON.stringify(err))
                    this.EnviarMensagem(JSON.stringify(err), "Erro");
                }
            );
            this.finalizouCaptura = false;
        } 
        catch (error) {
            this.EnviarMensagem(error, "Erro");
            this.finalizouCaptura = true;
        }
    }

    public triggerSnapshot():void {
        try {
            this.trigger.next();  
            this.tirouFoto = true;
            this.finalizouCaptura = true;
            this.EnviarMensagem("Foto tirada com sucesso!", "X");
        } 
        catch (error) {
            this.EnviarMensagem(error, "Erro");
        }      
    }

    public toggleWebcam():void {
        this.showWebcam = !this.showWebcam;
    }

    public handleInitError(error: WebcamInitError):void {
        if (error.mediaStreamError && error.mediaStreamError.name === "NotAllowedError") {
            console.warn("Camera access was not allowed by user!");
        }
        this.errors.push(error);
    }

    public showNextWebcam(directionOrDeviceId: boolean|string):void {
        this.nextWebcam.next(directionOrDeviceId); // true => move forward through devices, false => move backwards through devices, string => move to device with given deviceId
    }

    public handleImage(webcamImage: WebcamImage): void {
        console.log('received webcam image', webcamImage);
        this.webcamImage = webcamImage;
    }

    public cameraWasSwitched(deviceId: string): void {
        console.log('active device: ' + deviceId);
        this.deviceId = deviceId;
    }

    public get triggerObservable(): Observable<void> {
        return this.trigger.asObservable();
    }

    public get nextWebcamObservable(): Observable<boolean|string> {
        return this.nextWebcam.asObservable();
    }

    public get videoOptions(): MediaTrackConstraints {
        const result: MediaTrackConstraints = {};
        if (this.facingMode && this.facingMode !== "") {
            result.facingMode = { ideal: this.facingMode };
        }
        return result;
    }

    EnviarMensagem(message: string, action: string) {
        this.snackBar.open(message, action, { duration: 5000, horizontalPosition: "right", verticalPosition: "top" });
    }
  
}
