import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { ContaCorrenteService } from '../../services/conta-corrente.service';
import { AlertService } from 'src/app/shared/services/alert.service';
@Component({
  selector: 'chek-nova-solicitacao',
  template: `
    <div fxLayout="column" (keyup)="checkEnter($event)">
      <span>Por favor, informe o CPF para validação de abertura de conta</span>
      <div fxLayout="row" fxLayoutAlign="start center" fxLayoutGap="20px">
        <mat-form-field fxFlex="1 1 100%">
          <input matInput cpfMask [(ngModel)]="cpf" name="cpf" />
        </mat-form-field>
        <!-- <button class="btn btn-outline" (click)="cancelar()">Cancelar</button> -->
        <button class="btn btn-default" (click)="consultar()">
          Solicitar
        </button>
      </div>
    </div>
  `
})
export class CheckNovaSolicitacaoDialogComponent {
  cpf = '';
  constructor(
    public dialogRef: MatDialogRef<CheckNovaSolicitacaoDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: any,
    private contaCorrenteService: ContaCorrenteService,
    private alertService: AlertService
  ) {}
  cancelar(): void {
    this.dialogRef.close();
  }

  consultar() {
    this.dialogRef.close(this.cpf);
  }

  checkEnter(event) {
    if (event.code === 'NumpadEnter' || event.code === 'Enter') {
      this.consultar();
    }
  }
}
