import { Component, OnInit, Inject, ViewChild } from '@angular/core';
import {
  MatTableDataSource,
  MatCheckboxChange,
  MatDialog
} from '@angular/material';
import { ContaCorrenteService } from '../../services/conta-corrente.service';
import { AlertService } from 'src/app/shared/services/alert.service';
import { util } from 'src/app/core/utils/util';
import { PageScrollService } from 'ngx-page-scroll-core';
import { DOCUMENT } from '@angular/common';
import { SolicitacaoContaCorrenteModel } from './../../../../model/solicitacao/conta-corrente/solicitacao-conta-corrente.model';
import { PessoaModel } from 'src/app/model/pessoa/pessoa.model';
import { PessoaService } from 'src/app/modulos/pessoa/services/pessoa.service';
import { FichaCadastralConfig } from 'src/app/modulos/pessoa/ficha-cadastral.model';
import { ProcuradorModel } from 'src/app/model/beneficio/procurador/procurador.model';
import { BeneficioSolicitacaoService } from 'src/app/modulos/beneficio/services/beneficio-solicitacao.service';
import { CheckNovaSolicitacaoDialogComponent } from './CheckNovaSolicitacaoDialog';
import { PACOTE_TARIFAS } from 'src/app/data/pacote-tarifas.data';
import { SolicitacaoComponent } from 'src/app/modulos/solicitacao.component';

@Component({
  selector: 'app-conta-corrente',
  templateUrl: './conta-corrente.component.html',
  styleUrls: ['./conta-corrente.component.scss']
})
export class ContaCorrenteComponent extends SolicitacaoComponent
  implements OnInit {
  // @ViewChild('pessoaComp', { static: false }) pessoaComp: PessoaComponent;

  pacoteTarifaList = [];

  solicitacao: SolicitacaoContaCorrenteModel = {} as SolicitacaoContaCorrenteModel;
  procurador: ProcuradorModel;
  procuradorPessoa: PessoaModel = {} as PessoaModel;

  // showSolicitacoes = false;

  contaCorrenteDataSource: MatTableDataSource<any>;

  constructor(
    private contaCorrenteService: ContaCorrenteService,
    private alertService: AlertService,
    public pageScrollService: PageScrollService,
    @Inject(DOCUMENT) public document: any,
    private pessoaService: PessoaService,
    private dialog: MatDialog,
    private beneficioSolicitacaoService: BeneficioSolicitacaoService
  ) {
    super(pageScrollService, document);
    this.dataSources = [
      {
        key: 'conta',
        dataSource: new MatTableDataSource<any>([]),
        displayColumns: ['numConta', 'cpf', 'nome', 'status', 'acoes']
      },
      {
        key: 'solicitacao',
        dataSource: new MatTableDataSource<any>([]),
        displayColumns: ['numSolicConta', 'status', 'acao']
      }
    ];

    this.modulesConfig = [
      {
        key: 'procurador',
        disabledForm: true,
        className: 'procurador',
        title: 'Dados Procurador',
        active: false
      },

      {
        key: 'pacoteTarifa',
        disabledForm: false,
        className: 'pacote-tarifa',
        title: 'Pacotes de Tarifa',
        active: true
      },

      {
        key: 'capturaCartoes',
        disabledForm: true,
        className: 'captura-cartoes',
        title: 'Captura de Cartões',
        active: true
      },

      {
        key: 'capturaDocumentos',
        disabledForm: true,
        className: 'captura-documentos',
        title: 'Captura de Documentos',
        active: true
      }
    ];

    (this.fichaCadastralActivationPessoa.title =
      'FICHA CADASTRAL - CONTA CORRENTE'),
      (this.fichaCadastralActivationPessoa.className =
        'ficha-cadastral-conta-corrente'),
      (this.fichaCadastralActivationPessoa.end = pessoa => {
        this.modules('procurador').disabledForm = false;
        this.modules('procurador').active = true;
        this.scrollTo(this.modules('procurador').className);
      });

    this.fichaCadastralActivationProcurador.end = pessoaProcurador => {
      console.log('pessoaProcurador => ', pessoaProcurador);
    };
  }

  ngOnInit() {
    this.procuradorPessoa = this.startPessoa();
    this.alertService.setLoading(true);

    util
      .promiseMapArray(this.contaCorrenteService.consultarPacoteTarifas())
      .then(res => {
        this.pacoteTarifaList = res;
      })
      .catch(err => {
        this.pacoteTarifaList = PACOTE_TARIFAS;
      })
      .finally(() => this.alertService.setLoading(false));
  }

  pesquisar(form) {
    if (form.valid) {
      this.fecharFichaCadastralPessoa();
      this.alertService.setLoading(true);
      if (util.isEmptyNullOrUndefined(this.modelConsulta.numCpf)) {
        this.contaCorrenteService
          .consultarContaPor(
            'conta',
            util.onlyDigits(this.modelConsulta.chaveProcesso)
          )
          .toPromise()
          .then(res => console.log(res))
          .finally(() => this.alertService.setLoading(false));
      } else {
        this.contaCorrenteService
          .consultarContaPor('cpf', util.onlyDigits(this.modelConsulta.numCpf))
          .toPromise()
          .then(res => console.log(res))
          .finally(() => {
            this.populateTable('conta', [
              {
                codConta: '888',
                pessoa: {
                  nomPessoa: 'Held Felipe Aragão',
                  dadosPessoaFisica: { numCpf: '01910000000' }
                },
                ativo: true
              }
            ]);
            this.alertService.setLoading(false);
          });
      }
    } else if (
      util.isEmptyNullOrUndefined(
        this.modelConsulta.numCpf || this.modelConsulta.chaveProcesso
      )
    ) {
      this.alertService.dispatch('Por favor preencha uma das informações');
    } else {
      this.alertService.dispatch('Número de CPF inválido');
    }
  }

  editarSolicitacao(solic) {
    this.abrirFichaCadastral();
  }

  /* hasData(dataSource) {
    return this.dataSources[dataSource] &&
      this.dataSources[dataSource].data &&
      this.dataSources[dataSource].data.length > 0
      ? true
      : false;
  } */

  changeSolicitacao() {
    console.log(this.solicitacao);
  }

  buscarSolicitacoes(conta) {
    /*  this.solicitacao = {
      pessoa: this.startPessoa()
     } as SolicitacaoContaCorrenteModel;  */
    this.alertService.setLoading(true);
    util
      .promiseMapArray(
        this.beneficioSolicitacaoService.getSolicitacaoBeneficioByCodigoSolicitacao(
          '161'
        )
      )
      .then(res => {
        res.forEach(element => {
          this.populateTable('solicitacao', [
            {
              codConta: 880,
              codSolicConta: 1,
              pessoa: element.pessoa,
              status: element.status
            } as SolicitacaoContaCorrenteModel
          ]);
        });
        if (res && res.length > 0) {
          this.solicitacao = res[0];
          this.showSolicitacoes = true;
          this.scrollTo('panel-solicitacoes');
        }
      })
      .finally(() => this.alertService.setLoading(false));
  }

  novaSolicitacao() {
    this.dialog
      .open(CheckNovaSolicitacaoDialogComponent, {
        data: {},
        width: '500px'
      })
      .afterClosed()
      .subscribe(result => {
        if (result) {
          console.log(result);
          this.abrirFichaCadastral(true);
        }
      });
  }

  abrirFichaCadastral(isNew?) {
    if (!!isNew) {
      this.solicitacao = {
        pessoa: this.startPessoa()
      } as SolicitacaoContaCorrenteModel;
    }

    this.abrirFichaCadastralPessoa(!!isNew);
  }

  /* scrollTo(className) {
    setTimeout(() => {
      this.pageScrollService.scroll({
        document: this.document,
        scrollTarget: '.' + className,
        speed: 200
      });
    }, 700);
  } */
}
