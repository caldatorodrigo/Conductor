import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ContaCorrenteComponent } from './pages/conta-corrente/conta-corrente.component';
import { CheckNovaSolicitacaoDialogComponent } from './pages/conta-corrente/CheckNovaSolicitacaoDialog';
import { Routes, RouterModule } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { ContaCorrenteService } from './services/conta-corrente.service';
import { PessoaModule } from '../pessoa/pessoa.module';
import { BeneficioSolicitacaoService } from '../beneficio/services/beneficio-solicitacao.service';

export const contaCorrenteRoutes: Routes = [
  {
    path: '',
    component: ContaCorrenteComponent,
    data: { title: 'Conta Corrente' }
  }
];

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    RouterModule,
    PessoaModule
  ],
  exports: [ContaCorrenteComponent],
  declarations: [ContaCorrenteComponent, CheckNovaSolicitacaoDialogComponent],
  providers: [ContaCorrenteService, BeneficioSolicitacaoService],
  entryComponents: [CheckNovaSolicitacaoDialogComponent]
})
export class ContaCorrenteModule {}
