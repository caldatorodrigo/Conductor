import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { map } from 'rxjs/operators';

@Injectable({ providedIn: 'root' })
export class ContaCorrenteService {
  get CONTA_URL() {
    return `${environment.API_CONTA_CORRENTE}/api/Conta/v1/`;
  }

  get SOLIC_CONTA_URL() {
    return `${environment.API_CONTA_CORRENTE}/api/SolicConta/v1/`;
  }

  constructor(private httpClient: HttpClient) {}

  consultarContaPor(tipoConsulta: 'conta' | 'cpf', num) {
    return this.httpClient.get<any>(
      this.CONTA_URL + `consultar-por-${tipoConsulta}/${num}`
    );
  }

  consultarPacoteTarifas() {
    return this.httpClient.get<any>(
      this.CONTA_URL + `consultar-pacote-tarifas`
    );
  }

  consultarSolicConta(tipoConsulta: 'codigo' | 'numconta' | 'codconta', num) {
    return this.httpClient.get<any>(
      this.SOLIC_CONTA_URL + `consultar-por-${tipoConsulta}/${num}`
    );
  }
}
