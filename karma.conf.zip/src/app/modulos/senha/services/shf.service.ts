import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { WebApiService } from './web-api.service';

@Injectable({ providedIn: 'root' })
export class ShfService {
  public teclado: Teclado = null;
  public mensagem$: Observable<string>;
  private mensagemSubject: Subject<string>;

  constructor(private webApi: WebApiService) {
    this.mensagemSubject = new Subject<string>();
    this.mensagem$ = this.mensagemSubject.asObservable();
  }

  public ExecutarTeclado(versao: string, parametros: string[] = null) {
    if (this.teclado == null || this.teclado == undefined)
      this.ExecutarPlugin('TecladoVirtual', versao, parametros);
    else this.novaMensagem('o teclado já está em execução');
  }

  public async ExecutarPlugin(
    plugin: string,
    versao: string,
    parametros: string[] = null
  ) {
    var shfStatus: string = '',
      pluginInstalado: boolean,
      versaoInstalada: boolean,
      retornoDownload: string,
      retornoExecucao: string;
    await this.webApi
      .GetStatusShf()
      .then(x => {
        (shfStatus = x);
        console.log(x);
      })
      .catch(e => this.novaMensagem('erro ao se conectar com shf: ' + e));
    if (shfStatus == 'OK') {
      this.novaMensagem(
        "verificando se o plugin '" + plugin + "' está instalado"
      );
      await this.webApi
        .FlagPlugInInstalado(plugin)
        .then(x => (pluginInstalado = x));
      if (pluginInstalado == true) {
        this.novaMensagem('instalado: sim');
        this.novaMensagem(
          "verificando se a versão '" + versao + "' está instalada"
        );
        await this.webApi
          .FlagVersaoInstalada(plugin, versao)
          .then(x => (versaoInstalada = x));
        if (versaoInstalada == true) {
          this.novaMensagem('versão instalada: sim');
          this.tentarExecutar(plugin, versao, parametros);
        } else {
          this.novaMensagem(
            "versão '" +
              versao +
              "' do plugin '" +
              plugin +
              "' não está instalada, iniciando instalação"
          );
          await this.webApi
            .BaixarPlugin(plugin, versao)
            .then(x => (retornoDownload = x));
          if (retornoDownload.substr(0, 2) == 'OK') {
            this.novaMensagem('versão instalada com sucesso');
            this.tentarExecutar(plugin, versao, parametros);
          } else {
            this.novaMensagem(
              'erro ao baixar a versão do plug in: ' + retornoDownload
            );
          }
        }
      } else {
        this.novaMensagem(
          "pluging '" +
            plugin +
            "' não localizado, iniciando download (versão '" +
            versao +
            "')"
        );
        await this.webApi
          .BaixarPlugin(plugin, versao)
          .then(x => (retornoDownload = x));
        if (retornoDownload.substr(0, 2) == 'OK') {
          this.novaMensagem('plugin instalado com sucesso');
          this.tentarExecutar(plugin, versao, parametros);
        } else {
          this.novaMensagem(
            'erro ao baixar a versão do plug in: ' + retornoDownload
          );
        }
      }
    } else {
      this.novaMensagem('status shf não ok:' + shfStatus);
    }
  }

  private async tentarExecutar(
    plugin: string,
    versao: string,
    parametros: string[] = null
  ) {
    this.novaMensagem('tentando executar o plugin');
    var retornoExecucao: string;
    await this.webApi
      .ExecutarPlugin(plugin, versao, parametros)
      .then(x => (retornoExecucao = x));
    if (retornoExecucao.substr(0, 2) == 'OK') {
      this.teclado = new Teclado(versao, parametros, this.webApi);
      console.log(this.teclado);
      this.novaMensagem('pluging executado com sucesso');
    } else {
      this.novaMensagem('erro ao executar o plugin: ' + retornoExecucao);
    }
  }

  private novaMensagem(texto: string) {
    this.mensagemSubject.next(texto);
  }
}

class Teclado {
  public porta: string;
  public versao: string;
  public parametros: string[];

  constructor(
    versao: string,
    parametros: string[] = null,
    private webApi: WebApiService
  ) {
    this.porta = parametros[0];
    this.versao = versao;
    this.parametros = parametros;
  }

  public async buscarStatus(): Promise<string> {
    var retorno: string = '';
    await this.webApi
      .getStatusTeclado(this.porta)
      .toPromise()
      .then(x => (retorno = x))
      .catch(e => (retorno = 'erro ao buscar o status: ' + JSON.stringify(e)));
    return Promise.resolve(retorno);
  }

  public async fechar() {
    var retorno: string = '';
    await this.webApi
      .fecharTeclado(this.porta)
      .toPromise()
      .then(x => (retorno = x))
      .catch(
        e => (retorno = 'erro ao encerrar o teclado: ' + JSON.stringify(e))
      );
    return Promise.resolve(retorno);
  }
}
