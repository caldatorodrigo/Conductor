import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";

@Injectable( {providedIn: "root"} ) export class WebApiService {
    
    constructor(private client:HttpClient) { 
    }

    private sfhUrl :string = "http://localhost:9091/api/";
    private inssUrl:string = "http://localhost:59922/api/";

    public getValidarAlteracao(id:string, nomeSistema:string, cnpjEmpresa:string) {
        return this.client.get<any>(this.inssUrl + "SolicBeneficio/v1/validartrocasenhacartao/" + id + "?nomeSistema=" + nomeSistema + "&cnpjEmpresa=" + cnpjEmpresa);
    }

    public async GetStatusShf():Promise<string> {
        var ret:string = "";
        await this.client.get<any>(this.sfhUrl).toPromise().then(x => ret = x).catch(x => ret = x.statusText);
        return Promise.resolve(ret);
    }

    public ListarPlugins() {
        return this.client.get<any>(this.sfhUrl + "PluginList/");
    }

    public ListarVersoes(plugin:string) {
        return this.client.get<any>(this.sfhUrl + "PluginList/" + plugin);
    }

    public async ExecutarPlugin(plugin:string, versao:string, parametros:string[]):Promise<string> {
        var retorno:string = "NÃO OK";
        await this.client.get<any>(this.getExecuteUrl(plugin, versao, parametros)).toPromise().then( 
            x => {retorno = x.Mensagen == "Plugin [TecladoVirtual] Executado com sucesso" ? "OK" : JSON.stringify(x);}
        )
        .catch( 
            e => {retorno = "erro ao executar o plugin '" + plugin + "' : " + e;} 
        );
        return Promise.resolve(retorno);
    }

    public async BaixarPlugin(plugin:string, versao:string):Promise<string> {
        var retorno:string = "NÃO OK";
        await this.client.get<any>(this.getDownloadUrl(plugin, versao)).toPromise().then( 
            x => {retorno = x.Mensagen == "" ? "OK" : JSON.stringify(x);})
        .catch( 
            e => {retorno = "erro ao baixar o plugin '" + plugin + "' : " + e;} 
        );
        return Promise.resolve(retorno);
    }

    public async FlagPlugInInstalado(plugin:string):Promise<boolean> {
        var existePlugin:boolean = false;
        await this.ListarPlugins().toPromise().then(
            x => {
                for(var i = 0; i < x.length && !existePlugin; i++){
                    if(x[i] == plugin && plugin != "") existePlugin = true;
                }
            }
        );
        return Promise.resolve(existePlugin);
    }

    public async FlagVersaoInstalada(plugin:string, versao:string):Promise<boolean> {
        var existeVersao:boolean = false;
        await this.ListarVersoes(plugin).toPromise().then(
            x => {
                for(var i=0; i < x.length && !existeVersao; i++){
                    if(x[i] == versao && versao != "") existeVersao = true;
                }
            }
        );
        return Promise.resolve(existeVersao);
    }

    public getStatusTeclado(porta:string) {
        return this.client.get<any>("http://localhost:" + porta + "/api/TecladoVirtual/Get?id=1");
    }

    public fecharTeclado(porta:string) {
        return this.client.get<any>("http://localhost:" + porta + "/api/TecladoVirtual/Get?id=2");
    }





    private getExecuteUrl(plugin:string, versao:string, parametros:string[]) {
        if(parametros == null || parametros == undefined) parametros = [];
        return this.sfhUrl + "PluginExecute?value=" + JSON.stringify( {nomePlugin:plugin, versaoPlugin:versao, parametrosPlugin:parametros} );              
    }

    private getDownloadUrl(plugin:string, versao:string) {
        return this.sfhUrl + "PluginDownload?value=" + JSON.stringify( {nomePlugin:plugin, versaoPlugin:versao, parametrosPlugin:[]} );              
    }

}


