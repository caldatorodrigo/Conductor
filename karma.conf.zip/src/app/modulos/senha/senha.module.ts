import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShfService } from './services/shf.service';
import { WebApiService } from './services/web-api.service';

@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ],
  providers: [
    ShfService,
    WebApiService
  ]
})
export class SenhaModule { }
