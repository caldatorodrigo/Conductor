import { PessoaComponent } from './pessoa/pessoa.component';
import { ViewChild } from '@angular/core';
import { compare, util } from '../core/utils/util';
import { PessoaFisicaModel } from '../model/pessoa/pessoa-fisica.model';
import { PessoaEnderecoModel } from '../model/pessoa/pessoa-endereco.model';
import { PessoaEmailModel } from '../model/pessoa/pessoa-email.model';
import { PessoaTelefoneModel } from '../model/pessoa/pessoa-telefone.model';
import { PessoaModel } from '../model/pessoa/pessoa.model';
import { MatTableDataSource, MatCheckboxChange } from '@angular/material';
import { PageScrollService } from 'ngx-page-scroll-core';
import {
  FichaCadastralConfigModule,
  FichaCadastralConfig
} from './pessoa/ficha-cadastral.model';
import { ProcuradorModel } from '../model/beneficio/procurador/procurador.model';

export class SolicitacaoComponent {
  @ViewChild('pessoaComp', { static: false }) pessoaComp: PessoaComponent;

  modelConsulta = {
    numCpf: '',
    chaveProcesso: ''
  };

  showSolicitacoes = false;
  modulesConfig: FichaCadastralConfigModule[] = [];
  dataSources: {
    key: string;
    dataSource: MatTableDataSource<any>;
    displayColumns: string[];
  }[] = [];

  procurador: ProcuradorModel;
  procuradorPessoa: PessoaModel = {} as PessoaModel;

  fichaCadastralActivationPessoa: FichaCadastralConfig = {
    key: 'conta-corrente',
    title: 'FICHA CADASTRAL',
    active: false,
    isNew: false,
    className: 'ficha-cadastral',
    selectedModuleKey: 'dadosPessoais'
  };

  fichaCadastralActivationProcurador: FichaCadastralConfig = {
    key: 'procurador',
    title: 'FICHA CADASTRAL - PROCURADOR',
    active: false,
    isNew: false,
    className: 'ficha-cadastral-procurador',
    selectedModuleKey: 'dadosPessoais'
  };

  constructor(
    public pageScrollService: PageScrollService,
    public document: any
  ) {}

  compareSelect = tipo => compare[tipo];

  startPessoa() {
    return {
      dadosPessoaFisica: {} as PessoaFisicaModel,
      documentos: [],
      patrimonios: [],
      enderecos: [{} as PessoaEnderecoModel],
      relativos: [],
      emails: [{} as PessoaEmailModel],
      telefones: [{} as PessoaTelefoneModel]
    } as PessoaModel;
  }

  activeAndDisabledAll() {
    this.modulesConfig.forEach(m => {
      m.disabledForm = true;
    });
    this.setActiveAll(true);
  }

  setActiveAll(active) {
    this.modulesConfig.forEach(m => {
      m.active = active;
    });
  }

  populateTable(datasourceName, data) {
    this.getDataSource(datasourceName).dataSource.data = data;
  }

  modules(key): FichaCadastralConfigModule {
    return this.modulesConfig.find(el => el.key === key);
  }

  getDataSource = key => this.dataSources.find(ds => ds.key === key);

  enableForm(next) {
    const moduleSelected = this.modules(next);
    moduleSelected.disabledForm = false;
    moduleSelected.active = true;
    this.scrollTo(moduleSelected.className);
    return moduleSelected;
  }

  hasData(dataSource) {
    return this.getDataSource(dataSource) &&
      this.getDataSource(dataSource).dataSource.data &&
      this.getDataSource(dataSource).dataSource.data.length > 0
      ? true
      : false;
  }

  scrollTo(className) {
    setTimeout(() => {
      this.pageScrollService.scroll({
        document: this.document,
        scrollTarget: '.' + className,
        speed: 200
      });
    }, 700);
  }

  hasProcurador() {
    return !!this.procurador;
  }

  changeProcurador(event: MatCheckboxChange) {
    if (event.checked) {
      this.procurador = {} as ProcuradorModel;
      this.fichaCadastralActivationProcurador.active = true;
      this.scrollTo(this.fichaCadastralActivationProcurador.className);
    } else {
      this.procurador = undefined;
      this.fichaCadastralActivationProcurador.active = false;
    }
  }

  abrirFichaCadastralPessoa(isNew = false) {
    this.fichaCadastralActivationPessoa.active = true;
    this.fichaCadastralActivationPessoa.isNew = isNew;
    /* this.solicitacao.pessoa.dadosPessoaFisica.numCpf = util.onlyDigits(
        this.modelConsulta.numCpf
      ); */
    this.scrollTo(this.fichaCadastralActivationPessoa.className);
  }

  prosseguir(next) {
    const selectedModule = this.enableForm(next);
    if (this.pessoaComp) {
      this.pessoaComp.modulesConfig
        .filter(m => m.key !== selectedModule.key)
        .forEach(m => (m.disabledForm = true));
    }
    this.modulesConfig
      .filter(m => m.key !== selectedModule.key)
      .forEach(m => (m.disabledForm = true));
    if (selectedModule.prosseguir) {
      selectedModule.prosseguir(next);
    }
  }

  requiredConsulta(campo) {
    const empty = {
      chaveProcesso: util.isEmptyNullOrUndefined(
        this.modelConsulta.chaveProcesso
      ),
      numCpf: util.isEmptyNullOrUndefined(this.modelConsulta.numCpf)
    };

    switch (campo) {
      case 'numCpf':
        return empty.chaveProcesso;
      case 'chaveProcesso':
        return empty.numCpf;
      default:
        return true;
    }
  }

  fecharFichaCadastralPessoa() {
    this.fichaCadastralActivationPessoa.active = false;
    this.fichaCadastralActivationProcurador.active = false;
  }

  fecharModulos() {
    this.modulesConfig.forEach(item => {
      item.active = false;
      item.disabledForm = true;
    });
  }

  clearDataSources() {
    this.dataSources.forEach(ds => (ds.dataSource.data = []));
  }
}
