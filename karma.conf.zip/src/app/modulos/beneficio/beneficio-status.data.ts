import { StatusModel } from 'src/app/model/status/status.model';

export const STATUS_SOLICITACAO_BENEFICIO: StatusModel[] = [
  {
    codigo: 24,
    descricao: 'PASSO 1 - PENDENTE FORMA PAGTO',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 25,
    descricao: 'PASSO 2 - PENDENTE FICHA CLIENTE',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 26,
    descricao: 'PASSO 3 - PENDENTE FICHA PROCURADOR',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 27,
    descricao: 'PASSO 4 - PENDENTE CAPTURA CARTAO',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 28,
    descricao: 'PASSO 5 - PENDENTE CAPTURA DOCUMENTOS',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 29,
    descricao: 'PASSO 6 - AGUARDANDO ANALISE',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 30,
    descricao: 'PASSO 7 - RECUSADO ANALISE',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 31,
    descricao: 'PASSO 8 - APROVADO ANALISE',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 32,
    descricao: 'PASSO 9 - PENDENTE SENHA CARTAO',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 33,
    descricao: 'SOLICITACAO CONCLUIDA',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  },
  {
    codigo: 34,
    descricao: 'SOLICITACAO CANCELADA',
    ativo: true,
    tipo: {
      codigo: 21,
      descricao: 'SOLICITACAO BENEFICIO',
      ativo: true
    }
  }
];
