import { Component, OnInit, Inject, ViewChild, isDevMode } from '@angular/core';
import {
  MatTableDataSource,
  MatCheckboxChange,
  MatDialog
} from '@angular/material';
import { AlertService } from 'src/app/shared/services/alert.service';
import { util } from 'src/app/core/utils/util';
import { PageScrollService } from 'ngx-page-scroll-core';
import { DOCUMENT } from '@angular/common';
import { SolicitacaoContaCorrenteModel } from './../../../../model/solicitacao/conta-corrente/solicitacao-conta-corrente.model';
import { PessoaModel } from 'src/app/model/pessoa/pessoa.model';
import { PessoaService } from 'src/app/modulos/pessoa/services/pessoa.service';
import { FichaCadastralConfig } from 'src/app/modulos/pessoa/ficha-cadastral.model';
import { ProcuradorModel } from 'src/app/model/beneficio/procurador/procurador.model';
import { BeneficioSolicitacaoService } from 'src/app/modulos/beneficio/services/beneficio-solicitacao.service';
import { PACOTE_TARIFAS } from 'src/app/data/pacote-tarifas.data';
import { SolicitacaoComponent } from 'src/app/modulos/solicitacao.component';
import { BeneficioService } from '../../services/beneficio.service';
import { BeneficioDataModel } from 'src/app/model/beneficio/beneficio-data.model';
import { SolicitacaoBeneficioDataModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-data.model';
import { TipoMeioPagamentoModel } from 'src/app/model/tipos/tipo-meio-pagamento.model';
import { BeneficioPagamentoService } from '../../services/beneficio-pagamento.service';
import { BeneficioPagamentoModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento.model';
import { FormBuilder } from '@angular/forms';
import { STATUS_SOLICITACAO_BENEFICIO } from '../../beneficio-status.data';
import { SolicitacaoBeneficioRequestModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-request.model';
import { BeneficioGpbService } from '../../services/beneficio-gpb.service';
import { ShfService } from 'src/app/modulos/senha/services/shf.service';
import { environment } from 'src/environments/environment';
import { WebApiService } from 'src/app/modulos/senha/services/web-api.service';
import { CapturaCartaoModel } from 'src/app/model/beneficio/captura/captura-cartao.model';
import { SolicitacaoBeneficioDocumentoModel } from 'src/app/model/solicitacao/beneficio/documento/solicitacao-beneficio-documento.model';
import { DigitalizacaoComponent } from 'src/app/modulos/digitalizacao/components/digitalizacao/digitalizacao.component';
import { CapturaImagemComponent } from 'src/app/modulos/captura-imagem/captura-imagem.component';
import { SolicitacaoBeneficioDocumentoResponse } from 'src/app/model/documento/solicitacao-beneficio-documento-response.model';

@Component({
  selector: 'app-beneficio',
  templateUrl: './beneficio.component.html',
  styleUrls: ['./beneficio.component.scss']
})
export class BeneficioComponent extends SolicitacaoComponent implements OnInit {
  constructor(
    public pageScrollService: PageScrollService,
    @Inject(DOCUMENT) public document: any,
    private alertService: AlertService,
    private beneficioService: BeneficioService,
    private beneficioSolicitacaoService: BeneficioSolicitacaoService,
    private pessoaService: PessoaService,
    private beneficioPagamentoService: BeneficioPagamentoService,
    private beneficioGpbService: BeneficioGpbService,
    private plugInServ: ShfService,
    private webApi: WebApiService,
    private dialog: MatDialog
  ) {
    super(pageScrollService, document);

    this.dataSources = [
      {
        key: 'beneficio',
        dataSource: new MatTableDataSource<BeneficioDataModel>([]),
        displayColumns: [
          'nb',
          'cpf',
          'nome',
          'formaPagamento',
          'dataConcessao',
          'status',
          'acoes'
        ]
      },
      {
        key: 'solicitacao',
        dataSource: new MatTableDataSource<SolicitacaoBeneficioDataModel>([]),
        displayColumns: [
          'numSolicitacao',
          'codBeneficio',
          // 'cpf',
          // 'nome',
          'status',
          'dados',
          'analise',
          'senhaCartao'
        ]
      }
    ];

    this.modulesConfig = [
      {
        key: 'provaVida',
        disabledForm: true,
        className: 'prova-de-vida',
        title: 'Prova de Vida',
        active: false
      },
      {
        key: 'formaPagamento',
        disabledForm: true,
        className: 'forma-pagamento',
        title: 'Forma de Pagamento',
        active: false
      },
      {
        key: 'procurador',
        disabledForm: true,
        className: 'procurador',
        title: 'Dados Procurador',
        active: false
      },
      {
        key: 'capturaCartoes',
        disabledForm: true,
        className: 'captura-cartoes',
        title: 'Captura de Cartões',
        active: false
      },

      {
        key: 'capturaDocumentos',
        disabledForm: true,
        className: 'captura-documentos',
        title: 'Captura de Documentos',
        active: false
      }
    ];

    (this.fichaCadastralActivationPessoa.title =
      'FICHA CADASTRAL - PESSOA FÍSICA'),
      (this.fichaCadastralActivationPessoa.className =
        'ficha-cadastral-beneficio'),
      (this.fichaCadastralActivationPessoa.end = pessoa => {
        console.log('finish ficha cadastral pessoa');
        this.getBeneficioPagamento();
        if (this.solicitacaoAtiva.status.codigo === 25) {
          this.alterarStatus(27);
        }
      });

    this.fichaCadastralActivationProcurador.end = pessoaProcurador => {
      console.log('pessoaProcurador => ', pessoaProcurador);
    };
  }
  formaPagamentoFormSubmitted = false;
  tipoMeioPagamentoList = [];
  tipoMeioPagamentoPrincipal;
  solicPagamentoPrincipal: BeneficioPagamentoModel;
  solicitacaoAtiva: SolicitacaoBeneficioDataModel;
  beneficioAtivo: BeneficioDataModel;
  promisesFormasPagamento: {
    isPut: boolean;
    model: BeneficioPagamentoModel;
  }[] = [];
  beneficioPagamentoCapturaList = [];
  solicitacaoBeneficioDocumentoList: Array<SolicitacaoBeneficioDocumentoModel>;
  isContaCorrente = false;

  mapCartoesCapturados = new Map<string, CapturaCartaoModel>();
  enableProsseguirCapturaCartao = false;
  isBiometria = false;
  
  /* CREFISA METHODS */
  crefisa = {
    manualOuBiometricoValue: 'manual',
    ativarTeclado: () => {
      /*this.plugInServ.teclado
      .buscarStatus()
      .then(statusTeclado =>
        console.log('1-STATUS TECLADO VIRTUAL =======>' + statusTeclado)
      );
*/
      // this.fecharTeclado();
      this.plugInServ.mensagem$.subscribe(
        x => {
          if (x === 'pluging executado com sucesso') {
            console.log(
              'plugin executado VERSÃO:' + this.plugInServ.teclado.versao
            );
          } else {
            console.log(x);
          }
        },
        () => {
          this.plugInServ.teclado
            .buscarStatus()
            .then(statusTeclado =>
              console.log('2-STATUS TECLADO VIRTUAL =======>' + statusTeclado)
            );
        }
      );
      /*this.plugInServ.ExecutarPlugin('TecladoVirtual', 'v4.0', [
      '8083',
      '61033106000186',
      '626064',
      'OP_PWD_4'
    ]);*/
      this.plugInServ.ExecutarTeclado(
        environment.PLUGINS.TECLADO_VIRTUAL.VERSAO,
        environment.PLUGINS.TECLADO_VIRTUAL.PARAMETROS
      );

      this.webApi
        .getStatusTeclado(environment.PLUGINS.TECLADO_VIRTUAL.PARAMETROS[0])
        .subscribe(res => {
          console.log(res);
        });
    },
    trocarItemBeneficio: () => {
      let teste: BeneficioDataModel; // ::: cpf:17757432847, nb:1499177893
      console.clear();
      console.log('CHAMOU');
      this.beneficioGpbService
        .obtemDetalheDeBeneficio(
          Number.parseInt(this.beneficioAtivo.numBeneficio)
        )
        .subscribe(
          r => {
            console.log('RECEBEU');
            console.log(JSON.stringify(r));
          },
          e => {
            console.log(JSON.stringify(e));
          }
        );
    },
    buscarStatus: () => {
      this.plugInServ.teclado
        .buscarStatus()
        .then(x => console.log('TESTE TECLADO VIRTUAL ======= ' + x));
    },
    fecharTeclado: () => {
      this.plugInServ.teclado.fechar().then(x => console.log(x));
    },
    // ::: botão de captura do cartão
    capturaCartao: solicBeneficioPagamento => {
      this.alertService.setLoading(true);
      let dadosCapturaCartao: CapturaCartaoModel = {};
      dadosCapturaCartao.solicitacaoPagamento = Object.assign(
        {},
        solicBeneficioPagamento
      );
      dadosCapturaCartao.pessoa = Object.assign(
        {},
        this.solicitacaoAtiva.pessoa
      );

      this.beneficioSolicitacaoService
        .inserirSolicitacaoBeneficioCapturaCartao(dadosCapturaCartao)
        .subscribe(
          r => {
            //if (isDevMode()) r.data.idContaCartao = "1"; // ::: RETIRAR! é apenas para testes
            if (
              r.data.idContaCartao != null &&
              r.data.idContaCartao != undefined &&
              r.data.idContaCartao != ''
            ) {
              dadosCapturaCartao.solicitacaoPagamento.numIdcontacartao =
                r.data.idContaCartao;
              this.mapCartoesCapturados.set(
                '' +
                  dadosCapturaCartao.solicitacaoPagamento.tipoMeioPagamento
                    .codigo,
                dadosCapturaCartao
              );
              solicBeneficioPagamento.numIdcontacartao = r.data.idContaCartao;
              this.solicPagamentoPrincipal = solicBeneficioPagamento;
              this.enableProsseguirCapturaCartao = true;
            } else if (
              r.data.urlCallBack != undefined &&
              r.data.urlCallBack != null &&
              r.data.urlCallBack != ''
            ) {
              window.open(r.data.urlCallBack);
            } else {
              console.log(
                'A API NÃO RETORNOU O ID DO CARTÃO E NEM URL. InssApi, controller SolicBeneficio, método CapturarCartao'
              );
              console.log(
                'OBJETO solicitacaoBeneficioPagamento: \n' +
                  JSON.stringify(solicBeneficioPagamento)
              );
              console.log('OBJETO retorno da chamada: \n' + JSON.stringify(r));
            }
            this.alertService.setLoading(false);
          },
          e => {
            console.log(
              'OCORREU UM ERRO AO CHAMAR InssApi, controller SolicBeneficio, método CapturarCartao'
            );
            console.log(
              'OBJETO solicitacaoBeneficioPagamento: \n' +
                JSON.stringify(solicBeneficioPagamento)
            );
            console.log('OBJETO retorno da chamada: \n' + JSON.stringify(e));
            this.alertService.setLoading(false);
          }
        );
    },
    executarConfiguracao: (
      codConfiguracao: number,
      codSolicBeneficioDoc: number,
      desConfigValor: string
    ) => {
      console.clear();
      console.log(
        'codConfiguracao: ' +
          codConfiguracao +
          '\ncodSolicBeneficioDoc: ' +
          codSolicBeneficioDoc +
          '\ndesConfigValor: ' +
          desConfigValor
      );

      let params: string =
        codConfiguracao === 4
          ? '?codTipoDocumento=' +
            '55' +
            '&codSolicBeneficioDoc=' +
            codSolicBeneficioDoc
          : codConfiguracao === 5
          ? '?codTipoDocumento=' +
            '55' +
            '&codSolicBeneficioDoc=' +
            codSolicBeneficioDoc
          : codConfiguracao === 1
          ? '/' + codSolicBeneficioDoc + '/' + '55'
          : '';

      if (params !== '') {
        this.beneficioSolicitacaoService
          .executarConfiguracao(desConfigValor + params)
          .subscribe(
            r => {
              console.log(JSON.stringify(r));
            },
            e => {
              console.log(JSON.stringify(e));
            }
          );
      } else {
        if (codConfiguracao === 2) {
          let solBenPag: BeneficioPagamentoModel = this
            .beneficioPagamentoCapturaList[0];

          const params = {
            CodLoja: solBenPag.loja.codLoja,
            codigoSistema: '2',
            codigoDocumento: '20',
            codigoFuncao: '7',
            codigoExterno: '34803281807',
            codigoUsuarioUpload: '203419',
            origem: 'CPF121249',
            nomeArquivo: 'RG121249.34803281807.20191211_121249813.PDF',
            diretorioDestinoDoc: '\\crefisa.com.br\rootgedchk"',
            urlImg: 'http:centraldenegocios.adobenet.com.br/fotos/',
            endPointBanco: 'https://teste.com.br/IncluirDocumento'
          };
          let paramsDigitalizacao: string = JSON.stringify(params);
          /* let paramsDigitalizacao: string =
            '{ "CodLoja": "' +
            solBenPag.loja.codLoja +
            '", "codigoSistema": "2",  "codigoDocumento": "20",  "codigoFuncao": "7",  "codigoExterno": "34803281807",  "codigoUsuarioUpload": "203419",  "origem": "CPF121249", "nomeArquivo": "RG121249.34803281807.20191211_121249813.PDF", "diretorioDestinoDoc": "\\\\\\\\crefisa.com.br\\\\root\\\\gedchk\\\\", "urlImg" : "http:\\\\centraldenegocios.adobenet.com.br/fotos/", "endPointBanco" : "https://teste.com.br/IncluirDocumento" }'; */
          let dadosB64: string = window.btoa(paramsDigitalizacao);
          this.dialog
            .open(DigitalizacaoComponent, {
              disableClose: true,
              data: { dadosBase64: dadosB64 }
            })
            .afterClosed()
            .subscribe(result => {
              console.log(result);
            });
        } else if (codConfiguracao === 41) {
          let solBenPag: BeneficioPagamentoModel = this
            .beneficioPagamentoCapturaList[0];
          let paramsCapturaFoto: string =
            '{ "codigoSolicitacao": "' +
            solBenPag.codSolicbeneficio +
            '", "codigoDocumento": "11" }';
          this.dialog
            .open(CapturaImagemComponent, {
              disableClose: true,
              data: { dadosBase64: btoa(paramsCapturaFoto) }
            })
            .afterClosed()
            .subscribe(result => {
              console.log(result);
            });
        } else {
          console.log('codConfiguração não reconhecido');
        }
      }
    },
    exibirBotaoConfiguracao: (
      codConfiguracao: number,
      solicitacao: SolicitacaoBeneficioDocumentoModel,
      configuracoesList: any,
      biometrico: boolean
    ) => {
      // console.log(JSON.stringify(configuracoesList));

      let temGerar = false;
      for (let i = 0; i < configuracoesList.length && !temGerar; i++) {
        temGerar = configuracoesList[i].itemConfiguracao.codigo === 1;
      }
      if (codConfiguracao === 1) {
        // GERAR
        return true;
      } else if (codConfiguracao === 2) {
        // DIGITALIZAR
        return !biometrico ? true : solicitacao.caminhoArquivo !== null;
      } else if (codConfiguracao === 3) {
        // VISUALIZAR
        return solicitacao.caminhoArquivo !== null;
      } else if (codConfiguracao === 4) {
        // ENVIARGRAFOMETRIA
        return biometrico
          ? temGerar && solicitacao.digitalizacao === true
          : solicitacao.digitalizacao === true;
      } else if (codConfiguracao === 5) {
        // RECEBERGRAFOMETRIA
        return biometrico
          ? temGerar && solicitacao.enviado === true
          : solicitacao.enviado === true;
      } else if (codConfiguracao === 6) {
        // OBRIGATÓRIO
        return false;
      } else if (codConfiguracao === 41) {
        // CAPTURAR FOTO
        return true;
      }
    },

    /*  :::
          cpf: 17757432847
          a tabela OWR_NFCBCO.TB_INSS_SOLICBENEFICIODOC tem os flags de enviado, recebido, etc
          exceto para gerado, a gente sabe se foi gerado quando o campo 'des_caminhocarquivo' !== null
          quando todo processo for finalizado a gente tem que atualizar o campo cod_status da OWR_NFCBCO.
          TB_INSS_SOLICBENEFICIODOC para 42(entregue, OWR_NFCBCO.TB_INSS_STATUS)
      */

    manualOuBiometricoOnChange: () => {
      /// Assim que for selecionado manual ou biometrico, varrer a listagem e marcar todos
      for (let i = 0; i < this.solicitacaoBeneficioDocumentoList.length; i++) {
          this.solicitacaoBeneficioDocumentoList[i].biometria = this.isBiometria;
      }
      return;
    },
    prosseguirParaDocumentos: async () => {
      // ::: cpf:17757432847 nb:1499177893 | cpf:53836043327 nb:7003226740
      this.alertService.setLoading(true);

      util.promiseMapObject(this.beneficioSolicitacaoService
        .solicBeneficioPgtoAlterar(this.solicPagamentoPrincipal))
        .catch(e => {
          this.alertService.dispatch(
            'Erro ao atualizar os dados. Não é possível prosseguir.'
          );
          return;
        }).finally(() => {
          this.alertService.setLoading(false);
        });
      /*if (retornoPositivo) {
          console.clear();
          console.log(JSON.stringify(this.solicitacaoBeneficio));
          await this.beneficioSolicitacaoService.solicBeneficioInserirDocs(this.solicitacaoBeneficio).toPromise().then(r => {
              retornoPositivo = (r.data != undefined && r.data != null && r.data == true);
          }).catch(e => {
              retornoPositivo = false;
          });
      }*/

      this.beneficioSolicitacaoService
        .getSolicitacaoBeneficioDocumento(
          '' + this.solicitacaoAtiva.codSolicbeneficio
        )
        .subscribe(
          (data: any) => {
            const solicitacaoBeneficioDocumentoResponse = data as SolicitacaoBeneficioDocumentoResponse;
            const solicitacaoBeneficioDocumentoList = solicitacaoBeneficioDocumentoResponse.data as SolicitacaoBeneficioDocumentoModel[];
            console.log(
              'prosseguirParaDocumentos.solicitacaoBeneficioDocumentoList=' +
                JSON.stringify(this.solicitacaoBeneficioDocumentoList)
            );

            for (
              var x: number = 0;
              x < this.solicitacaoBeneficioDocumentoList.length;
              x++
            ) {
              console.log(
                'item[' +
                  x +
                  ']' +
                  JSON.stringify(this.solicitacaoBeneficioDocumentoList[x])
              );
              for (
                var y: number = 0;
                y <
                this.solicitacaoBeneficioDocumentoList[x].documento.configuracao
                  .length;
                y++
              ) {
                console.log(
                  'configuracao[' +
                    y +
                    ']=' +
                    JSON.stringify(
                      this.solicitacaoBeneficioDocumentoList[x].documento
                        .configuracao[y]
                    )
                );
              }
              console.log(
                '-------------------------------------------------------\n================================================================='
              );
            }
            // this.dadosCapturaDoc.setValue({
            //   // tituloDocumento: this.solicitacaoBeneficioDocumentoResponse.data[0].documento.descricao,
            //   tituloDocumento: this.solicitacaoBeneficioDocumentoList[0].documento.descricao,
            //   statusDocumento: this.solicitacaoBeneficioDocumentoList[0].status.descricao,
            //   botaoAcaoDocumento: this.solicitacaoBeneficioDocumentoList[0].documento.configuracao[0].itemConfiguracao.descricao,
            // });
            console.log(
              'CAPTURA-DOCUMENTO' +
                this.solicitacaoBeneficioDocumentoList[0].documento.descricao
            );
            if (this.solicitacaoAtiva.status.codigo === 27) {
              this.alterarStatus(28);
            }
          },
          e => {
            console.log(
              '+++++++ error prosseguirParaDocumentos ++++++++++ ' + e
            );
            this.alertService.setLoading(false);
          },
          () => {
            console.log('+++++++ completed prosseguirParaDocumentos++++++++++');
            this.alertService.setLoading(false);
          }
        );
      this.enableDocumentos();
    }
  };

  enableDocumentos() {
    if (this.solicitacaoAtiva.status.codigo === 27) {
      this.alterarStatus(28);
    }
    this.prosseguir('capturaDocumentos');
  }

  getDocumentos() {
    this.alertService.setLoading(true);
    util
      .promiseMapArray(
        this.beneficioSolicitacaoService.getSolicitacaoBeneficioDocumento(
          '' + this.solicitacaoAtiva.codSolicbeneficio
        )
      )
      .then(data => {
        this.solicitacaoBeneficioDocumentoList = data;
      })
      .finally(() => {
        this.alertService.setLoading(false);
      });
  }

  ngOnInit() {
    this.procuradorPessoa = this.startPessoa();

    util
      .promiseMapArray(this.pessoaService.getAllTipoMeioPagamento())
      .then(res => (this.tipoMeioPagamentoList = res))
      .finally(() => this.alertService.setLoading(false));
  }

  getBeneficioPagamento() {
    this.alertService.setLoading(true);
    util
      .promiseMapArray(
        this.beneficioPagamentoService.getBeneficioPagamentoByCodigoSolicitacaoBeneficio(
          this.solicitacaoAtiva.codSolicbeneficio
        )
      )
      .then(res => (this.beneficioPagamentoCapturaList = res))
      .finally(() => {
        this.alertService.setLoading(false);
        this.prosseguir('capturaCartoes');
      });
  }

  manualOuBiometricoSetValue(manualOuBiometrico : boolean){
    this.isBiometria = manualOuBiometrico;
  } 

  resetPage() {
    this.fichaCadastralActivationPessoa.active = false;
    this.fichaCadastralActivationPessoa.disabledAll = false;
    this.fichaCadastralActivationPessoa.openAll = false;
    this.setActiveAll(false);
  }

  pesquisar(form) {
    this.resetPage();
    if (form.valid) {
      this.fecharFichaCadastralPessoa();
      this.fecharModulos();
      this.clearDataSources();
      this.showSolicitacoes = false;
      this.alertService.setLoading(true);
      if (util.isEmptyNullOrUndefined(this.modelConsulta.numCpf)) {
        util
          .promiseMapArray(
            this.beneficioService.consultarBeneficioPor(
              'numbeneficio',
              util.onlyDigits(this.modelConsulta.chaveProcesso)
            )
          )
          .then(res => this.populateTable('beneficio', res))
          .finally(() => this.alertService.setLoading(false));
      } else {
        util
          .promiseMapArray(
            this.beneficioService.consultarBeneficioPor(
              'cpf',
              util.onlyDigits(this.modelConsulta.numCpf)
            )
          )
          .then(res => this.populateTable('beneficio', res))
          .finally(() => {
            this.alertService.setLoading(false);
          });
      }
    } else if (
      util.isEmptyNullOrUndefined(
        this.modelConsulta.numCpf || this.modelConsulta.chaveProcesso
      )
    ) {
      this.alertService.dispatch('Por favor preencha uma das informações');
    } else {
      this.alertService.dispatch('Número de CPF inválido');
    }
  }

  buscarSolicitacoes(beneficio: BeneficioDataModel, newSolicitacao?) {
    this.beneficioAtivo = beneficio;
    this.alertService.setLoading(true);
    this.modules('provaVida').active = false;
    this.modules('provaVida').disabledForm = true;
    util
      .promiseMapArray(
        this.beneficioSolicitacaoService.getSolicitacaoBeneficioByCodigoBeneficio(
          beneficio.codBeneficio
        )
      )
      .then((res: SolicitacaoBeneficioDataModel[]) => {
        this.populateTable(
          'solicitacao',
          res.sort((a, b) => (this.statusReadyOnly(a) ? -1 : 0))
        );
        if (res.length > 0) {
          this.showSolicitacoes = true;
          this.scrollTo('panel-solicitacoes');
          const novaSolicitacao = res.find(
            solic => solic.codSolicbeneficio === newSolicitacao
          );
          if (novaSolicitacao) {
            this.selecionarSolicitacao(novaSolicitacao);
          }
        }
      })
      .finally(() => {
        this.alertService.setLoading(false);
      });
  }

  atualizarSolicitacaoAtiva() {
    this.alertService.setLoading(true);
    util
      .promiseMapArray(
        this.beneficioSolicitacaoService.getSolicitacaoBeneficioByCodigoSolicitacao(
          this.solicitacaoAtiva.codSolicbeneficio
        )
      )
      .then(res => {
        if (res.length > 0) {
          this.solicitacaoAtiva = res[0];
          this.tipoMeioPagamentoPrincipal = this.beneficioPagamentoPrincipal(
            this.solicitacaoAtiva
          ).tipoMeioPagamento.codigo;

          this.abrirFichaCadastralPessoa();
        }
      })
      .finally(() => {
        this.alertService.setLoading(false);
      });
  }

  beneficioPagamentoPrincipal = (
    item: BeneficioDataModel | SolicitacaoBeneficioDataModel
  ): BeneficioPagamentoModel | any =>
    item.formaPagamento.find(el => el.principal) as any;

  changeFormaPagamento($event) {
    this.formaPagamentoFormSubmitted = false;
    this.promisesFormasPagamento = [];
    let novaFormaPagamento = this.solicitacaoAtiva.formaPagamento.find(
      fp => fp && fp.tipoMeioPagamento.codigo === $event
    );

    if (!novaFormaPagamento) {
      const formaAtualPrincipal = this.beneficioPagamentoPrincipal(
        this.solicitacaoAtiva
      );
      if (!!formaAtualPrincipal) {
        formaAtualPrincipal.principal = false;
        this.promisesFormasPagamento.push({
          isPut: true,
          model: formaAtualPrincipal
        });
      }
      novaFormaPagamento = {} as BeneficioPagamentoModel;
      novaFormaPagamento.codSolicbeneficio = this.solicitacaoAtiva.codSolicbeneficio;
      novaFormaPagamento.principal = true;

      this.promisesFormasPagamento.push({
        isPut: false,
        model: novaFormaPagamento
      });
      // criar novo
    } else {
      this.solicitacaoAtiva.formaPagamento.forEach(el => {
        const isPrincipalNow = el.tipoMeioPagamento.codigo === $event;
        if (
          (!el.principal && isPrincipalNow) ||
          (el.principal && !isPrincipalNow)
        ) {
          el.principal = !el.principal;
          this.promisesFormasPagamento.push({
            isPut: true,
            model: el
          });
        }
      });
    }

    // this.tipoMeioPagamentoPrincipal = novaFormaPagamento.tipoMeioPagamento;
    this.tipoMeioPagamentoPrincipal =
      novaFormaPagamento.tipoMeioPagamento.codigo;
  }

  newPromise(promise: Promise<any>): Promise<any> {
    return new Promise((resolve, reject) =>
      promise.then(resolve).catch(reject)
    );
  }

  salvarFormaPagamento() {
    this.formaPagamentoFormSubmitted = true;
    if (this.tipoMeioPagamentoPrincipal) {
      if (this.promisesFormasPagamento.length > 0) {
        this.alertService.setLoading(true);
        Promise.all(
          this.promisesFormasPagamento.map(el => {
            return util.promiseMapObject(
              this.beneficioPagamentoService.salvarSolicitacaoBeneficioPagamento(
                el.model,
                el.isPut
              )
            );
          })
        )
          .then(res => {
            this.isContaCorrente = this.tipoMeioPagamentoPrincipal === 22;
          })
          .finally(() => {
            this.alertService.setLoading(false);
            this.atualizarSolicitacaoAtiva();
            // this.modules('formaPagamento').disabledForm = true;
          });
      } else {
        // this.modules('formaPagamento').disabledForm = true;
        this.abrirFichaCadastralPessoa();
      }

      if (this.solicitacaoAtiva.status.codigo === 24) {
        this.alterarStatus(25);
      }
    } else {
      this.alertService.dispatch('Escolha uma forma de pagamento');
    }
  }

  ativarBenficio() {
    this.alertService.setLoading(true);
    this.beneficioSolicitacaoService
      .postSolicitacaoBeneficio(this.beneficioAtivo)
      .toPromise()
      .then(res => {
        if (res.status) {
          this.buscarSolicitacoes(this.beneficioAtivo, res.data);
        } else {
          this.alertService.dispatch(
            'Houve um erro ao iniciar uma nova solicitação'
          );
        }
      })
      .finally(() => this.alertService.setLoading(false));
  }

  dadosSolicitacao(solicitacao, disabledAll) {}

  statusReadyOnly = solic =>
    [29, 31, 32, 33, 34].filter(status => solic.status.codigo === status)
      .length > 0;

  selecionarSolicitacao(solic) {
    this.resetPage();
    this.solicitacaoAtiva = solic;
    if (this.statusReadyOnly(solic)) {
      this.fichaCadastralActivationPessoa.active = true;
      this.fichaCadastralActivationPessoa.openAll = true;
      this.fichaCadastralActivationPessoa.disabledAll = true;
      this.activeAndDisabledAll();
      this.scrollTo(this.modules('formaPagamento').className);
    } else {
      this.prosseguir('formaPagamento');
    }

    const pgmtoPrincipal = this.beneficioPagamentoPrincipal(
      this.solicitacaoAtiva
    );

    if (pgmtoPrincipal) {
      this.tipoMeioPagamentoPrincipal = pgmtoPrincipal.tipoMeioPagamento.codigo;
      this.isContaCorrente = this.tipoMeioPagamentoPrincipal === 22;
    }
    this.getDocumentos();
  }

  disableBtnAtivarBeneficio = () =>
    !!this.getDataSource('solicitacao').dataSource.data.find(
      el => el.status.codigo !== 34 || el.status.codigo !== 33
    );

  alterarStatus(cod) {
    const novoStatus = STATUS_SOLICITACAO_BENEFICIO.find(s => s.codigo === cod);
    const request: SolicitacaoBeneficioRequestModel = {} as SolicitacaoBeneficioRequestModel;
    request.data = Object.assign(this.solicitacaoAtiva, {});
    request.data.status = novoStatus;
    this.alertService.setLoading(true);
    util
      .promiseMapObject(
        this.beneficioSolicitacaoService.atualizarStatusSolicitacaoBeneficio(
          request
        )
      )
      .then(res => {
        console.log(`ALTERACAO_STATUS_TO_${cod}:`, novoStatus.descricao);
        if (res) {
          this.solicitacaoAtiva.status = novoStatus;
        }
      })
      .finally(() => this.alertService.setLoading(false));
  }

  showProvaDeVida(beneficio) {
    this.beneficioAtivo = beneficio;
    this.prosseguir('provaVida');
  }
}
