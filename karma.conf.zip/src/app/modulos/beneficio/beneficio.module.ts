import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BeneficioSolicitacaoService } from './services/beneficio-solicitacao.service';
import { BeneficioPagamentoService } from './services/beneficio-pagamento.service';
import { MatIconModule } from '@angular/material';
import { BeneficioGpbService } from './services/beneficio-gpb.service';
import { BeneficioComponent } from './pages/beneficio/beneficio.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { PessoaModule } from '../pessoa/pessoa.module';

@NgModule({
  declarations: [BeneficioComponent],
  imports: [CommonModule, SharedModule, PessoaModule],
  exports: [BeneficioComponent],
  providers: [
    BeneficioSolicitacaoService,
    BeneficioPagamentoService,
    BeneficioGpbService
  ]
})
export class BeneficioModule {}
