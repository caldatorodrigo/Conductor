import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders, HttpErrorResponse } from "@angular/common/http";
import { environment } from "src/environments/environment";
import { Observable, throwError, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';

 var httpOptions = {
  headers: new HttpHeaders()
};

@Injectable()
export class BeneficioService {
  API_INSS_SERVER_NAME: string;
  BASE_URL_BENEFICIO_API = "api/Beneficio/v1";

  constructor(private httpClient: HttpClient) {
    this.API_INSS_SERVER_NAME = environment.API_INSS_SERVER_NAME;
    httpOptions.headers.set("Access-Control-Allow-Origin", "*");
    httpOptions.headers.set("Content-Type", "application/json");
  }

  public getBeneficio(numeroBeneficio: string, cpf: string) {
    if (numeroBeneficio != undefined) {
      numeroBeneficio = this.getDigitos(numeroBeneficio);
      return this.getBeneficioByNumeroBeneficio(numeroBeneficio);
    }

    if (cpf != undefined) {
      cpf = this.getDigitos(cpf);
      return this.getBeneficioByCpf(cpf);
    }
  }

  public getBeneficioDetalhe(numeroBeneficio: string): Observable<any> {
    return this.httpClient.get(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_API}/detalhar-beneficio/${numeroBeneficio}`,
      httpOptions
    )/* .pipe(catchError(this.handleError)); */
  }

  private getBeneficioByNumeroBeneficio(numeroBeneficio: string): Observable<any> {
    return this.httpClient.get(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_API}/consultar-por-numbeneficio/${numeroBeneficio}/true`,
      httpOptions
    )/* .pipe(catchError(this.handleError)); */
  }

  consultarBeneficioPor(tipoConsulta: 'numbeneficio' | 'cpf', num) {
    return this.httpClient.get<any>(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_API}/consultar-por-${tipoConsulta}/${num}/true`
    );
  }

  private getBeneficioByCpf(cpf: string): Observable<any> {
    return this.httpClient.get(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_API}/consultar-por-cpf/${cpf}/true`,
      httpOptions
    )/* .pipe(catchError(this.handleError)); */
  }

  getDigitos(value) {
    return value.replace(/\D/g, "");
  }


  public handleError(error: HttpErrorResponse) {
    let errorMessage = "Unknown error!";
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

  public handleErrorT(error: HttpErrorResponse) {
    return Observable.throw(error.message||"Server Error");
  }

}
