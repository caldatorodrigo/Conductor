import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpErrorResponse } from '@angular/common/http';
import { environment } from "src/environments/environment";
import { throwError, Observable, Subject, BehaviorSubject } from 'rxjs';
import { BeneficioPagamentoModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento.model';
import { BeneficioPagamentoRequestModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento-request.model';
import { BeneficioPagamentoResponseModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento-response-data.model';
import { map } from 'rxjs/operators';
import { resolve } from 'url';

var httpOptions = {
  headers: new HttpHeaders()
};

@Injectable()
export class BeneficioPagamentoService {

  API_INSS_SERVER_NAME: string;
  BASE_URL_BENEFICIO_PAGAMENTO_API = "api/BeneficioPgto/v1";
  BASE_URL_SOLICITACAO_BENEFICIO_PAGAMENTO_API = "api/SolicBeneficioPgto/v1";

  public formaPagamentoSubject = new Subject<any>();
  public solicitacaoSubject = new Subject<any>();
  public formaPagamentoEscolhidaSubject = new BehaviorSubject<any>('');

  constructor(private httpClient: HttpClient) {
    this.API_INSS_SERVER_NAME = environment.API_INSS_SERVER_NAME;
    httpOptions.headers.set("Access-Control-Allow-Origin", "*");
    httpOptions.headers.set("Content-Type", "application/json");
  }

  solicitacaoSubjectObs = () => this.solicitacaoSubject.asObservable();

  addFormaPagamento(data) {
    console.log('entrou em addFormaPagamento data='+JSON.stringify(data));
    this.formaPagamentoSubject.next(data);
  }

  addFormaPagamentoEscolhida(data) {
    console.log('entrou em addFormaPagamentoEscolhida data='+JSON.stringify(data));
    this.formaPagamentoEscolhidaSubject.next(data);
  }


  // BUS de cominicacao para o componente app-dados-estaticos
  addSolicitacao(data) {
    console.log('entrou em addSolicitacao data='+JSON.stringify(data));
    this.solicitacaoSubject.next(data);
  }

  public getBeneficioPagamentoByCodigoBeneficio(codigoBeneficio: string) : Observable<BeneficioPagamentoResponseModel> {
    return this.httpClient.get(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_PAGAMENTO_API}/consultar-por-codbeneficio/${codigoBeneficio}/true`,
      httpOptions
    );
  }

  public getBeneficioPagamentoByCodigoSolicitacaoBeneficio(codigoSolicitacaoBeneficio: any) : Observable<BeneficioPagamentoResponseModel> {
    return this.httpClient.get(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_SOLICITACAO_BENEFICIO_PAGAMENTO_API}/consultar/${codigoSolicitacaoBeneficio}`,
      httpOptions
    );
  }

  public getBeneficioPagamentoByCodigoSolicitacaoBeneficioPromise(codigoSolicitacaoBeneficio: string): Promise<any> {
    return this.httpClient
      .get<any>(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_SOLICITACAO_BENEFICIO_PAGAMENTO_API}/consultar/${codigoSolicitacaoBeneficio}`
      )
      .pipe(map(res => (res ? res : {})))
      .toPromise();
  }

  // public getBeneficioPagamentoByCodigoSolicitacaoBeneficioPromise(codigoSolicitacaoBeneficio: string): Promise<any> {
  //   let promise = new Promise<any>((resolve, reject) => {
  //     this.httpClient
  //     .get<any>(
  //       `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_SOLICITACAO_BENEFICIO_PAGAMENTO_API}/consultar/${codigoSolicitacaoBeneficio}`
  //     ).toPromise()
  //     .then(
  //       res => {
  //         console.log('respondeu servico getBeneficioPagamentoByCodigoSolicitacaoBeneficioPromise='+JSON.stringify(res));
  //       }
  //     )
  //   });
  //   return promise;
  // }

  public postBeneficioPagamento(beneficioPagamento: BeneficioPagamentoModel) {

    let request = {} as BeneficioPagamentoRequestModel;
    let data    = {} as BeneficioPagamentoModel;

    request.process = 12345;
    request.system = "nfc-beneficio";

    request.data = data;

    return this.httpClient.post(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_PAGAMENTO_API}/inserir/`,
      request
    );
  }

  public salvarSolicitacaoBeneficioPagamento(solicitacao: BeneficioPagamentoModel, alterar = false) {

    console.log((alterar ? 'put' : 'post') + ' to => ', solicitacao);

    return this.httpClient[alterar ? 'put' : 'post']<any>(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_SOLICITACAO_BENEFICIO_PAGAMENTO_API}/${alterar ? 'alterar' : 'inserir'}/`,
      solicitacao
    );
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = "Unknown error!";
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // Server-side errors
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

}
