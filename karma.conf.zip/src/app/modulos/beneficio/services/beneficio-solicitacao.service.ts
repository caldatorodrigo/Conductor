import { Injectable } from '@angular/core';
import {
  HttpHeaders,
  HttpClient,
  HttpErrorResponse
} from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { BeneficioDataModel } from 'src/app/model/beneficio/beneficio-data.model';
import { throwError, Observable, Subject, BehaviorSubject } from 'rxjs';
import { catchError, retry, map } from 'rxjs/operators';
import { SolicitacaoBeneficioResponseModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-response.model';
import { SolicitacaoBeneficioRequestModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-request.model';
import { SolicitacaoBeneficioDataModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-data.model';
import { LojaModel } from 'src/app/model/loja/loja.model';
import { BeneficioPagamentoModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento.model';
import { StatusTipoModel } from 'src/app/model/tipos/tipo-status.model';
import { CapturaCartaoModel } from 'src/app/model/beneficio/captura/captura-cartao.model';

let httpOptions = {
  headers: new HttpHeaders()
};

@Injectable()
export class BeneficioSolicitacaoService {
  API_INSS_SERVER_NAME: string;
  BASE_URL_BENEFICIO_SOLICITACAO_API = 'api/SolicBeneficio/v1';
  BASE_URL_BENEFICIO_SOLICITACAO_DOC_API = 'api/SolicBeneficioDoc/v1';
  BASE_URL_BENEFICIO_SOLICITACAO_PGTO_API = '/api/SolicBeneficioPgto/v1/';

  public solicitacaoSubject = new BehaviorSubject<any>({});
  private beneficioToProvaVidaSubject = new BehaviorSubject<any>({});

  constructor(private httpClient: HttpClient) {
    this.API_INSS_SERVER_NAME = environment.API_INSS_SERVER_NAME;
    httpOptions.headers.set('Access-Control-Allow-Origin', '*');
    httpOptions.headers.set('Content-Type', 'application/json');
  }

  public setBeneficioToProvaVidaSubject(data: any) {
    this.beneficioToProvaVidaSubject.next(data);
  }
  public getBeneficioToProvaVidaSubject(): Observable<any> {
    return this.beneficioToProvaVidaSubject.asObservable();
  }

  public addSolicitacao(data) {
    console.log(
      'entrou em solicitacaoService.addSolicitacao data=' + JSON.stringify(data)
    );
    this.solicitacaoSubject.next(data);
  }

  public getSolicitacao(): Observable<any> {
    return this.solicitacaoSubject.asObservable();
  }

  public getSolicitacaoBeneficioByCodigoBeneficio(
    codigBeneficio
  ): Observable<SolicitacaoBeneficioResponseModel> {
    return this.httpClient
      .get(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/consultar/${codigBeneficio}/true`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public getSolicitacaoBeneficioByCodigoSolicitacao(
    codigSolcBeneficio
  ): Observable<SolicitacaoBeneficioResponseModel> {
    return this.httpClient
      .get(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/consultar-por-codsolicbeneficio/${codigSolcBeneficio}/true`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public inserirSolicitacaoBeneficioCapturaCartao(
    dadosCapturaCartao: CapturaCartaoModel
  ): Observable<any> {
    // ::: serviço de captura do cartão
    return this.httpClient.post(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/CapturarCartao`,
      dadosCapturaCartao
    );
  }

  public postSolicitacaoBeneficio(
    beneficio: BeneficioDataModel
  ): Observable<any> {
    const request = {
      process: 12345,
      system: 'nfc-beneficio',
      data: {
        codSolicbeneficio: 0,
        codBeneficio: beneficio.codBeneficio,
        loja: {
          codLoja: 0
        } as LojaModel,
        pessoa: beneficio.pessoa,
        status: {
          ativo: true,
          codigo: 24
        } as StatusTipoModel
      } as SolicitacaoBeneficioDataModel
    } as SolicitacaoBeneficioRequestModel;

    return this.httpClient.post(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/inserir/`,
      request
    );
  }

  public getSolicitacaoBeneficioDocumento(
    codigSolicitacaoBeneficio: string
  ): Observable<SolicitacaoBeneficioResponseModel> {
    return this.httpClient
      .get(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_DOC_API}/consultar/${codigSolicitacaoBeneficio}/true`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public atualizarSolicitacaoBeneficio(solicitacaoBeneficio: any) {
    return this.httpClient
      .put(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/SolicBeneficio/v1/alterar`,
        solicitacaoBeneficio
      )
      .subscribe(
        resp => {
          console.log(
            'respPost atualizarSolicitacaoBeneficio=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em atualizarSolicitacaoBeneficio' + JSON.stringify(err)
          )
      );
  }

  public atualizarStatusSolicitacaoBeneficio(solicitacaoBeneficio: any) {
    return this.httpClient.put(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/alterar-status`,
      solicitacaoBeneficio
    );
  }

  public finalizarSolicitacaoBeneficio(
    solicitacaoBeneficio: any
  ): Promise<any> {
    console.log(
      'finalizarSolicitacaoBeneficio.solicitacaoBeneficio' +
        JSON.stringify(solicitacaoBeneficio)
    );

    return this.httpClient
      .post<any>(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/finalizar-captura`,
        solicitacaoBeneficio
      )
      .pipe(map(res => (res.data ? res.data : {})))
      .toPromise();
  }

  reprovarAnalise(payload) {
    return this.httpClient.post<any>(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/reprovaranalise`,
      payload
    );
  }

  aprovarAnalise(payload) {
    return this.httpClient.post<any>(
      `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_BENEFICIO_SOLICITACAO_API}/aprovaranalise`,
      payload
    );
  }

  public executarConfiguracao(strControllerEParametros): Observable<any> {
    return this.httpClient.put(
      this.API_INSS_SERVER_NAME + strControllerEParametros,
      null
    );
  }

  public solicBeneficioPgtoAlterar(
    body: BeneficioPagamentoModel
  ): Observable<any> {
    return this.httpClient.put(
      this.API_INSS_SERVER_NAME +
        this.BASE_URL_BENEFICIO_SOLICITACAO_PGTO_API +
        'alterar',
      body
    );
  }

  public solicBeneficioInserirDocs(
    body: BeneficioPagamentoModel
  ): Observable<any> {
    return this.httpClient.post(
      this.API_INSS_SERVER_NAME +
        '/' +
        this.BASE_URL_BENEFICIO_SOLICITACAO_API +
        '/inserir-documentos-obrigatorios',
      body
    );
  }
}
