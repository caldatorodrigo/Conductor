import { Injectable }              from "@angular/core";
import { HttpHeaders, HttpClient } from "@angular/common/http";
import { environment }             from "src/environments/environment";
import { Observable }              from "rxjs";

var httpOptions = {
    headers: new HttpHeaders()
};

@Injectable() export class BeneficioGpbService {
    API_INSS_SERVER_NAME:string;

    constructor(private httpClient: HttpClient) {
        httpOptions.headers.set("Access-Control-Allow-Origin", "*");
        httpOptions.headers.set("Content-Type", "application/json");
    }

    public obtemDetalheDeBeneficio(numBeneficio:number):Observable<any> {
        return this.httpClient.post(environment.API_BENEFICIO + "/api/Beneficio/ObtemDetalheDeBeneficio", JSON.parse('{ "data": {"numeroDeBeneficio": ' + numBeneficio + '} }'), httpOptions);
    }

}
