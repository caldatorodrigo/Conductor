import { Component, OnInit, ViewChild, NgModule, Output } from '@angular/core';
import { NgForm, Validators, FormBuilder } from '@angular/forms';
import { BeneficioService } from '../../services/beneficio.service';
import { ActivatedRoute } from '@angular/router';
import { FichaCadastralComponent } from 'src/app/shared/modulos/ficha-cadastral/components/ficha-cadastral/ficha-cadastral.component';
import { map } from 'rxjs/operators';
import { BeneficioResponseModel } from 'src/app/model/beneficio/beneficio-response.model';
import { BeneficioDataModel } from 'src/app/model/beneficio/beneficio-data.model';
import { BeneficioSolicitacaoService } from '../../services/beneficio-solicitacao.service';
import { SolicitacaoBeneficioDataModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-data.model';
import { SolicitacaoBeneficioResponseModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-response.model';
import {
  MatDialogModule,
  MatDialog,
  MatSnackBar,
  MatTableDataSource,
  MatSort
} from '@angular/material';
import { ModalComponentComponent } from 'src/app/shared/modulos/modal-component/modal-component.component';
import { BeneficioPagamentoService } from '../../services/beneficio-pagamento.service';
import { BeneficioPagamentoResponseModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento-response-data.model';
import { BeneficioPagamentoModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento.model';
import { CadastroBusService } from 'src/app/shared/services/cadastro-bus.service';
import { SenhaCartaoComponent } from 'src/app/shared/modulos/senha-cartao/senha-cartao.component';
import { FichaCadastralContaCorrenteComponent } from 'src/app/shared/modulos/ficha-cadastral-conta-corrente/components/ficha-cadastral-conta-corrente/ficha-cadastral-conta-corrente.component';
import { TipoMeioPagamentoModel } from 'src/app/model/tipos/tipo-meio-pagamento.model';
import { ShfService } from 'src/app/modulos/senha/services/shf.service';
import { WebApiService } from 'src/app/modulos/senha/services/web-api.service';
import { SolicitacaoBeneficioRequestModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-request.model';
import { StatusTipoModel } from 'src/app/model/tipos/tipo-status.model';
import { StatusModel } from 'src/app/model/status/status.model';
import { isNullOrUndefined } from 'util';
import { AlertService } from 'src/app/shared/services/alert.service';
import { AlertType } from 'src/app/shared/models/alert.model';
import { environment } from 'src/environments/environment';
import { FilasService } from 'src/app/modulos/filas/filas.service';
import { FilaModel } from 'src/app/model/fila/fila.model';
import { BeneficioGpbService } from '../../services/beneficio-gpb.service';

interface FilaAnaliseItem {
  codigoNomeUsuario?: string;
  dataInicioAnalise?: string;
  dataFimAnalise?: string;
  descricaoObservacao?: string;
}

interface HistoricoAnaliseTableFormat {

  codigoNomeUsuario?: string;
  dataInclusao?: string;
  codigoDescricaoStatus?: string;
  analises?: Array<FilaAnaliseItem>;

  tipoFila?: string;
  cpf?: string;
  nome?: string;
  loja?: string;
  analista?: string;
  dataInicioAnalise?: string;
  dataFimAnalise?: string;
  status?: string;
  acoes?: string;
}

@Component({
  selector: 'app-beneficio-inss-main',
  templateUrl: './beneficio-inss-main.component.html',
  styleUrls: ['./beneficio-inss-main.component.scss']
})
@NgModule({
  declarations: [FichaCadastralComponent, FichaCadastralContaCorrenteComponent],
  exports: [FichaCadastralComponent]
})
export class BeneficioInssMainComponent implements OnInit {
  @ViewChild('form', { read: true, static: false })
  form: NgForm;

  fechaAbas;
  show;
  beneficioResponseModelContaCorrente;
  showAcoesContaCorrente;
  show5;
  show2;
  show4;
  showContaCorrente;
  showFichaCadastralProcurador;
  showAtivarContaCorrente;

  displayedColumns: string[] = [
    'selected',
    'numBeneficio',
    'cpf',
    'nome',
    'formaPagamento',
    'dataConcessão',
    'status'
  ];

  displayedColumnsInicioRelacionamento: string[] = [
    'numSolicitacao',
    'numBeneficio',
    'cpf',
    'nome',
    'status',
    'solicitacao',
    'analise',
    'senhaCartao'
  ];
  dataSource;
  dataSourceInicioRelacionamento: MatTableDataSource<any> = new MatTableDataSource([{a: '', b: ''}]);
  dataSourceAnaliseBeneficio: MatTableDataSource<any> = new MatTableDataSource([{a: '', b: ''}]);

  @ViewChild(MatSort, { static: false }) sort: MatSort;

  message: {};
  cpf: string;
  numeroBeneficio: string;

  beneficioResponseModel: BeneficioResponseModel;
  beneficios: any[] = [];
  solicitacaoBeneficioResponseModel: SolicitacaoBeneficioResponseModel;
  solicitacoesBeneficio: SolicitacaoBeneficioDataModel[] = [];
  beneficioSelecionado: BeneficioDataModel = {};
  beneficioDetalhe: BeneficioDataModel = {};
  solicitacaoSelecionada: SolicitacaoBeneficioDataModel = {};

  beneficioPagamentoResponseModel: BeneficioPagamentoResponseModel;
  beneficioPagamentoModel: BeneficioPagamentoModel[] = [];

  dialogValue: string;
  sendValue: string;

  showAcoesBeneficio: Boolean = false;
  showPainelBeneficio: Boolean = true; // painel-beneficio
  showAtivarBeneficio: Boolean = false; // ativar-beneficio
  showProvaVida: Boolean = false; // prova-vida
  showFormaPagto: Boolean = false; // forma-pagto
  showDetalheBeneficio: Boolean = false; // detalhe-beneficio
  showDadosCadastrais: Boolean = false; // dados-cadastrais
  showAntecipaRenda: Boolean = false; // antecipa-renda
  showRecadastramentoCenso: Boolean = false; // recadastramento-censo
  apareceHistoricoAnalise: Boolean = false; //historico analise de solicitacao
  detalhesApareceHistoricoAnalise: Boolean = false; //Detalhes analise de solicitacao

  isCheckedPrePagoMasterCard: Boolean = false;
  isCheckedContaCorrente: Boolean = false;
  showFichaCadastral: Boolean = false; // ficha cadastral
  showFormaRecebimentoBeneficio: Boolean = false;
  showFichaCadastralContaCorrente: Boolean = false;
  showTabelaBeneficioSolicitacoes: Boolean = false; // mostra tabela de solicitacoes
  habilitarBotaoAtivarBeneficio: Boolean = false; // mostra tabela de solicitacoes

    public ticket:any;
    public matriculaUser:string;

  constructor(
    public snackBar: MatSnackBar,
    public dialog: MatDialog,
    public beneficioService: BeneficioService,
    public beneficioSolicitacaoService: BeneficioSolicitacaoService,
    public beneficioPagamentoService: BeneficioPagamentoService,
    public cadastroBusService: CadastroBusService,
    private plugInServ: ShfService,
    private webApi: WebApiService,
    private alertService: AlertService,
    private filaService : FilasService,
    private route:ActivatedRoute,
    private beneficioGpbService:BeneficioGpbService
  ) {
      /*this.route.paramMap.subscribe(p => {
          this.ticket = JSON.parse(atob(p.get("ticket"))); // eyJzdWIiOiIyMDc1MTUiLCJqdGkiOiJjMDA2NzQ5My0yMDUzLTQ5MTctYmZmYS1hMjUzNjVmNjA3MzAiLCJlbWFpbCI6InJvYnNvbi5jZXJxdWVpcmFAY3JlZmlzYS5jb20uYnIiLCJpc3MiOiJDcmVmaXNhLkF1dGhQcm92aWRlciIsImV4cCI6MTU3ODk0MzEyOCwiTk9NRSI6IlJPQlNPTiBDRVJRVUVJUkEiLCJQRVJGSUwiOiJDTkdfT1BFUkFET1IiLCJDT0RJR09fQVBMSUNBQ0FPIjoiQ05HIiwiVElQT19BQ0VTU08iOiJTZWciLCJJREVOVElGSUNBQ0FPX1VTVUFSSU9MT0dJTiI6IjAxMjk2MTEwLTZlNmQtNGZiOS04MzhlLWM1OWQzNjM1MTNlNiIsImF1ZCI6IkNORyJ9
      });
      this.matriculaUser = this.ticket.sub;
      console.log("matrícula usuário = " + this.matriculaUser);*/
  }

  ngOnInit() {}

  onSubmit() {
    this.escondePainelIniciaRelacionamento();

    if (this.dataSource) {
      this.dataSource = undefined;
    }
    this.showAcoesBeneficio = false;
    this.alertService.setLoading(true);
    if (
      (this.cpf == undefined && this.numeroBeneficio == undefined) ||
      (this.cpf == 'XXX.XXX.XXX-XX' && this.numeroBeneficio == 'XXX.XXX.XXX-X')
    ) {
      this.openSnackBar('Informar CPF ou Beneficio', 'ERRO');
      this.alertService.setLoading(false);
      this.beneficios = null;
      return;
    } else {
      this.beneficioService
        .getBeneficio(this.numeroBeneficio, this.cpf)
        .subscribe(
          (res: any) => {
            if (res.data && res.data.length > 0) {
              this.beneficioResponseModel = res;
              this.beneficios = <BeneficioDataModel[]>(
                this.beneficioResponseModel.data
              );
              console.log(
                'this.beneficioResponseModel=' +
                  JSON.stringify(this.beneficioResponseModel.data)
              );
              console.log('this.beneficios=' + JSON.stringify(this.beneficios));
            } else {
              this.alertService.dispatch(
                'Nenhum dado encontrado',
                AlertType.INFO
              );
              this.beneficios = [];
            }

            this.dataSource = new MatTableDataSource(this.beneficios);
          },
          err => {
            //  text: err['error']['errors'][0]
            /* console.log("erro=" + err);
            this.openSnackBar("Nenhum Dado Encontrado", "X"); */
            this.alertService.setLoading(false);
          },
          () => {
            this.alertService.setLoading(false);
          }
        );
    }
  }

  trocarItemBeneficio(beneficio: BeneficioDataModel) {
    console.log('entrou trocarItemBeneficio' + beneficio.numBeneficio);
    this.beneficioSelecionado = Object.assign({}, beneficio);
    console.log('trocarItemBeneficio.beneficioSelecionado=',this.beneficioSelecionado);
    this.beneficioSolicitacaoService.setBeneficioToProvaVidaSubject(this.beneficioSelecionado);
    this.showAcoesBeneficio = true;
      var teste: BeneficioDataModel; // ::: cpf:17757432847, nb:1499177893
      console.clear();
      console.log("CHAMOU");
      this.beneficioGpbService.obtemDetalheDeBeneficio(Number.parseInt(this.beneficioSelecionado.numBeneficio)).subscribe(
          r => {
              console.log("RECEBEU");
              console.log(JSON.stringify(r));
          },
          e => {
              console.log(JSON.stringify(e));
          }
      );
  }

  //FUNCAO PARA TESTAR O NGX-LOADING
  componenteLoading() {
    this.alertService.setLoading(true);
    setTimeout(() => {
      this.alertService.setLoading(false);
    }, 1500);
  }

  //FUNCOES PARA RETORNAR PARA A PAGINA DE BENEFICIO
  escondePainelProvaVida() {
    this.showProvaVida = false;
    this.showPainelBeneficio = true;
  }

  escondePainelDadosCadastrais() {
    this.showDadosCadastrais = false;
    this.showPainelBeneficio = true;
  }

  escondePainelFormaPagamento() {
    this.showFormaPagto = false;
    this.showPainelBeneficio = true;
  }

  escondePainelAntecipaRenda() {
    this.showAntecipaRenda = false;
    this.showPainelBeneficio = true;
  }

  escondePainelRecadastramentoCenso() {
    this.showRecadastramentoCenso = false;
    this.showPainelBeneficio = true;
  }

  escondePainelIniciaRelacionamento() {
    this.showAtivarBeneficio = false;
    this.showPainelBeneficio = true;
    if (this.dataSourceInicioRelacionamento) {
      this.dataSourceInicioRelacionamento = undefined;
    }
    if (this.dataSourceAnaliseBeneficio) {
      this.dataSourceAnaliseBeneficio = undefined;
    }
    this.showAcoesBeneficio = false;
  }

  //FUNCOES PARA RETORNAR PARA A PAGINA DE BENEFICIO

  mostrarPainelEsconderOutros(idPainel: string) {
    console.log('entrou mostrarPainelEsconderOutros idPainel=' + idPainel);

    if (idPainel == 'undefined') return;

    switch (idPainel) {
      case 'painel-beneficio':
        this.showPainelBeneficio = true;
        this.showAtivarBeneficio = false;
        this.showProvaVida = false;
        this.showFormaPagto = false;
        this.showDetalheBeneficio = false;
        this.showDadosCadastrais = false;
        this.showAntecipaRenda = false;
        this.showRecadastramentoCenso = false;
        break;

      case 'ativar-beneficio':
        this.showPainelBeneficio = false;
        this.showProvaVida = false;
        this.showFormaPagto = false;
        this.showDetalheBeneficio = false;
        this.showDadosCadastrais = false;
        this.showAntecipaRenda = false;
        this.showRecadastramentoCenso = false;

        console.log(
          'this.beneficioSelecionado=' +
            JSON.stringify(this.beneficioSelecionado)
        );

        this.alertService.setLoading(true);

        this.beneficioSolicitacaoService
          .getSolicitacaoBeneficioByCodigoBeneficio(
            this.beneficioSelecionado.codBeneficio + ''
          )
          .subscribe(
            (res: any) => {
              this.solicitacaoBeneficioResponseModel = res;
              this.solicitacoesBeneficio = <SolicitacaoBeneficioDataModel[]>(
                this.solicitacaoBeneficioResponseModel.data
              );
              this.dataSourceInicioRelacionamento = new MatTableDataSource(
                res.data
              );
              console.log(
                'this.solicitacaoBeneficioResponseModel=' +
                  JSON.stringify(this.solicitacaoBeneficioResponseModel.data)
              );
            },
            err => {
              //  text: err['error']['errors'][0]
            },
            () => {
              this.tratarBotaoAtivarBeneficio();
              this.alertService.setLoading(false);
            }
          );

        this.showAtivarBeneficio = true;

        break;

      case 'prova-vida':
        this.showPainelBeneficio = false;
        this.showAtivarBeneficio = false;
        this.showProvaVida = true;
        this.showFormaPagto = false;
        this.showDetalheBeneficio = false;
        this.showDadosCadastrais = false;
        this.showAntecipaRenda = false;
        this.showRecadastramentoCenso = false;
        break;

      case 'antecipa-renda':
        this.showPainelBeneficio = false;
        this.showAtivarBeneficio = false;
        this.showProvaVida = false;
        this.showFormaPagto = false;
        this.showDetalheBeneficio = false;
        this.showDadosCadastrais = false;
        this.showAntecipaRenda = true;
        this.showRecadastramentoCenso = false;
        break;

      case 'recadastramento-censo':
        this.showPainelBeneficio = false;
        this.showAtivarBeneficio = false;
        this.showProvaVida = false;
        this.showFormaPagto = false;
        this.showDetalheBeneficio = false;
        this.showDadosCadastrais = false;
        this.showAntecipaRenda = false;
        this.showRecadastramentoCenso = true;
        break;

      case 'forma-pagto':
        this.showPainelBeneficio = false;
        this.showAtivarBeneficio = false;
        this.showProvaVida = false;
        this.showFormaPagto = true;
        this.showDetalheBeneficio = false;
        this.showDadosCadastrais = false;
        this.showAntecipaRenda = false;
        this.showRecadastramentoCenso = false;
        break;

      case 'detalhe-beneficio':
        this.showPainelBeneficio = false;
        this.showAtivarBeneficio = false;
        this.showProvaVida = false;
        this.showFormaPagto = false;
        this.showDetalheBeneficio = true;
        this.showDadosCadastrais = false;
        this.showRecadastramentoCenso = false;
        break;

      case 'dados-cadastrais':
        this.showPainelBeneficio = false;
        this.showAtivarBeneficio = false;
        this.showProvaVida = false;
        this.showFormaPagto = false;
        this.showDetalheBeneficio = false;
        this.showDadosCadastrais = true;
        this.showAntecipaRenda = false;
        this.showRecadastramentoCenso = false;
        break;
    }
  }

  tratarBotaoAtivarBeneficio() {
    console.log(
      'habilitarBotaoAtivarBeneficioINI=' + this.habilitarBotaoAtivarBeneficio
    );
    // Se houver solicitacoes pendentes mostra tabela,
    // caso contrario somente o botao ativar
    console.log(
      'this.solicitacoesBeneficio =' +
        JSON.stringify(this.solicitacoesBeneficio)
    );

    console.log(
      'habilitarBotaoAtivarBeneficio-0=' + this.solicitacoesBeneficio.length
    );
    console.log(
      'habilitarBotaoAtivarBeneficio-0.1=' +
        isNullOrUndefined(this.solicitacoesBeneficio)
    );

    if (
      !isNullOrUndefined(this.solicitacoesBeneficio) &&
      this.solicitacoesBeneficio.length > 0
    ) {
      this.habilitarBotaoAtivarBeneficio = true;
      console.log(
        'habilitarBotaoAtivarBeneficio-1=' + this.habilitarBotaoAtivarBeneficio
      );
      for (var i = 0; i < this.solicitacoesBeneficio.length; i++) {
        console.log(
          'habilitarBotaoAtivarBeneficio-2=' +
            this.habilitarBotaoAtivarBeneficio
        );
        console.log(
          'habilitarBotaoAtivarBeneficio-2.5=' +
            this.solicitacoesBeneficio[i].status.codigo
        );
        if (
          this.solicitacoesBeneficio[i].status.codigo != 33 &&
          this.solicitacoesBeneficio[i].status.codigo != 34
        ) {
          this.habilitarBotaoAtivarBeneficio = false;
          console.log(
            'habilitarBotaoAtivarBeneficio-3=' +
              this.habilitarBotaoAtivarBeneficio
          );
          break;
        }
      }

      this.showTabelaBeneficioSolicitacoes = true;
    } else {
      console.log(
        'habilitarBotaoAtivarBeneficio-4=' + this.habilitarBotaoAtivarBeneficio
      );
      this.habilitarBotaoAtivarBeneficio = true;
      this.showTabelaBeneficioSolicitacoes = false;
      console.log(
        'habilitarBotaoAtivarBeneficio-5=' + this.habilitarBotaoAtivarBeneficio
      );
    }
  }

  habilitarFichaCadastral() {
    this.showFichaCadastral = true;
    if ( this.isCheckedPrePagoMasterCard == undefined &&
         this.isCheckedContaCorrente == undefined ) {
      this.showFichaCadastral = false;
    }

    console.log('*****************************************************');
    console.log('habilitarFichaCadastral=' + this.solicitacaoSelecionada);
    this.beneficioSolicitacaoService.addSolicitacao(
      this.solicitacaoSelecionada
    );
    console.log('*****************************************************');

    this.beneficioPagamentoService.formaPagamentoEscolhidaSubject.subscribe();
    let meioPagamentoEscolhido: TipoMeioPagamentoModel = {};
    this.beneficioPagamentoService.formaPagamentoEscolhidaSubject.subscribe(
      (data: any) => {
        meioPagamentoEscolhido = <TipoMeioPagamentoModel>data;
        console.log(
          'meioPagamentoEscolhido=' + meioPagamentoEscolhido.descricao
        );
      }
    );

    // Insere solicitacao de Forma de Pagamento
    if ( this.solicitacaoSelecionada.formaPagamento != undefined &&
         this.solicitacaoSelecionada.formaPagamento.length > 0
    ) {
      // Seleciona a forma de pagamento principal da solicitacao
      let formaPagamentoPrincipalSolicitacao: BeneficioPagamentoModel = {};
      for (var i = 0; i < this.solicitacaoSelecionada.formaPagamento.length; i++) {
        if (this.solicitacaoSelecionada.formaPagamento[i].principal === true) {
          formaPagamentoPrincipalSolicitacao = this.solicitacaoSelecionada.formaPagamento[i];
          break;
        }
      }

      // Altera somente se houve alteracao na forma de pagamento
      if ( formaPagamentoPrincipalSolicitacao.tipoMeioPagamento.codigo != meioPagamentoEscolhido.codigo &&
           formaPagamentoPrincipalSolicitacao.tipoMeioPagamento.descricao != meioPagamentoEscolhido.descricao &&
           meioPagamentoEscolhido.codigo != undefined
      ) {
        // Efetua chamada para tirar forma de pagamento atual como principal = false
      formaPagamentoPrincipalSolicitacao.principal = false;
      this.beneficioPagamentoService
        .salvarSolicitacaoBeneficioPagamento(formaPagamentoPrincipalSolicitacao)
        .subscribe(
          (res: any) => {
            console.log('retorno do postSolicitacaoBeneficioPagamento');
          },
          err => {
            console.error(
              'Erro ao chamar postSolicitacaoBeneficioPagamento=>' + err
            );
          }
        );

        // Monta request e efetua post de nova solicitacao de beneficio pagamento
        let novaSolicitacaoBeneficioPagamento: BeneficioPagamentoModel = {};
        novaSolicitacaoBeneficioPagamento.codSolicBeneficioPgto = 0;
        novaSolicitacaoBeneficioPagamento.codSolicbeneficio =formaPagamentoPrincipalSolicitacao.codSolicbeneficio;
        novaSolicitacaoBeneficioPagamento.loja = Object.assign( {}, formaPagamentoPrincipalSolicitacao.loja );
        novaSolicitacaoBeneficioPagamento.numConta = '0'; // Ainda nao existe, portanto enviar zerado
        novaSolicitacaoBeneficioPagamento.numIdcontacartao = '0'; // Ainda nao existe, portanto enviar zerado
        novaSolicitacaoBeneficioPagamento.principal = true;
        novaSolicitacaoBeneficioPagamento.senha = formaPagamentoPrincipalSolicitacao.senha;
        novaSolicitacaoBeneficioPagamento.validado = formaPagamentoPrincipalSolicitacao.validado;
        let tipoMeioPagamento: TipoMeioPagamentoModel = {};
        tipoMeioPagamento.ativo = meioPagamentoEscolhido.ativo;
        tipoMeioPagamento.codigo = meioPagamentoEscolhido.codigo;
        tipoMeioPagamento.descricao = meioPagamentoEscolhido.descricao;
        novaSolicitacaoBeneficioPagamento.tipoMeioPagamento = Object.assign({}, tipoMeioPagamento);

        // Chama POST /api/SolicBeneficioPgto/v1/inserir
        this.beneficioPagamentoService
          .salvarSolicitacaoBeneficioPagamento(novaSolicitacaoBeneficioPagamento)
          .subscribe(
            (res: any) => {
              console.log('retorno do postSolicitacaoBeneficioPagamento');
            },
            err => {
              console.error(
                'Erro ao chamar postSolicitacaoBeneficioPagamento=>' + err
              );
            }
          );
      }
    }

    // Atualiza o status da solicitacao:
    this.atualizarStatusSolicitacaoBeneficio(25);
  }

  habilitarFichaCadastralContaCorrente() {
    this.showFichaCadastralContaCorrente = true;
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(ModalComponentComponent, {});
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  enviarFormaPagamentoToBUS(data: any) {
    // Adiciona forma de pagamento no BUS
    console.log(
      'antes de add no BUS this.beneficioPagamentoModel=' +
        JSON.stringify(this.beneficioPagamentoModel)
    );
    this.beneficioPagamentoService.addFormaPagamento(
      this.beneficioPagamentoModel
    );
  }

  enviarSolicitacaoToBUS(data: any) {
    console.log(
      'this.solicitacaoSelecionada=' +
        this.solicitacaoSelecionada.codSolicbeneficio
    );

    // Adiciona solicitacao no BUS
    console.log(
      'antes de add no BUS this.solicitacaoSelecionada=' +
        JSON.stringify(this.solicitacaoSelecionada)
    );
    this.beneficioPagamentoService.addSolicitacao(this.solicitacaoSelecionada);
  }

  ativarBeneficio() {
    // Verifica se existe alguma solicitacao pendente com status diferente de 33(cancelado) e 34(concluida)
    let possuiSolicitacaoPendente: Boolean = false;
    for (var i = 0; i < this.solicitacoesBeneficio.length; i++) {
      if (
        this.solicitacoesBeneficio[i].status.codigo != 33 &&
        this.solicitacoesBeneficio[i].status.codigo != 34
      ) {
        possuiSolicitacaoPendente = true;
        break;
      }
    }

    if (!possuiSolicitacaoPendente) {
      this.alertService.setLoading(true);
      this.beneficioSolicitacaoService
        .postSolicitacaoBeneficio(this.beneficioSelecionado)
        .subscribe(
          (res: any) => {
            console.log('retorno do post');
            // this.showFormaRecebimentoBeneficio = true;
          },
          err => {
            console.error('erro em ativarBeneficio->' + JSON.stringify(err));
            this.alertService.setLoading(false);
          },
          () => {
            this.mostrarPainelEsconderOutros('ativar-beneficio');
          }
        );
    }

    this.obterFormaRecebimentoBeneficio();
    this.cadastroBusService.addBeneficio(this.beneficioSelecionado);
  }

  selecionarSolicitacao(solicitacaoSelecionada: SolicitacaoBeneficioDataModel) {
    console.log(
      'solicitacaoSelecionada=' + solicitacaoSelecionada.codSolicbeneficio
    );
    this.solicitacaoSelecionada = solicitacaoSelecionada;
    this.showFormaRecebimentoBeneficio = true;
    console.log(
      'this.solicitacaoSelecionada=' +
        this.solicitacaoSelecionada.codSolicbeneficio
    );
    this.beneficioSolicitacaoService.addSolicitacao(
      this.solicitacaoSelecionada
    );
    this.cadastroBusService.addBeneficio(this.beneficioSelecionado);
    this.showFormaRecebimentoBeneficio = true;
  }

  obterFormaRecebimentoBeneficio() {
    this.beneficioPagamentoService
      .getBeneficioPagamentoByCodigoBeneficio(
        '' + this.beneficioSelecionado.codBeneficio
      )
      .subscribe(
        (res: any) => {
          this.beneficioPagamentoResponseModel = res;
          this.beneficioPagamentoModel = <BeneficioPagamentoModel[]>(
            this.beneficioPagamentoResponseModel.data
          );

          this.enviarFormaPagamentoToBUS(
            this.beneficioPagamentoResponseModel.data
          );

          this.enviarSolicitacaoToBUS(this.solicitacaoSelecionada);

          console.log(
            'this.beneficioPagamentoResponseModel=' +
              JSON.stringify(this.beneficioPagamentoResponseModel.data)
          );
        },
        err => {
          //  text: err['error']['errors'][0]
        }
      );
  }

  detalharBeneficio() {
    this.showDetalheBeneficio = true;
    let detalheData: BeneficioResponseModel;

    this.beneficioService
      .getBeneficioDetalhe('' + this.beneficioSelecionado.numBeneficio)
      .subscribe(
        (res: any) => {
          detalheData = res;
          this.beneficioDetalhe = <BeneficioDataModel>detalheData.data;
          console.log(
            'this.getBeneficioDetalhe=' + JSON.stringify(this.beneficioDetalhe)
          );
        },
        err => {
          //  text: err['error']['errors'][0]
        }
      );
  }

  fecharDetalhesBeneficio() {
    this.showDetalheBeneficio = false;
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 5000,
      horizontalPosition: 'right',
      verticalPosition: 'top'
    });
  }

  modalSenha(): void {
    const dialogRef = this.dialog.open(SenhaCartaoComponent, {});
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  public validarAlteracao(): void {
    this.webApi
      .getValidarAlteracao('626064', 'SistemaInss', '61033106000186')
      .subscribe(
        x => console.log(JSON.stringify(x)),
        e => console.log(JSON.stringify(e))
      );
  }

  public ativarTeclado(): void {
    /*this.plugInServ.teclado
      .buscarStatus()
      .then(statusTeclado =>
        console.log('1-STATUS TECLADO VIRTUAL =======>' + statusTeclado)
      );
*/
    //this.fecharTeclado();
    this.plugInServ.mensagem$.subscribe(
      x => {
        if (x === 'pluging executado com sucesso') {
          console.log(
            'plugin executado VERSÃO:' + this.plugInServ.teclado.versao
          );
        } else {
          console.log(x);
        }
      },
      () => {
        this.plugInServ.teclado
          .buscarStatus()
          .then(statusTeclado =>
            console.log('2-STATUS TECLADO VIRTUAL =======>' + statusTeclado)
          );
      }
    );
    /*this.plugInServ.ExecutarPlugin('TecladoVirtual', 'v4.0', [
      '8083',
      '61033106000186',
      '626064',
      'OP_PWD_4'
    ]);*/
    this.plugInServ.ExecutarTeclado(
      environment.PLUGINS.TECLADO_VIRTUAL.VERSAO,
      environment.PLUGINS.TECLADO_VIRTUAL.PARAMETROS
    );

    this.webApi
      .getStatusTeclado(environment.PLUGINS.TECLADO_VIRTUAL.PARAMETROS[0])
      .subscribe(res => {
        console.log(res);
      });
  }

  public buscarStatus(): void {
    this.plugInServ.teclado
      .buscarStatus()
      .then(x => console.log('TESTE TECLADO VIRTUAL ======= ' + x));
  }

  public fecharTeclado(): void {
    this.plugInServ.teclado.fechar().then(x => console.log(x));
  }

  public atualizarStatusSolicitacaoBeneficio(codigoStatus: number) {
    let solicitacaoBeneficioStatusRequest: SolicitacaoBeneficioRequestModel = {};
    let solicitacaoBeneficioStatusDataRequest: SolicitacaoBeneficioDataModel = {};
    let status: StatusModel = {};
    let tipo: StatusTipoModel = {};

    status.codigo = codigoStatus;
    status.ativo = true;
    tipo.codigo = 21;
    status.tipo = Object.assign({}, tipo);
    solicitacaoBeneficioStatusDataRequest.status = Object.assign({}, status);
    solicitacaoBeneficioStatusDataRequest.codBeneficio = this.solicitacaoSelecionada.codBeneficio;
    solicitacaoBeneficioStatusDataRequest.codSolicbeneficio = this.solicitacaoSelecionada.codSolicbeneficio;
    solicitacaoBeneficioStatusRequest.data = Object.assign(
      {},
      solicitacaoBeneficioStatusDataRequest
    );
    console.log(
      'atualizarStatusSolicitacaoBeneficio=' +
        JSON.stringify(solicitacaoBeneficioStatusRequest)
    );
    this.beneficioSolicitacaoService.atualizarStatusSolicitacaoBeneficio(
      solicitacaoBeneficioStatusRequest
    );
  }

  statusReadyonly(codigo) {
    const readyonlyStatus = [29, 31, 32, 33, 34];

    return readyonlyStatus.filter(codigo_ => codigo === codigo_).length > 0;
  }

  emptyTable(dataSource) {
    return dataSource && dataSource.data && dataSource.data.length === 0;
  }


  mostrarHistoricoAnalise() {
     // TODO: Validar se esta no status de ANALISE antes de mostrar
    this.apareceHistoricoAnalise = true;

    if (this.dataSourceAnaliseBeneficio) {
      this.dataSourceAnaliseBeneficio = undefined;
    }
    this.getDadosHistoricos();
  }

  getDadosHistoricos() {

    let historicoAnaliseList = [] as Array<FilaModel>;
    let mappedHistoricoAnaliseList = [] as Array<HistoricoAnaliseTableFormat>;

    this.alertService.setLoading(true);
    this.filaService
      .getHistoricoFilaAnalisePorCodigoExternoAndTipoFila(
          '123','4'
      )
      .then(resposta => {
        console.log('getHistoricoFilaAnalisePorCodigoExternoAndTipoFila=', resposta);
        historicoAnaliseList = <FilaModel[]>resposta;
        console.log('historicoAnaliseList=', historicoAnaliseList);
        console.log(
          'historicoAnaliseList=' + JSON.stringify(historicoAnaliseList)
        );

        // interface FilaAnaliseItem {
        //   codigoNomeUsuario?: string;
        //   dataInicioAnalise?: string;
        //   dataFimAnalise?: string;
        //   descricaoObservacao?: string;
        // }

        // interface HistoricoAnaliseTableFormat {

        //   codigoNomeUsuario?: string;
        //   dataInclusao?: string;
        //   codigoDescricaoStatus?: string;
        //   analises?: Array<FilaAnaliseItem>;


        historicoAnaliseList.forEach(
          item => {
            const itemFilaAnalise: HistoricoAnaliseTableFormat = {};

            itemFilaAnalise.codigoNomeUsuario =
              item.codUsuarioinclusao ? item.codUsuarioinclusao+'' : '';

            itemFilaAnalise.dataInclusao =
              item.dtaInclusao ? item.dtaInclusao.toString() : '';

            itemFilaAnalise.codigoDescricaoStatus =
              item.status &&
              item.status.codStatus
                ? item.status.codStatus+''
                : '';

            itemFilaAnalise.codigoDescricaoStatus =
              itemFilaAnalise.status +
                (item.status && item.status.descStatus ? ('-' + item.status.descStatus) : '');


            if (item.filasAnalise) {

              item.filasAnalise.forEach(filaAnalise => {

                itemFilaAnalise.tipoFila =
                  item &&
                  item.tiposFila &&
                  item.tiposFila.desFila
                    ? item.tiposFila.desFila
                    : '';

                itemFilaAnalise.analista =
                  item &&
                  item.codUsuarioinclusao
                    ? item.codUsuarioinclusao + ''
                    : '';

                itemFilaAnalise.dataInicioAnalise =
                  filaAnalise.dtaIniAnalise
                    ? filaAnalise.dtaIniAnalise
                    : '';

                itemFilaAnalise.dataFimAnalise =
                  filaAnalise.dtaFimAnalise
                    ? filaAnalise.dtaFimAnalise
                    : '';

                itemFilaAnalise.status =
                  item &&
                  item.status &&
                  item.status.descStatus
                    ? item.status.descStatus
                    : '';

                itemFilaAnalise.acoes = 'TODO';
              });
            }
            mappedHistoricoAnaliseList.push(itemFilaAnalise);
          }
        );

      })
      .finally(() => {
        this.dataSourceAnaliseBeneficio = new MatTableDataSource(
          mappedHistoricoAnaliseList
        );

        console.log(
          'this.mappedHistoricoAnaliseList=' +
            JSON.stringify(mappedHistoricoAnaliseList)
        );
        this.alertService.setLoading(false);
      });
  }

}
