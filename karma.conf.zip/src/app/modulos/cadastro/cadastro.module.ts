import { NgModule } from '@angular/core';
import { PessoaComponent } from './pessoa/pessoa.component';

@NgModule({
  imports: [],
  exports: [],
  providers: [],
  declarations: [PessoaComponent],
})
export class CadastroModule { }
