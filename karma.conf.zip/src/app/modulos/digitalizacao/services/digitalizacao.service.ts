import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Injectable } from '@angular/core';

@Injectable()
export class DigitalizacaoService{

    constructor(private http: HttpClient){}

    /// Gravar documento na base de dados.
    documentoApi(pUrl:string, parametro:any) {

        return this.http.post<any>(pUrl, parametro)
        .pipe(map(data => {
        return data;
        }));
    
    }

}




  
