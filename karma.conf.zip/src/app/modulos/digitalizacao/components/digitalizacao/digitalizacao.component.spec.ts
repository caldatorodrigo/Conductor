import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalizacaoComponent } from './digitalizacao.component';

describe('DigitalizacaoComponent', () => {
  let component: DigitalizacaoComponent;
  let fixture: ComponentFixture<DigitalizacaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalizacaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalizacaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
