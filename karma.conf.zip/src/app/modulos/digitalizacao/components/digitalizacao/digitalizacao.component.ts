import { first }                                      from "rxjs/operators";
import { environment }                                from "src/environments/environment";
import { DatePipe }                                   from "@angular/common";
import { NgbCarouselConfig, NgbCarousel  }            from "@ng-bootstrap/ng-bootstrap";
import { digitalizacaoSerializer }                    from "src/app/model/digitalizacao/digitalizacaoSerialize";
import { digitalizacao }                              from "src/app/model/digitalizacao/digitalizacao";
import { DigitalizacaoService }                       from "../../services/digitalizacao.service";
import { MatSnackBar, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { Component, OnInit, ViewChild, Inject}        from "@angular/core";
import * as $                                         from "jquery";
import { CDDScanner }                                 from "../../../../../assets/javascript/cddscanner";

declare let   $:any;
let           _Images = [];

@Component({ 
    selector: "app-digitalizacao",
    templateUrl: "./digitalizacao.component.html", 
    styleUrls: ["./digitalizacao.component.scss"] 
}) 
export class DigitalizacaoComponent implements OnInit {

    @ViewChild('mycarousel', {static : true}) carousel: NgbCarousel;
    
    ///Variaveis
    private _digitalizacao = new digitalizacao();
    private _digitalizacaoSerializer = new digitalizacaoSerializer();

    _config: NgbCarouselConfig;

    _environment;
    event_list = [];
    upcoming_events =  [];
    _paramtroEntrada;
  
    constructor(@Inject(MAT_DIALOG_DATA) public dados:any, public snackBar:MatSnackBar, private datePipe:DatePipe, private digitalizacaoService:DigitalizacaoService, public modal:MatDialogRef<DigitalizacaoComponent>) { 
        this._config = new NgbCarouselConfig
        this._config.interval = 8000;
        this._config.wrap = false;
        this._config.keyboard = false;
        this._config.pauseOnHover = false;
        this._config.showNavigationArrows = true;
        this._config.showNavigationIndicators = true;
        this._environment = environment;
        this._paramtroEntrada = window.atob(dados.dadosBase64); // decode do base64
    }

    ngOnInit() {
        CDDScanner().clear(); 
        try {
            this._digitalizacao = this._digitalizacaoSerializer.fromJson(JSON.parse(this._paramtroEntrada));  /// Cria a classe digitaliza��o para armazenar os dados deserializados.
        } 
        catch (error) {
            this.EnviarMensagem(error, "Erro"); /// Desabilitar os botoes do formulario para n�o ser possivel digitalizar.
        }
    }
 
    Next(){
        this.carousel.next();
    }

    /// teste de Base64 passando um Json encripitado.
    teste(){
        let teste:string = "{ \"CodLoja\": \"2010\", \"codigoSistema\": \"2\",  \"codigoDocumento\": \"20\",  \"codigoFuncao\": \"7\",  \"codigoExterno\": \"34803281807\",  \"codigoUsuarioUpload\": \"203419\",  \"origem\": \"CPF121249\", \"nomeArquivo\": \"RG121249.34803281807.20191211_121249813.PDF\", \"diretorioDestinoDoc\": \"\\\\\\\\crefisa.com.br\\\\root\\\\gedchk\\\\\", \"urlImg\" : \"http:\\\\centraldenegocios.adobenet.com.br/fotos/\", \"endPointBanco\" : \"https://teste.com.br/IncluirDocumento\" }";
        
        //encode binary to ascii
        var enc = window.btoa(teste); // eyAiQ29kTG9qYSI6ICIyMDEwIiwgImNvZGlnb1Npc3RlbWEiOiAiMiIsICAiY29kaWdvRG9jdW1lbnRvIjogIjIwIiwgICJjb2RpZ29GdW5jYW8iOiAiNyIsICAiY29kaWdvRXh0ZXJubyI6ICIzNDgwMzI4MTgwNyIsICAiY29kaWdvVXN1YXJpb1VwbG9hZCI6ICIyMDM0MTkiLCAgIm9yaWdlbSI6ICJDUEYxMjEyNDkiLCAibm9tZUFycXVpdm8iOiAiUkcxMjEyNDkuMzQ4MDMyODE4MDcuMjAxOTEyMTFfMTIxMjQ5ODEzLlBERiIsICJkaXJldG9yaW9EZXN0aW5vRG9jIjogIlxcXFxjcmVmaXNhLmNvbS5iclxccm9vdFxcZ2VkY2hrXFwiLCAidXJsSW1nIiA6ICJodHRwOlxcY2VudHJhbGRlbmVnb2Npb3MuYWRvYmVuZXQuY29tLmJyL2ZvdG9zLyIsICJlbmRQb2ludEJhbmNvIiA6ICJodHRwczovL3Rlc3RlLmNvbS5ici9JbmNsdWlyRG9jdW1lbnRvIiB9
        
        //decode ascii to binary
        var dec = window.atob(enc);
        console.info("Encoded String: " + enc + "<br>" + "Decoded String: " + dec);
    }

    digitalizarPagina() {
        let x = $("#ImageContainer").find(".carousel-indicators").find(".active").index();
        this.digitalizar(x);
    }

    removerPagina = function(index){
        this.upcoming_events.splice(index, 1);
    }

    salvarDocumento() {
        CDDScanner().saveDocument(
            this._environment.URLService
            , this._digitalizacao.DiretorioDestinoDoc + this._digitalizacao.CodigoExterno + "\\"
            , this._digitalizacao.NomeArquivo
            ,{parametros:
                {'Size':'A4'
                ,'Properties':{
                    'Title': 'Documento'
                    ,'Author':'Crefisa'
                    ,'Subject':'Documento'
                    ,'Keywords': this._digitalizacao.CodigoExterno 
                }
                }                
            ,onSucesso(e) {
            this.successMessage = "Digitalização salva com sucesso!";
            }
            ,onErro: function(e){
                this.successMessage = "Ocorreu o seguinte erro: " + e.Message;
            }
        })

        let _year  = this.datePipe.transform(new Date(),"yyyy");
        let _month = this.datePipe.transform(new Date(),"MM");
        let _day   = this.datePipe.transform(new Date(),"dd");

        this._digitalizacao.CaminhoArquivo = this._digitalizacao.DiretorioDestinoDoc +
                                            this._digitalizacao.CodigoExterno +'\\'+
                                            _year+'\\'+_month+'\\'+_day+'\\'+
                                            this._digitalizacao.NomeArquivo
        ;
        this._digitalizacao.UrlArquivo     = this._digitalizacao.UrlImg +
                                            this._digitalizacao.CodigoExterno + '/' +
                                            _year+'/'+_month+'/'+_day+'/'+
                                            this._digitalizacao.NomeArquivo
        ;
        /// Receber parametro via API
        this.digitalizacaoService.documentoApi(this._digitalizacao.EndPointBanco, this._digitalizacaoSerializer.toJson(this._digitalizacao)).pipe(first())
        .subscribe(
            data  => { let Id = data.data; }, 
            error => { this.EnviarMensagem("Não foi possivel salvar : "+this._digitalizacao.EndPointBanco, "erro"); }
        );   
    }

    digitalizar(pagina) {
        let _upcoming_events = this.upcoming_events;
        CDDScanner().scannedPageList[pagina] = null;
        CDDScanner().setQualityLevel(40);
        CDDScanner().scannedPageList[pagina] = CDDScanner().createPage({
            imagem: {
                'container': 'img' + pagina,
                'height': '350px',
                'width': '350px'
            },
            parametros: {
                'BarCodeType': this._environment.BarCodeType,
                'ShowTransfer': true,
                'Horizontal Resolution': this._environment.ImageResolution,
                'Vertical Resolution': this._environment.ImageResolution
            },
            onErro: function (e) {
                this.EnviarMensagem(e.Message, "Erro");   
            },
            onSucesso: function () {
            let src = CDDScanner().scannedPageList[pagina].opcoes.url + '/img/' + CDDScanner().scannedPageList[pagina].cID + '.jpeg';

            _upcoming_events.push({
                event:' Event '+pagina,
                img: src,
                alt: src,
                eventStartDate : new Date('2019/07/28'),
                eventEndingDate: new Date('2019/07/30')
            });
            }
        });
        if(CDDScanner().scannedPageList[pagina]){
            CDDScanner().scannedPageList[pagina].scan();
        }
    }

    EnviarMensagem(message: string, action: string) {
        this.snackBar.open(message, action, { duration: 5000, horizontalPosition: "right", verticalPosition: "top"} );
    }

    public fechar():void {
        this.modal.close("o componente digitalização foi fechado");
    }

}
