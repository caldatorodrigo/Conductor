import { Component, OnInit } from '@angular/core';
import { FilasAnalise } from '../../filas/components/analise/example-data';
import { ArrayDataSource } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import { FilasService } from '../../filas/filas.service';
import { map, tap } from 'rxjs/operators';

@Component({
  selector: 'app-tree',
  templateUrl: './tree.component.html',
  styleUrls: ['./tree.component.scss']
})
export class TreeComponent implements OnInit {
  treeControl = new NestedTreeControl<FilasAnalise>(node => node.filaStatus);
  dataSources = [];
  filasContext = [];
  solicitacoes = [
  ];

  hasChild = (_: number, node: FilasAnalise) =>
    !!node.filaStatus && node.filaStatus.length > 0;

  constructor(public filasService: FilasService) {}

  mapContext(contexts) {
    return contexts.map(item => {
      return {
        contexto: item.contexto,
        filas: this.mapFilas(item.filas)
      };
    });
  }

  mapFilas(filas: FilasAnalise[], codTpfila?) {
    return filas.map(fila => {
      if (fila.filaStatus && fila.filaStatus.length > 0) {
        this.mapFilas(fila.filaStatus, fila.codTpfila);
      } else if (codTpfila) {
        fila.codTpfila = codTpfila;
      }
      return fila;
    });
  }

  ngOnInit() {
    this.filasService
      .getFilaCentralizadora()
      .pipe(
        map(res =>
          res.data
            ? this.mapContext(res.data)
            : []
        )
      )
      .subscribe(context => {
        this.filasContext = context;
        this.filasContext.map(context => {
          this.dataSources.push(new ArrayDataSource(context.filas));
          return {contexto: context.context}
        })
      });
  }

  consultar(tpFila, codStatus) {
    this.filasService.getFilaStatus(tpFila, codStatus)
    .then(solicitacoes => {
      this.solicitacoes = solicitacoes;
    });
  }
}
