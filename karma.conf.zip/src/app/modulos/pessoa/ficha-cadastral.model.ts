export interface FichaCadastralConfig {
  key: string;
  active?: boolean;
  title?: string;
  isNew?: boolean;
  className?: string;
  selectedModuleKey?: string;
  disabledAll?: boolean;
  openAll?: boolean;
  end?: (params) => any;
}

export interface FichaCadastralConfigModule {
  disabledForm?: boolean;
  key?: string;
  className?: string;
  title?: string;
  active?: boolean;
  prosseguir?: (params) => any;
  alterar?: (params) => any;
}
