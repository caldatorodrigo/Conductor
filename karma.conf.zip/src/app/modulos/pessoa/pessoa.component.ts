import {
  Component,
  OnInit,
  Inject,
  forwardRef,
  Input,
  Output,
  EventEmitter,
  SimpleChanges,
  OnChanges,
  ViewChild
} from '@angular/core';
import { MatCheckboxChange, MatSelectChange } from '@angular/material';
import { AlertService } from 'src/app/shared/services/alert.service';
import { util, compare } from 'src/app/core/utils/util';
import { PageScrollService } from 'ngx-page-scroll-core';
import { DOCUMENT } from '@angular/common';
import { PessoaModel } from 'src/app/model/pessoa/pessoa.model';
import { PessoaFisicaModel } from 'src/app/model/pessoa/pessoa-fisica.model';
import { PessoaPatrimonioModel } from 'src/app/model/pessoa/pessoa-patrimonio.model';
import { PessoaService } from 'src/app/modulos/pessoa/services/pessoa.service';
import { PessoaDocumentoModel } from 'src/app/model/pessoa/pessoa-documento.model';
import { PessoaEnderecoModel } from 'src/app/model/pessoa/pessoa-endereco.model';
import { PessoaEmailModel } from 'src/app/model/pessoa/pessoa-email.model';
import { PessoaTelefoneModel } from 'src/app/model/pessoa/pessoa-telefone.model';
import { PessoaRelativoModel } from 'src/app/model/pessoa/pessoa-relativo.model';
import { PessoaFATCAModel } from 'src/app/model/pessoa/pessoa-fatca.model';
import { PessoaPEPModel } from 'src/app/model/pessoa/pessoa-pep.model';
import {
  ControlValueAccessor,
  NG_VALUE_ACCESSOR,
  NgForm,
  ValidationErrors
} from '@angular/forms';

import { tap } from 'rxjs/operators';
import {
  FichaCadastralConfig,
  FichaCadastralConfigModule
} from './ficha-cadastral.model';
import { TipoRelacaoModel } from 'src/app/model/tipos/tipo-relacao.model';
@Component({
  selector: 'app-pessoa',
  templateUrl: './pessoa.component.html',
  styleUrls: ['./pessoa.component.scss'],
  exportAs: 'pessoaComp'
})
export class PessoaComponent implements OnInit, OnChanges {
  @Input() pessoa: PessoaModel;
  @Input() fichaCadastralConfig: FichaCadastralConfig;
  @Output() endPessoaFicha = new EventEmitter();
  submitted = false;
  backupPatrimonios = [];

  @Input() isContaCorrente = false;

  public modulesConfig: FichaCadastralConfigModule[] = [
    {
      key: 'dadosPessoais',
      disabledForm: false,
      className: 'dados-pessoais',
      title: 'Dados Pessoais',
      active: true
    },
    {
      key: 'dadosPessoaisCont',
      disabledForm: true,
      className: 'dados-pessoais-cont',
      title: 'Dados Pessoais (Continuação)',
      active: false
    },
    {
      key: 'enderecos',
      disabledForm: true,
      className: 'enderecos',
      title: 'Endereços',
      active: false
    },
    {
      key: 'contato',
      disabledForm: true,
      className: 'contato',
      title: 'Contato',
      active: false
    },
    {
      key: 'patrimonio',
      disabledForm: true,
      className: 'patrimonio',
      title: 'Patrimônio',
      active: false
    },
    {
      key: 'fatca',
      disabledForm: true,
      className: 'fatca',
      title: 'FATCA',
      active: false
    },
    {
      key: 'pep',
      disabledForm: true,
      className: 'pep',
      title: 'PEP - Pessoa Exposta Politicamente',
      active: false
    }
  ];

  selectLists = {
    ufList: [],
    cidadeList: [],
    tiposResidenciaList: [],
    tiposEstadoCivilList: [],
    profissaoList: [],
    documentoPessoaList: [],
    tiposPatrimoniosList: []
  };

  multiValuesSelects = {
    selectedUfs: [],
    selectedCidades: [],
    selectedTiposResidencia: []
  };

  utilServices = {
    findUFs: () => util.pipeMapArray(this.pessoaService.getAllUF()),
    findCidadesByUF: uf =>
      util.pipeMapArray(this.pessoaService.getCidadePorUF(uf)),
    findTiposResidencia: () =>
      util.pipeMapArray(this.pessoaService.getAllTipoResidencia()),
    findTipoEstadoCivil: () =>
      util.pipeMapArray(this.pessoaService.getAllEstadoCivil()),
    findProfissao: () =>
      util.pipeMapArray(this.pessoaService.listaProfissoes()),
    findTiposDocumentoPessoa: () =>
      util.pipeMapArray(this.pessoaService.getAllTiposDocumentoPessoa()),
    findTiposPatrimonio: () =>
      util.pipeMapArray(this.pessoaService.getAllTiposPatrimonio())
  };

  model: {} = {
    documentoAdicional: this.documentoAdicional(),
    rg: this.rg(),
    relativos: this.relativos()
  };

  constructor(
    private pessoaService: PessoaService,
    private alertService: AlertService,
    private pageScrollService: PageScrollService,
    @Inject(DOCUMENT) private document: any
  ) {}

  moduleFicha(key): FichaCadastralConfigModule {
    return this.modulesConfig.find(el => el.key === key);
  }

  ngOnInit() {}

  classNameModule(keyModule) {
    return `${this.fichaCadastralConfig.key}-${
      this.moduleFicha(keyModule).className
    }`;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes.pessoa && changes.pessoa.currentValue !== null) {
      this.findDataSelect();
      this.checkRelativos();
    }
  }

  updateCidades() {
    this.pessoa.enderecos.forEach(el => {
      this.getCidades(el.slgUf);
    });
  }

  rg() {
    const doc = this.pessoa
      ? this.pessoa.documentos.find(
          el => el.tpoDocumento && el.tpoDocumento.descricao === 'RG'
        )
      : ({} as PessoaDocumentoModel);

    return !!doc ? doc : ({} as PessoaDocumentoModel);
  }

  documentoAdicional() {
    const doc = this.pessoa
      ? this.pessoa.documentos.find(
          el => el.tpoDocumento && el.tpoDocumento.descricao !== 'RG'
        )
      : ({} as PessoaDocumentoModel);

    return !!doc ? doc : ({} as PessoaDocumentoModel);
  }

  relativos() {
    const relativos: {
      relativoMae: PessoaRelativoModel;
      relativoPai: PessoaRelativoModel;
      conjuge: PessoaRelativoModel;
    } = {
      relativoMae: {} as PessoaRelativoModel,
      relativoPai: {} as PessoaRelativoModel,
      conjuge: {} as PessoaRelativoModel
    };

    if (this.pessoa) {
      const findRelativo = cod =>
        this.pessoa.relativos.find(
          rel => rel.tpoRelacao.codTiporelacao === cod
        );

      relativos.relativoMae = findRelativo(254);
      relativos.relativoPai = findRelativo(253);
      relativos.conjuge = findRelativo(257);
    }

    relativos.relativoMae = relativos.relativoMae
      ? relativos.relativoMae
      : { nomPessoarelativo: ' ' };
    relativos.relativoPai = relativos.relativoPai
      ? relativos.relativoPai
      : { nomPessoarelativo: ' ' };
    relativos.conjuge = relativos.conjuge
      ? relativos.conjuge
      : { nomPessoarelativo: ' ' };

    return relativos;
  }

  checkEmails() {
    if (
      !this.pessoa.emails ||
      (this.pessoa.emails && this.pessoa.emails.length === 0)
    ) {
      this.alertService.setLoading(true);
      const newEmail = {
        codPessoa: this.pessoa.codPessoa,
        codPessoaemail: 0,
        desEmail: ' ',
        flgAtivo: true,
        flgPessoal: true
      } as PessoaEmailModel;
      util
        .promiseMapObject(this.pessoaService.inserirPessoaEmail(newEmail))
        .then(res => {
          if (res) {
            newEmail.codPessoaemail = res;
            this.pessoa.emails.push(newEmail);
          }
        })
        .finally(() => {
          this.alertService.setLoading(false);
          this.pessoa.emails.push(newEmail);
        });
    }
  }


  checkTelefones() {
    if (
      !this.pessoa.telefones ||
      (this.pessoa.telefones && this.pessoa.telefones.length === 0)
    ) {
      this.alertService.setLoading(true);
      const newTelefone = {
        codPessoa: this.pessoa.codPessoa,
        codPessoatelefone: 0,
        flgAtivo: true,
        numDdd: ' ',
        numTelefone: ' '
      } as PessoaTelefoneModel;
      util
        .promiseMapObject(this.pessoaService.inserirPessoaTelefone(newTelefone))
        .then(res => {
          if (res) {
            newTelefone.codPessoatelefone = res;
            this.pessoa.telefones.push(newTelefone);
          }
        })
        .finally(() => {
          this.alertService.setLoading(false);
          this.pessoa.telefones.push(newTelefone);
        });
    }
  }

  checkEnderecos() {
    if (
      !this.pessoa.enderecos ||
      (this.pessoa.enderecos && this.pessoa.enderecos.length === 0)
    ) {
      this.alertService.setLoading(true);
      const newEndereco = {
        codPessoa: this.pessoa.codPessoa,
        flgAtivo: true
      } as PessoaEnderecoModel;
      util
        .promiseMapObject(this.pessoaService.inserirPessoaEndereco(newEndereco))
        .then(res => {
          if (res) {
            newEndereco.codPessoaendereco = res;
            this.pessoa.enderecos.push(newEndereco);
          }
        })
        .finally(() => {
          this.alertService.setLoading(false);
          this.pessoa.emails.push(newEndereco);
        });
    }
  }

  checkTiposPatrimonio() {
    const listPatrimonios: PessoaPatrimonioModel[] = [];
    this.alertService.setLoading(false);
    Promise.all(
      this.selectLists.tiposPatrimoniosList
        .filter(el => {
          return !this.pessoa.patrimonios
            .map(p => p.tipo.codigo)
            .includes(el.codigo);
        })
        .map(tp => {
          const pessoaPatrimonio = {} as PessoaPatrimonioModel;
          pessoaPatrimonio.codPessoa = this.pessoa.codPessoa;
          pessoaPatrimonio.vlrEstimado = 0;
          pessoaPatrimonio.ativo = true;
          pessoaPatrimonio.tipo = tp;

          listPatrimonios.push(pessoaPatrimonio);

          return util.promiseMapObject(
            this.pessoaService.inserirPessoaPatrimonio(pessoaPatrimonio)
          );
        })
    )
      .then(res => {
        for (let i = 0; i < res.length; i++) {
          listPatrimonios[i].codPessoaPatrimonio = res[i];
          this.pessoa.patrimonios.push(listPatrimonios[i]);
        }
      })
      .finally(() => this.alertService.setLoading(false));
  }

  checkRelativos() {
    const promisesRelativo = [];
    if (!this.relativos().relativoMae.codPessoa) {
      const newRelativo = this.novoRelativo(
        'F',
        this.relativos().relativoMae.nomPessoarelativo,
        this.pessoa.codPessoa,
        254
      );
      promisesRelativo.push({
        model: newRelativo,
        key: 'relativoMae',
        codTiporelacao: 254
      });
    }

    if (!this.relativos().relativoPai.codPessoa) {
      const newRelativo = this.novoRelativo(
        'M',
        this.relativos().relativoPai.nomPessoarelativo,
        this.pessoa.codPessoa,
        253
      );
      promisesRelativo.push({
        model: newRelativo,
        key: 'relativoPai',
        codTiporelacao: 253
      });
    }

    if (!this.relativos().conjuge.codPessoa) {
      const newRelativo = this.novoRelativo(
        'M',
        this.relativos().conjuge.nomPessoarelativo,
        this.pessoa.codPessoa,
        257
      );
      promisesRelativo.push({
        model: newRelativo,
        key: 'conjuge',
        codTiporelacao: 253
      });
    }

    if (promisesRelativo.length > 0) {
      this.alertService.setLoading(true);
      Promise.all(
        promisesRelativo.map(
          el =>
            new Promise((resolve, reject) => {
              util
                .promiseMapObject(
                  this.pessoaService.inserirPessoaRelativo(el.model)
                )
                .then(res => {
                  if (res) {
                    el.model.codPessoarelativo = res;
                    // this.relativos()[el.key] = el.model;
                    this.setRelativo(el.codTipo, el.model);
                  }
                  resolve(res);
                })
                .catch(err => reject(err));
            })
        )
      ).finally(() => this.alertService.setLoading(false));
    }
  }

  setRelativo(cod, relativo) {
    this.pessoa.relativos.forEach(r => {
      if (r.tpoRelacao.codTiporelacao === cod) {
        r = relativo;
      }
    });
  }

  newPromise(promise: Promise<any>): Promise<any> {
    return new Promise((resolve, reject) =>
      promise.then(resolve).catch(reject)
    );
  }

  novoRelativo(sexo, nomRelativo, codPessoa, codTiporelacao) {
    const relativo: PessoaRelativoModel = {};
    relativo.codPessoa = codPessoa;
    relativo.slgSexo = sexo;
    relativo.nomPessoarelativo = nomRelativo;
    relativo.nomPessoarelativo = relativo.nomPessoarelativo.toUpperCase();

    const tipoRelacao: TipoRelacaoModel = {};
    tipoRelacao.codTiporelacao = codTiporelacao;
    tipoRelacao.flgAtivo = true;
    relativo.tpoRelacao = tipoRelacao;
    return relativo;
  }

  compareSelect = tipo => compare[tipo];

  findDataSelect() {
    this.alertService.setLoading(true);
    const promises = [
      this.newPromise(
        this.utilServices
          .findTiposResidencia()
          .pipe(tap(res => (this.selectLists.tiposResidenciaList = res)))
          .toPromise()
      ),
      new Promise((resolve, reject) => {
        this.utilServices
          .findTipoEstadoCivil()
          .pipe(tap(res => (this.selectLists.tiposEstadoCivilList = res)))
          .toPromise()
          .then(resolve)
          .catch(reject);
      }),

      new Promise((resolve, reject) => {
        this.utilServices
          .findProfissao()
          .pipe(tap(res => (this.selectLists.profissaoList = res)))
          .toPromise()
          .then(resolve)
          .catch(reject);
      }),

      new Promise((resolve, reject) => {
        this.utilServices
          .findTiposDocumentoPessoa()
          .pipe(tap(res => (this.selectLists.documentoPessoaList = res)))
          .toPromise()
          .then(resolve)
          .catch(reject);
      }),

      new Promise((resolve, reject) => {
        this.utilServices
          .findTiposPatrimonio()
          .pipe(tap(res => (this.selectLists.tiposPatrimoniosList = res)))
          .toPromise()
          .then(resolve)
          .catch(reject)
          .finally(() => this.checkTiposPatrimonio());
      }),

      this.getUF()
    ];

    Promise.all(promises)
      .catch(err => {
        this.alertService.dispatch(
          'Houve um erro ao recuperar os dados para cadastro!'
        );
      })
      .finally(() => {
        this.alertService.setLoading(false);
        this.updateCidades();
        this.checkEmails();
        this.checkTelefones();
        this.checkEnderecos();
      });
  }

  hasPatrimonio() {
    return this.pessoa.patrimonios && this.pessoa.patrimonios.length > 0;
  }

  changePatrimonio(event: MatCheckboxChange) {
    if (event.checked) {
      this.pessoa.patrimonios = this.backupPatrimonios;
      this.backupPatrimonios = [];
    } else {
      this.backupPatrimonios = this.pessoa.patrimonios;
      this.pessoa.patrimonios = [];
    }
  }

  changeDadosFatca(event: MatCheckboxChange) {
    if (event.checked) {
      this.pessoa.dadosFATCA = {} as PessoaFATCAModel;
      this.scrollTo(this.moduleFicha('fatca').className);
    } else {
      this.pessoa.dadosFATCA = undefined;
    }
  }
  hasDadosFatca() {
    return !!this.pessoa.dadosFATCA;
  }

  dadosFatca() {
    return this.pessoa.dadosFATCA;
  }

  changeDadosPep(event: MatCheckboxChange) {
    if (event.checked) {
      this.pessoa.dadosPEP = {} as PessoaPEPModel;
      this.scrollTo(this.moduleFicha('pep').className);
    } else {
      this.pessoa.dadosPEP = undefined;
    }
  }

  dadosPep() {
    return this.pessoa.dadosPEP;
  }

  hasDadosPep() {
    return !!this.pessoa.dadosPEP;
  }

  scrollTo(className) {
    setTimeout(() => {
      this.pageScrollService.scroll({
        document: this.document,
        scrollTarget: '.' + className,
        speed: 200
      });
    }, 700);
  }

  salvarRequest(next, isEnd?) {
    this.salvarPessoa()
      .then((res: any) => {
        if (res && res.data) {
          if (isEnd && this.fichaCadastralConfig.end) {
            this.fichaCadastralConfig.end(true);
            this.moduleFicha('pep').disabledForm = true;
          } else {
            this.enableForm(next);
          }
        } else {
          this.alertService.dispatch(res.exceptionMessage);
        }
      })
      .finally(() => {
        this.alertService.setLoading(false);
        this.submitted = false;
      });
  }

  salvar(form: NgForm, next, current) {
    this.submitted = true;
    if (!form.invalid) {
      const dirty = form.dirty;
      const isEnd = next === '';

      switch (next) {
        case 'patrimonio':
          break;
        default:
          break;
      }

      if (!dirty) {
        if (isEnd && this.fichaCadastralConfig.end) {
          this.fichaCadastralConfig.end(true);
          this.moduleFicha(current).disabledForm = true;
        } else {
          this.enableForm(next);
        }
      } else {
        this.alertService.setLoading(true);
        this.salvarRequest(next, isEnd);
      }
    } else {
      Object.keys(form.controls).forEach(key => {
        const controlErrors: ValidationErrors = form.controls[key].errors;
        if (controlErrors != null) {
          Object.keys(controlErrors).forEach(keyError => {
            console.log(
              'Key control: ' +
                key +
                ', keyError: ' +
                keyError +
                ', err value: ',
              controlErrors[keyError]
            );
          });
        }
      });
    }
  }

  enableForm(next) {
    const selectedModuleKey = next;
    const moduleSelected = this.moduleFicha(selectedModuleKey);
    moduleSelected.disabledForm = false;
    moduleSelected.active = true;

    this.modulesConfig
      .filter(m => m.key !== selectedModuleKey)
      .forEach(m => (m.disabledForm = true));

    if (moduleSelected) {
      this.scrollTo(this.classNameModule(next));
      if (moduleSelected.prosseguir) {
        moduleSelected.prosseguir(next);
      }
    }
  }

  getCidades(uf) {
    this.selectLists.cidadeList = [];
    this.utilServices
      .findCidadesByUF(uf)
      .toPromise()
      .then(res => {
        const listaSelecionada = this.selectLists.cidadeList.find(
          list => list.uf === uf
        );
        if (!listaSelecionada) {
          this.selectLists.cidadeList.push({ uf, list: res });
        }
      });
  }

  getUF() {
    return new Promise((resolve, reject) => {
      this.utilServices
        .findUFs()
        .pipe(
          tap(res => {
            this.selectLists.ufList = res;
            /*this.pessoa.enderecos.forEach(end => {
              const ufSelecionada = this.selectLists.ufList.find(
                uf => uf.uf === end.slgUf
              );
              if (ufSelecionada) {
                this.multiValuesSelects.selectedUfs.push(ufSelecionada);
              }
            });*/
          })
        )
        .toPromise()
        .then(resolve);
    });
  }

  end(current) {
    this.fichaCadastralConfig.end(this.pessoa);
    this.modulesConfig.forEach(m => (m.disabledForm = true));
    if (this.fichaCadastralConfig.end) {
      this.fichaCadastralConfig.end('end');
    }
  }

  listaCidade(end) {
    const find = this.selectLists.cidadeList.find(
      list => list.uf === end.slgUf
    );
    return find ? find.list : [];
  }

  selectedCidadeModel(end) {
    return this.listaCidade(end)
      ? this.listaCidade(end).find(cidade => cidade.desCidade === end.desCidade)
      : {};
  }

  selectedCidadeModelChange(end, event: any) {
    end.desCidade = event.desCidade;
  }

  selectedUfModel(end) {
    return this.selectLists.ufList.find(uf => uf.uf === end.slgUf);
  }

  selectedUfModelChange(end, event: any) {
    end.slgUf = event.uf;
    this.getCidades(event.uf);
  }

  salvarPessoa() {
    return this.pessoaService.atualizarPessoa(this.pessoa).toPromise();
  }
}
