import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PessoaComponent } from './pessoa.component';
import { SharedModule } from '../../shared/shared.module';
import { PessoaService } from './services/pessoa.service';

@NgModule({
  declarations: [PessoaComponent],
  exports: [PessoaComponent],
  imports: [CommonModule, SharedModule],
  providers: [PessoaService]
})
export class PessoaModule {}
