import { Injectable } from '@angular/core';
import {
  HttpHeaders,
  HttpErrorResponse,
  HttpClient
} from '@angular/common/http';
import { catchError, retry, map } from 'rxjs/operators';
import { throwError, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { analyzeAndValidateNgModules } from '@angular/compiler';
import { PessoaModel } from 'src/app/model/pessoa/pessoa.model';
import { PessoaRelativoModel } from 'src/app/model/pessoa/pessoa-relativo.model';

var httpOptions = {
  headers: new HttpHeaders()
};

@Injectable()
export class PessoaService {
  API_PESSOA_SERVER_NAME: string;
  API_INSS_SERVER_NAME: string;
  BASE_URL_API = 'api';

  constructor(private httpClient: HttpClient) {
    this.API_PESSOA_SERVER_NAME = environment.API_PESSOA_SERVER_NAME;
    this.API_INSS_SERVER_NAME = environment.API_INSS_SERVER_NAME;
    httpOptions.headers.set('Access-Control-Allow-Origin', '*');
    httpOptions.headers.set('Content-Type', 'application/json');
  }

  public listaProfissoes(): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/TipoProfissao/v1/consultar-todos`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public getAllEstadoCivil(): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/TipoEstadoCivil/v1/consultar-todos`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public getAllUF(): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/Estado/v1/consultar-todos`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public getCidadePorUF(uf: string): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/Cidade/v1/consultar-por-uf/${uf}`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public getAllTipoResidencia(): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/TipoResidencia/v1/consultar-todos`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public handleErrorT(error: HttpErrorResponse) {
    return Observable.throw(error.message || 'Server Error');
  }

  public atualizarPessoa(pessoa: PessoaModel) {
    return this.httpClient.put(
      `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/Pessoa/v1/alterar-completo`,
      pessoa
    );
  }

  public atualizarPessoaFisica(dadosPessoaFisica: any) {
    console.log(
      'atualizarPessoaFisica dadosPessoaFisica=' +
        JSON.stringify(dadosPessoaFisica)
    );
    this.httpClient
      .put<any>(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaFisica/v1/atualizar`,
        dadosPessoaFisica
      )
      .subscribe(
        resp => {
          console.log('respPut atualizarPessoaFisica=' + JSON.stringify(resp));
        },
        err =>
          console.error('erro em atualizarPessoaFisica:' + JSON.stringify(err))
      );
  }

  public inserirPessoaFisica(dadosPessoaFisica: any) {
    console.log(
      'inserirPessoaFisica dadosPessoaFisica=' +
        JSON.stringify(dadosPessoaFisica)
    );
    this.httpClient
      .post(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaFisica/v1/inserir`,
        dadosPessoaFisica
      )
      .subscribe(
        resp => {
          console.log('respPut inserirPessoaFisica=' + JSON.stringify(resp));
        },
        err =>
          console.error('erro em inserirPessoaFisica:' + JSON.stringify(err))
      );
  }

  public inserirPessoaRelativo(pessoaRelativo: any) {
    return this.httpClient.post<any>(
      `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaRelativo/v1/inserir`,
      pessoaRelativo
    );
  }

  public atualizarPessoaRelativo(pessoaRelativo: any) {
    console.log(
      '_atualizarPessoaRelativo pessoaRelativo=' +
        JSON.stringify(pessoaRelativo)
    );
    this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaRelativo/v1/alterar`,
        pessoaRelativo
      )
      .subscribe(
        resp => {
          console.log('respPut=' + resp);
        },
        err => console.error('erro em atualizarPessoaRelativo' + err)
      );
    //.pipe();
  }

  public getAllTipoMeioPagamento(): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_API}/TipoMeioPagamento/v1/consultar-todos`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public inserirPessoaEndereco(pessoaEndereco: any) {
    return this.httpClient
      .post(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaEndereco/v1/inserir`,
        pessoaEndereco
      )
  }


  public atualizarPessoaEndereco(pessoaEndereco: any) {
    return this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaEndereco/v1/alterar`,
        pessoaEndereco
      )
      .toPromise();
  }

  public inserirPessoaDocumento(pessoaDocumento: any) {
    console.log(
      'inserirPessoaDocumento pessoaDocumento=' +
        JSON.stringify(pessoaDocumento)
    );
    this.httpClient
      .post(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaDocumento/v1/inserir`,
        pessoaDocumento
      )
      .subscribe(
        resp => {
          console.log(
            'respPost inserirPessoaDocumento=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error('erro em inserirPessoaDocumento' + JSON.stringify(err))
      );
  }

  public atualizarPessoaDocumento(pessoaDocumento: any) {
    console.log(
      'atualizarPessoaDocumento pessoaDocumento=' +
        JSON.stringify(pessoaDocumento)
    );
    this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaDocumento/v1/alterar`,
        pessoaDocumento
      )
      .subscribe(
        resp => {
          console.log(
            'respPost atualizarPessoaDocumento=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em atualizarPessoaDocumento' + JSON.stringify(err)
          )
      );
  }

  public inserirPessoaTelefone(pessoaTelefone: any) {
    return this.httpClient
      .post(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaTelefone/v1/inserir`,
        pessoaTelefone
      )
  }

  public atualizarPessoaTelefone(pessoaTelefone: any) {
    console.log(
      'atualizarPessoaTelefone pessoaTelefone=' + JSON.stringify(pessoaTelefone)
    );
    this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaTelefone/v1/alterar`,
        pessoaTelefone
      )
      .subscribe(
        resp => {
          console.log(
            'respPost atualizarPessoaTelefone=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error('erro em atualizarPessoaTelefone' + JSON.stringify(err))
      );
  }

  public getAllTiposDocumentoPessoa(): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/Documento/v1/consultar-por-tipo/1/false`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public inserirPessoaEmail(pessoaEmail: any) {
    return this.httpClient
      .post(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaEmail/v1/inserir`,
        pessoaEmail
      )
  }

  public atualizarPessoaEmail(pessoaEmail: any) {
    console.log(
      'atualizarPessoaEmail pessoaEmail=' + JSON.stringify(pessoaEmail)
    );
    this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaEmail/v1/alterar`,
        pessoaEmail
      )
      .subscribe(
        resp => {
          console.log('respPost atualizarPessoaEmail=' + JSON.stringify(resp));
        },
        err =>
          console.error('erro em atualizarPessoaEmail' + JSON.stringify(err))
      );
  }

  public getAllTiposPatrimonio(): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/TipoPatrimonio/v1/consultar-todos`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public getPessoaPatrimonio(codigoPessoa: string): Observable<any> {
    return this.httpClient
      .get(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPatrimonio/v1/consultar/${codigoPessoa}`,
        httpOptions
      )
      .pipe(retry(3));
  }

  public getPessoaPatrimonioPromise(codigoPessoa: string): Promise<any> {
    return this.httpClient
      .get<any>(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPatrimonio/v1/consultar/${codigoPessoa}`,
        httpOptions
      )
      .pipe(
        map(res => {
          console.log('res=' + JSON.stringify(res.data));
          return res.data ? res.data : [];
        })
      )
      .toPromise();
  }

  public inserirPessoaPatrimonio(pessoaPatrimonio: any) {
    return this.httpClient.post<any>(
      `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPatrimonio/v1/inserir`,
      pessoaPatrimonio
    );
  }

  public atualizarPessoaPatrimonio(pessoaPatrimonio: any) {
    console.log(
      'atualizarPessoaPatrimonio pessoaPatrimonio=' +
        JSON.stringify(pessoaPatrimonio)
    );
    this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPatrimonio/v1/alterar`,
        pessoaPatrimonio
      )
      .subscribe(
        resp => {
          console.log(
            'respPost atualizarPessoaPatrimonio=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em atualizarPessoaPatrimonio=' + JSON.stringify(err)
          )
      );
  }

  public excluirPessoaPatrimonio(codigoPessoaPatrimonio: any) {
    console.log(
      'excluirPessoaPatrimonio pessoaPatrimonio=' +
        JSON.stringify(codigoPessoaPatrimonio)
    );
    this.httpClient
      .delete(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPatrimonio/v1/excluir/${codigoPessoaPatrimonio}`
      )
      .subscribe(
        resp => {
          console.log(
            'respPost excluirPessoaPatrimonio=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em excluirPessoaPatrimonio=' + JSON.stringify(err)
          )
      );
  }

  public getPessoaFATCAPromise(codigoPessoa: string): Promise<any> {
    return this.httpClient
      .get<any>(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaFatca/v1/consultar/${codigoPessoa}`,
        httpOptions
      )
      .pipe(
        map(res => {
          console.log('res=' + JSON.stringify(res.data));
          return res.data ? res.data : {};
        })
      )
      .toPromise();
  }

  public inserirPessoaFATCA(pessoaFATCA: any) {
    console.log(
      'inserirPessoaFATCA pessoaFATCA=' + JSON.stringify(pessoaFATCA)
    );
    this.httpClient
      .post(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaFatca/v1/inserir`,
        pessoaFATCA
      )
      .subscribe(
        resp => {
          console.log('respPost inserirPessoaFATCA=' + JSON.stringify(resp));
        },
        err =>
          console.error('erro em inserirPessoaFATCA=' + JSON.stringify(err))
      );
  }

  public atualizarPessoaFATCA(pessoaFATCA: any) {
    console.log(
      'atualizarPessoaFATCA pessoaFATCA=' + JSON.stringify(pessoaFATCA)
    );
    this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaFatca/v1/alterar`,
        pessoaFATCA
      )
      .subscribe(
        resp => {
          console.log('respPost atualizarPessoaFATCA=' + JSON.stringify(resp));
        },
        err =>
          console.error('erro em atualizarPessoaFATCA=' + JSON.stringify(err))
      );
  }

  public excluirPessoaFATCA(codigoPessoaFATCA: any) {
    console.log(
      'excluirPessoaFATCA codigoPessoaFATCA=' +
        JSON.stringify(codigoPessoaFATCA)
    );
    this.httpClient
      .delete(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaFatca/v1/excluir/${codigoPessoaFATCA}`
      )
      .subscribe(
        resp => {
          console.log('respPost excluirPessoaFATCA=' + JSON.stringify(resp));
        },
        err =>
          console.error('erro em excluirPessoaFATCA=' + JSON.stringify(err))
      );
  }

  public getPessoaPEPPromise(codigoPessoa: string): Promise<any> {
    return this.httpClient
      .get<any>(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPep/v1/consultar/${codigoPessoa}`,
        httpOptions
      )
      .pipe(
        map(res => {
          console.log('res=' + JSON.stringify(res.data));
          return res.data ? res.data : {};
        })
      )
      .toPromise();
  }

  public inserirPessoaPEP(pessoaPEP: any) {
    console.log('inserirPessoaPEP pessoaPEP=' + JSON.stringify(pessoaPEP));
    this.httpClient
      .post(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPep/v1/inserir`,
        pessoaPEP
      )
      .subscribe(
        resp => {
          console.log('respPost inserirPessoaPEP=' + JSON.stringify(resp));
        },
        err => console.error('erro em inserirPessoaPEP=' + JSON.stringify(err))
      );
  }

  public atualizarPessoaPEP(pessoaPEP: any) {
    console.log('atualizarPessoaPEP pessoaPEP=' + JSON.stringify(pessoaPEP));
    this.httpClient
      .put(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPep/v1/alterar`,
        pessoaPEP
      )
      .subscribe(
        resp => {
          console.log('respPost atualizarPessoaPEP=' + JSON.stringify(resp));
        },
        err =>
          console.error('erro em atualizarPessoaPEP=' + JSON.stringify(err))
      );
  }

  public excluirPessoaPEP(codigoPessoaPEP: any) {
    console.log(
      'excluirPessoaPEP codigoPessoaPEP=' + JSON.stringify(codigoPessoaPEP)
    );
    this.httpClient
      .delete(
        `${this.API_PESSOA_SERVER_NAME}/${this.BASE_URL_API}/PessoaPep/v1/excluir/${codigoPessoaPEP}`
      )
      .subscribe(
        resp => {
          console.log('respPost excluirPessoaPEP=' + JSON.stringify(resp));
        },
        err => console.error('erro em excluirPessoaPEP=' + JSON.stringify(err))
      );
  }
}
