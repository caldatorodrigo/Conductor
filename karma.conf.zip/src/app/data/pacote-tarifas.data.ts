export const PACOTE_TARIFAS = [
  {
    codPacote: '00001',
    dataVigenciaIni: '2019-01-01T00:00:00',
    dataVigenciaFim: '0001-01-01T00:00:00',
    descricaoPacote: 'PACOTE DE SERVIÇOS I',
    aplicacaoPessoa: 'F',
    valorPacote: '13,00',
    codHistG: '526',
    dataSist: '2018-12-05T00:00:00',
    codUsuario: 'CCM_215477',
    dataAtu: '2018-12-05T14:41:52'
  },
  {
    codPacote: '00002',
    dataVigenciaIni: '2019-01-01T00:00:00',
    dataVigenciaFim: '0001-01-01T00:00:00',
    descricaoPacote: 'PACOTE DE SERVIÇOS II',
    aplicacaoPessoa: 'F',
    valorPacote: '20,00',
    codHistG: '527',
    dataSist: '2018-12-05T00:00:00',
    codUsuario: 'CCM_215477',
    dataAtu: '2018-12-05T14:42:11'
  },
  {
    codPacote: '00003',
    dataVigenciaIni: '2019-01-01T00:00:00',
    dataVigenciaFim: '0001-01-01T00:00:00',
    descricaoPacote: 'PACOTE DE SERVIÇOS III',
    aplicacaoPessoa: 'F',
    valorPacote: '27,00',
    codHistG: '528',
    dataSist: '2018-12-05T00:00:00',
    codUsuario: 'CCM_215477',
    dataAtu: '2018-12-05T14:42:38'
  },
  {
    codPacote: '00004',
    dataVigenciaIni: '2019-01-01T00:00:00',
    dataVigenciaFim: '0001-01-01T00:00:00',
    descricaoPacote: 'PACOTE DE SERVIÇOS IV',
    aplicacaoPessoa: 'F',
    valorPacote: '42,00',
    codHistG: '529',
    dataSist: '2018-12-05T00:00:00',
    codUsuario: 'CCM_215477',
    dataAtu: '2018-12-05T14:42:58'
  },
  {
    codPacote: '00005',
    dataVigenciaIni: '2019-11-01T00:00:00',
    dataVigenciaFim: '0001-01-01T00:00:00',
    descricaoPacote: 'PACOTE CREFISA TESTE DIGITAL',
    aplicacaoPessoa: 'F',
    valorPacote: '13,00',
    codHistG: '537',
    dataSist: '2019-10-25T00:00:00',
    codUsuario: 'CCM_215477',
    dataAtu: '2019-10-28T16:34:54'
  },
  {
    codPacote: '99999',
    dataVigenciaIni: '2020-01-17T08:24:44.89',
    dataVigenciaFim: '2020-01-17T08:24:44.89',
    descricaoPacote: 'NENHUM PACOTE',
    aplicacaoPessoa: 'F',
    valorPacote: '0,00',
    codHistG: '999',
    dataSist: '2020-01-17T08:24:44.89',
    codUsuario: '216867',
    dataAtu: '2020-01-17T08:24:44.89'
  }
];
