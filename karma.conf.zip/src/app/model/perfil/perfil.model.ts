export interface PerfilModel { 
    codigo?: number;
    descricao?: string;
    codigoPerfilGestao?: number;
}
