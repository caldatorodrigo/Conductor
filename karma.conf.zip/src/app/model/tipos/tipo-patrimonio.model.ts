export interface TipoPatrimonioModel {
    codigo?:	        number;
    descricao?:	        string
    ativo?:	            boolean;
    usuarioInclusao?:	string;
    dataInclusao?:	    string;
    maquinaInclusao?:	string;
    origemInclusao?:	string;
    usuarioAlteracao?:	string;
    dataAlteracao?:	    string;
    maquinaAlteracao?:	string;
    origemAlteracao?:	string;
}