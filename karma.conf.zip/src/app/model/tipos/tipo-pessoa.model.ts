export interface TipoPessoaModel {
  codTipopessoa?: number;
  desTipopessoa?: string;
  flgAtivo?: boolean;
}
