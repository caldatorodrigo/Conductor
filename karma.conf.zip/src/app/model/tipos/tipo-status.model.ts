export interface StatusTipoModel { 
    codigo?: number;
    descricao?: string;
    ativo?:boolean;
}