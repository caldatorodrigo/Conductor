export interface TipoMeioPagamentoModel {
  codigo?: number;
  descricao?: string;
  ativo?: boolean;
}
