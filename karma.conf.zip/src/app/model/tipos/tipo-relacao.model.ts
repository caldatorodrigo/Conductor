export interface TipoRelacaoModel {
  codTiporelacao?: number;
  desTiporelacao?: string;
  flgAtivo?: boolean;
}
