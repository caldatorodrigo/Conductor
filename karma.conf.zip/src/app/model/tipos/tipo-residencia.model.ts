export interface TipoResidenciaModel {
  codTiporesidencia?: number;
  desTiporesidencia?: string;
  flgAtivo?: boolean;
}
