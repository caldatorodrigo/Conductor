export interface TipoConstituicaoJuridicaModel {
  codTipoconstitjuridica?: number;
  desTipoconstituicaojuridica?: string;
  flgAtivo?: boolean;
}
