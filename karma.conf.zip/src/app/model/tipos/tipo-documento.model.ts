export interface TipoDocumentoModel {
    codigo?: number;
    descricao?: string;
    ativo?: Boolean;
}