export interface TipoProfissaoModel {
  codTipoprofissao?: number;
  desTipoprofissao?: string;
  flgAtivo?: boolean;
}
