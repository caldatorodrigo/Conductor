export interface TipoEstadoCivilModel {
  codTipoestadocivil?: number;
  desTipoestadocivil?: string;
  flgAtivo?: boolean;
}
