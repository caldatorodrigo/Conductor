import { Fila } from './fila';

export interface AgrupamentoFilas {
    data : Fila[];
    exceptionMessage: string;
    hostname: string;
    message: string;
    status: boolean
}
