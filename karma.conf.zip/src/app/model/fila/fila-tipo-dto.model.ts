
export interface FilaTipoDTOModel { 
    codTpfila?: number;
    nomFila?: string;
    desFila?: string;
    desMetodoconsulta?: string;
    desMetodolock?: string;
    desMetodopre?: string;
    desMetodopos?: string;
    flgAtivo?: any;
    dtaInclusao?: string;
    codUsuarioinclusao?: string;
    dtaAlteracao?: string;
    codUsuarioalteracao?: string;
    descMetodoCentralizadora?: string;
    flgMetodoCentralizadora?: string;
    descMetodoCentralizadoraDet?: string;
}
