export interface FilaMotivoRecusaModel { 
    codMotivorecusa?: number;
    codTpfila?: number;
    desMotivorecusa?: string;
    flgBiometria?: any;
    flgGeratermo?: any;
    flgAlteradados?: any;
}
