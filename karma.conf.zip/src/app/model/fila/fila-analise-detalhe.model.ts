import { FilaModel } from './fila.model';
import { PessoaFisicaModel } from '../pessoa/pessoa-fisica.model';
import { LojaModel } from '../loja/loja.model';

export interface FilaAnaliseDetalheModel {
    fila?: FilaModel;
    pessoaFisica?: PessoaFisicaModel;
    loja?: LojaModel;
}