import { FilaMotivoRecusaModel } from './fila-motivo-recusa.model';
import { PessoaModel } from '../pessoa/pessoa.model';

export interface FilaAnaliseModel { 
    codFilaAnalise?: number;
    codIdfilaAnalise?: number;
    codIdfila?: number;
    pessoaFuncionario?: PessoaModel;
    dtaIniAnalise?: string;
    dtaFimAnalise?: string;
    desObservacao?: string;
    motivosRecusa?: Array<FilaMotivoRecusaModel>;
}
