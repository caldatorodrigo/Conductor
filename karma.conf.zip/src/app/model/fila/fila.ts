import { ItemFila } from './item-fila';

export interface Fila {
    codTpfila: Number;
    nomTpFila : string;
    urlAPI: string;
    filaStatus: ItemFila[];
}
