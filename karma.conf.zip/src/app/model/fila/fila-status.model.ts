export interface FilaStatusModel { 
    codStatus?: number;
    descStatus?: string;
}