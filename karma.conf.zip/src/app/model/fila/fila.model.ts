import { FilaStatusModel } from './fila-status.model';
import { FilaTipoDTOModel } from './fila-tipo-dto.model';
import { FilaAnaliseModel } from './fila-analise.model';

export interface FilaModel { 
    codIdfila?: number;
    codExterno?: string;
    dtaInclusao?: Date;
    codUsuarioinclusao?: number;
    dtaAlteracao?: string;
    codUsuarioalteracao?: string;
    status?: FilaStatusModel;
    filasAnalise?: Array<FilaAnaliseModel>;
    tiposFila?: FilaTipoDTOModel;
}