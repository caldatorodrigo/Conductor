import { FilaHistoricoAnaliseDetalheModel } from './fila-historico-analise-detalhe.model';

export interface FilaHistoricoAnaliseResponseModel {
    data?: Array<FilaHistoricoAnaliseDetalheModel>;
    exceptionMessage?: string;
    hostname?: string;
    message?: string;
    status?: boolean;
}