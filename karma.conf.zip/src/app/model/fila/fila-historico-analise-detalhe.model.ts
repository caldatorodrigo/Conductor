import { FilaModel } from './fila.model';
import { LojaModel } from '../loja/loja.model';
import { PessoaModel } from '../pessoa/pessoa.model';

export interface FilaHistoricoAnaliseDetalheModel {
    fila?: FilaModel;
    pessoa?: PessoaModel;
    loja?: LojaModel;
}