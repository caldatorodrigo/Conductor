export interface ItemFila {
    codStatus: Number;
    nomStatus : string;
    totStatus : Number;
}
