import { StatusTipoModel } from '../tipos/tipo-status.model';

export interface StatusModel {
    codigo?: number;
    descricao?: string;
    ativo?: boolean;
    tipo?: StatusTipoModel;
}
