import { RegionalModel } from '../regional/regional.model';

export interface CadastroLojaModel { 
    codigoLoja?: number;
    descricaoLoja?: string;
    cnpj?: string;
    nomeResponsavel?: string;
    centroCusto?: string;
    regional?: RegionalModel;
    cep?: string;
    uf?: string;
    endereco?: string;
    enderecoNumero?: string;
    enderecoComplemento?: string;
    bairro?: string;
    cidade?: string;
    email?: string;
    localEData?: string;
    flagBiometria?: string;
}