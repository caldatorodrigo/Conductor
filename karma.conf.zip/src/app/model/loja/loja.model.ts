export interface LojaModel {
  codLoja?: number;
  descLoja?: string;
  cnpj?: string;
  nomeResponsavel?: string;
  centroCusto?: string;
  cep?: string;
  uf?: string;
  endereco?: string;
  enderecoNumero?: string;
  enderecoComplemento?: string;
  bairro?: string;
  cidade?: string;
  email?: string;
  localEData?: string;
  flagBiometria?: string;  
  codigoRegional?: number;
  descricaoRegional?: string;
  codigoGrupoRegional?: number;
  descricaoGrupoRegional?: string;
  codigoRegiao?: number;
  descricaoRegiao?: string;
}
