export interface ISerialize {
    fromJson(json: any): any; 
    toJson(resource: any): any;
}
