export class digitalizacao {
    CodLoja: string;
    CodigoSistema: string;
    CodigoDocumento: string;
    CodigoFuncao: string;
    CodigoExterno: string;
    CodigoUsuarioUpload: string;
    Origem: string;
    ObservacaoImagem: string;
    CaminhoArquivo: string;
    UrlArquivo: string;
    NomeArquivo: string;
    DiretorioDestinoDoc: string;
    UrlImg: string;
    EndPointBanco: string;
}