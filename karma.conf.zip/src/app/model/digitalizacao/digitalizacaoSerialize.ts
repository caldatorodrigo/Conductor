import {ISerialize} from '../ISerialize';
import { digitalizacao } from './digitalizacao';

export class digitalizacaoSerializer implements ISerialize {
    
    fromJson(json: any): digitalizacao {
      
      let _digitalizacao = new digitalizacao();
      
      _digitalizacao.CodLoja             = json.CodLoja;
      _digitalizacao.CodigoSistema       = json.codigoSistema;  
      _digitalizacao.CodigoDocumento     = json.codigoDocumento;
      _digitalizacao.CodigoFuncao        = json.codigoFuncao;
      _digitalizacao.CodigoExterno       = json.codigoExterno;
      _digitalizacao.CodigoUsuarioUpload = json.codigoUsuarioUpload;
      _digitalizacao.Origem              = json.origem;
      _digitalizacao.ObservacaoImagem    = json.observacaoImagem;
      _digitalizacao.CaminhoArquivo      = json.caminhoArquivo;
      _digitalizacao.UrlArquivo          = json.urlArquivo;   
      _digitalizacao.NomeArquivo         = json.nomeArquivo;
      _digitalizacao.DiretorioDestinoDoc = json.diretorioDestinoDoc;
      _digitalizacao.UrlImg              = json.urlImg;
      _digitalizacao.EndPointBanco       = json.endPointBanco;

      return _digitalizacao;
    }
  
    toJson(_digitalizacao: digitalizacao): any {
      return {
        CodLoja             : _digitalizacao.CodLoja,
        CodigoSistema       : _digitalizacao.CodigoSistema,
        CodigoDocumento     : _digitalizacao.CodigoDocumento,
        CodigoFuncao        : _digitalizacao.CodigoFuncao,
        CodigoExterno       : _digitalizacao.CodigoExterno,
        CodigoUsuarioUpload : _digitalizacao.CodigoUsuarioUpload,
        Origem              : _digitalizacao.Origem,
        ObservacaoImagem    : _digitalizacao.ObservacaoImagem,
        CaminhoArquivo      : _digitalizacao.CaminhoArquivo,
        UrlArquivo          : _digitalizacao.UrlArquivo,
        NomeArquivo         : _digitalizacao.NomeArquivo,
        DiretorioDestinoDoc : _digitalizacao.DiretorioDestinoDoc,
        UrlImg              : _digitalizacao.UrlImg,
        EndPointBanco       :_digitalizacao.EndPointBanco
      };
    }
  }