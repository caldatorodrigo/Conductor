export interface DocumentoItemConfiguracaoModel {
    codigo?: number;
    descricao?: string;
    ativo?: boolean;
}