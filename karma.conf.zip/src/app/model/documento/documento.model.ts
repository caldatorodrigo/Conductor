import { TipoDocumentoModel } from '../tipos/tipo-documento.model';
import { DocumentoConfiguracaoModel } from './documento-configuracao.model';

export interface DocumentoModel {
    codigo?: number;
    descricao?: string;
    tipo?: TipoDocumentoModel;
    configuracao?: Array<DocumentoConfiguracaoModel>;
    ativo?: Boolean;
}