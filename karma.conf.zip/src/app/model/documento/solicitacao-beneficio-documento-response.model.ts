import { SolicitacaoBeneficioDocumentoModel } from '../solicitacao/beneficio/documento/solicitacao-beneficio-documento.model';

export interface SolicitacaoBeneficioDocumentoResponse {
    data?: Array<SolicitacaoBeneficioDocumentoModel>;
    exceptionMessage?: string;
    hostname?: string;
    message?: string;
    status?: Boolean;
}