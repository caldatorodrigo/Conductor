import { DocumentoItemConfiguracaoModel } from './documento-item-configuracao.model';
import { ProcessoModel } from '../processo/processo.model';

export interface DocumentoConfiguracaoModel {
    codDocumento?: number;
    itemConfiguracao?: DocumentoItemConfiguracaoModel;
    processo?: ProcessoModel;
    valor?: string
    dtaVigenciainicio?: string
    dtaVigenciafim?: string;
    ativo?: Boolean;
}