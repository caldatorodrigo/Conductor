import { BeneficioPagamentoModel } from '../pagamento/beneficio-pagamento.model';
import { PessoaModel } from '../../pessoa/pessoa.model';

export interface CapturaCartaoModel {
    solicitacaoPagamento?: BeneficioPagamentoModel;
    pessoa?: PessoaModel;
    usuario?: string;
}