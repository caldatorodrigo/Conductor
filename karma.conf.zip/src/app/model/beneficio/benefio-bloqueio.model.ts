export interface BeneficioBloqueioModel {
  codBeneficio?: number;
  tipoBloqueio?: string;
  tipoLote?: string;
  dataInicioPeriodo?: Date;
  dataFimPeriodo?: Date;
  naturezaCredito?: string;
  dataMovimentoCredito?: Date;
  dataInicioValidade?: Date;
  dataFimValidade?: Date;
  idBloqueio?: string;
  origemBloqueio?: string;
}
