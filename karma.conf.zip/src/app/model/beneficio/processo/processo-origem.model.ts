export interface ProcessoOrigemModel { 
    data?: Array<any>;
    codProcessoorigem?: number;
    desProcesso?: string;
}