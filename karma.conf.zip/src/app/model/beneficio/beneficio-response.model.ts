import { BeneficioDataModel } from './beneficio-data.model';

export interface BeneficioResponseModel { 
    data?: BeneficioDataModel;
    exceptionMessage?: string;
    hostname?: string;
    message?: string;
    status?: boolean;
}