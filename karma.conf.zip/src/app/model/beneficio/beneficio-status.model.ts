import { StatusTipoModel } from '../tipos/tipo-status.model';

export interface BeneficioStatusModel { 
    codigo?: number;
    descricao?: string;
    solicTipoStatusDTO?: StatusTipoModel;
}