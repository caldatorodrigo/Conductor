import { BeneficioPagamentoModel } from './beneficio-pagamento.model';

export interface BeneficioPagamentoRequestModel {
    data?: BeneficioPagamentoModel;
    system?: string;
    process?: number;
  }
  