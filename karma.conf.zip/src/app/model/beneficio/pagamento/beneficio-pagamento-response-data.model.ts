import { BeneficioPagamentoModel } from './beneficio-pagamento.model';

export interface BeneficioPagamentoResponseModel { 
    data?: BeneficioPagamentoModel;
    exceptionMessage?: string;
    hostname?: string;
    message?: string;
    status?: boolean;
}