import { TipoMeioPagamentoModel } from '../../tipos/tipo-meio-pagamento.model';
import { LojaModel } from '../../loja/loja.model';

export interface BeneficioPagamentoModel {
  codSolicBeneficioPgto?: number;
  codSolicbeneficio?: number;
  numConta?: string;
  numIdcontacartao?: string;
  principal?: boolean;
  validado?: boolean;
  senha?: boolean;
  loja?: LojaModel;
  tipoMeioPagamento?: TipoMeioPagamentoModel;
}
