export interface ProcuradorModel {
  codProcuradores?: number;
  codPessoa?: number;
  numCpf?: string;
  nomProcurador?: string;
  numTelefone?: string;
}
