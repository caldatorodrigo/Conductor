import { BeneficioStatusModel } from './beneficio-status.model';
import { ProcessoOrigemModel } from './processo/processo-origem.model';
import { ProcuradorModel } from './procurador/procurador.model';
import { PessoaModel } from '../pessoa/pessoa.model';
import { LojaModel } from '../loja/loja.model';
import { BeneficioPagamentoModel } from './pagamento/beneficio-pagamento.model';
import { BeneficioBloqueioModel } from './benefio-bloqueio.model';

export interface BeneficioDataModel { 
    codBeneficio?: number;
    codOrgaopagador?: number;
    dtaUltimaconcessao?: Date;
    dtaConcessao?: Date;
    dataInicioPagamento?: Date;
    dataLimitePagamento?: Date;    
    tpoEspecie?: number;
    numContacorrente?: string;
    nit?: string;
    numBeneficio?: string;
    codDiautil?: number;
    representante?: boolean;
    status?: BeneficioStatusModel;
    processos?: Array<ProcessoOrigemModel>;
    procuradores?: Array<ProcuradorModel>;
    pessoa?: PessoaModel;
    loja?: LojaModel;
    formaPagamento?: Array<BeneficioPagamentoModel>;
    bloqueios?: Array<BeneficioBloqueioModel>;
    valorLiquido?: number;
    motivo?: string;
}