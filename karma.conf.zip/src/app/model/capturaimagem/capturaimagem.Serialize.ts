import { ISerialize } from '../ISerialize';
import { capturaImagem } from './capturaimagem';

export class capturaImagemSerializer implements ISerialize {
    
    fromJson(json: any): capturaImagem {
      
      let _capturaImagem = new capturaImagem();

      _capturaImagem.codigoSolicitacao = json.codigoSolicitacao;
      _capturaImagem.codigoDocumento   = json.codigoDocumento;
      _capturaImagem.imageBase64       = json.nomeArquivo;  
      
      return _capturaImagem;
    }
  
    toJson(_capturaImagem: capturaImagem): any {
      return {
        codigoSolicitacao : _capturaImagem.codigoSolicitacao,
        codigoDocumento   : _capturaImagem.codigoDocumento,
        imageBase64       : _capturaImagem.imageBase64
      };
    }
  }

