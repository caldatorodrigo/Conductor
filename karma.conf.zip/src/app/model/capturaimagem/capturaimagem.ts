export class capturaImagem{
    codigoSolicitacao : string;
    codigoDocumento : string;
    imageBase64 : string;
}