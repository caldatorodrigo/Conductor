export interface ProdutoModel {
  codProduto?: number;
  desProduto?: string;
  codProdutopai?: number;
  flgAtivo?: boolean;
}
