export interface ProcessoTipoModel {
    codigo?: number;
    descricao?: string;
    ativo?: Boolean;
}