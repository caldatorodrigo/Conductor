import { ProcessoTipoModel } from './processo-tipo.model';

export interface ProcessoModel {
    codigo?: number;
    descricao?: string;
    tipo?: ProcessoTipoModel;
    ativo?: Boolean;
}