import { TipoPessoaModel } from '../tipos/tipo-pessoa.model';
import { PaisModel } from '../pais/pais.model';
import { CidadeModel } from '../cidade/cidade.model';
import { PessoaDocumentoModel } from './pessoa-documento.model';
import { PessoaEmailModel } from './pessoa-email.model';
import { PessoaEnderecoModel } from './pessoa-endereco.model';
import { PessoaFATCAModel } from './pessoa-fatca.model';
import { PessoaFisicaModel } from './pessoa-fisica.model';
import { PessoaJuridicaModel } from './pessoa-juridica.model';
import { PessoaPatrimonioModel } from './pessoa-patrimonio.model';
import { PessoaPEPModel } from './pessoa-pep.model';
import { PessoaProdutoModel } from './pessoa-produto.model';
import { PessoaRelativoModel } from './pessoa-relativo.model';
import { PessoaTelefoneModel } from './pessoa-telefone.model';
import { PessoaContaExternaModel } from './pessoa-conta-externa.model';

export interface PessoaModel { 
    codPessoa?: number;
    nomPessoa?: string;
    tpoPessoa?: TipoPessoaModel;
    pais?: PaisModel;
    cidade?: CidadeModel;
    slgUf?: string;
    ativo?: boolean;
    documentos?: Array<PessoaDocumentoModel>;
    emails?: Array<PessoaEmailModel>;
    enderecos?: Array<PessoaEnderecoModel>;
    dadosFATCA?: PessoaFATCAModel;
    dadosPessoaFisica?: PessoaFisicaModel;
    dadosPessoaJuridica?: PessoaJuridicaModel;
    patrimonios?: Array<PessoaPatrimonioModel>;
    dadosPEP?: PessoaPEPModel;
    produtos?: Array<PessoaProdutoModel>;
    relativos?: Array<PessoaRelativoModel>;
    telefones?: Array<PessoaTelefoneModel>;
    contasExternas?: Array<PessoaContaExternaModel>;
}
