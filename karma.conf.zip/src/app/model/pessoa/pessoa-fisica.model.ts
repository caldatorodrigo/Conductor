import { TipoProfissaoModel } from '../tipos/tipo-profissao.model';
import { TipoEstadoCivilModel } from '../tipos/tipo-estado-civil.model';

export interface PessoaFisicaModel {
  codPessoafisica?: number;
  codPessoa?: number;
  numCpf?: string;
  slgSexo?: string;
  dtaNascimento?: Date;
  tpoProfissao?: TipoProfissaoModel;
  tpoEstcivil?: TipoEstadoCivilModel;
  vlrRendames?: number;
  vlrBensedireitos?: number;
  vlrOutrosrendimentos?: number;
  desOutrosrendimentos?: string;
  dtaEntradabrasil?: Date;
  nomEmpresa?: string;
}
