import { TipoRelacaoModel } from '../tipos/tipo-relacao.model';

export interface PessoaRelativoModel {
  codPessoarelativo?: number;
  codPessoa?: number;
  tpoRelacao?: TipoRelacaoModel;
  nomPessoarelativo?: string;
  desCargo?: string;
  flgRepresentante?: boolean;
  slgSexo?: string;
  dtaNascimento?: Date;
  numCpf?: string;
  numRg?: string;
  dtaRgEmissao?: Date;
  slgRgOrgemissor?: string;
  slgRgUf?: string;
  numTelefone?: string;
  numDdd?: string;
  numRamal?: string;
  flgCliente?: boolean;
  flgAtivo?: boolean;
}
