import { TipoPatrimonioModel } from '../tipos/tipo-patrimonio.model';

export interface PessoaPatrimonioModel {
  codPessoaPatrimonio?: number;
  codPessoa?: number;
  vlrEstimado?: number;
  tipo?: TipoPatrimonioModel;
  ativo?: boolean;
}
