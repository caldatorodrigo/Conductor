import { TipoConstituicaoJuridicaModel } from '../tipos/tipo-constituicao-juridica.model';

export interface PessoaJuridicaModel {
  codPessoajuridica?: number;
  codPessoa?: number;
  numCnpj?: string;
  nomRazaosocial?: string;
  desAtividade?: string;
  tpoConstituicaojuridica?: TipoConstituicaoJuridicaModel;
  dtaConstituicao?: Date;
  vlrReceitaMes?: number;
}
