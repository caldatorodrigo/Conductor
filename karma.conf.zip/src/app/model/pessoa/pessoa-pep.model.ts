export interface PessoaPEPModel {  
  codPessoaPEP?: number;
  codPessoa?: number;
  funcao?: string;
  dtaInicio?: string;
  dtaFim?: string;
  empresa?: string;
  relacaoAgentePubli?: boolean;
  ativo?: boolean;
}
