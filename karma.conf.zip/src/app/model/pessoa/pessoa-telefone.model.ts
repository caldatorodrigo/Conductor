export interface PessoaTelefoneModel {
  codPessoatelefone?: number;
  codPessoa?: number;
  numDdd?: string;
  numTelefone?: string;
  codPais?: number;
  numRamal?: string;
  obsTelefone?: string;
  flgCelular?: boolean;
  flgPessoal?: boolean;
  flgSmsautorizado?: boolean;
  flgAtivo?: boolean;
}
