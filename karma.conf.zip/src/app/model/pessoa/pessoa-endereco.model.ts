import { TipoResidenciaModel } from '../tipos/tipo-residencia.model';


export interface PessoaEnderecoModel { 
    codPessoaendereco?: number;
    codPessoa?: number;
    desCidade?: string;
    desLogradouro?: string;
    flgResidencial?: boolean;
    tpoResidencia?: TipoResidenciaModel;
    flgResidenciaatual?: boolean;
    numEndereco?: string;
    desBairro?: string;
    slgUf?: string;
    numCep?: string;
    desComplemento?: string;
    flgAtivo?: boolean;
}
