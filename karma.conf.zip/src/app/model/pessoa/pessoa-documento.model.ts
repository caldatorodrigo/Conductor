import { PaisModel } from '../pais/pais.model';
import { TipoDocumentoModel } from '../tipos/tipo-documento.model';
import { DocumentoModel } from '../documento/documento.model';

export interface PessoaDocumentoModel {
  codPessoadocumento?: number;
  codPessoa?: number;
  tpoDocumento?: DocumentoModel;
  numDocumento?: string;
  digDocumento?: string;
  codPais?: PaisModel;
  slgOrgemissor?: string;
  dtaEmissao?: Date;
  dtaValidade?: Date;
  flgDocdeidentificacao?: boolean;
  slgUf?: string;
  flgAtivo?: boolean;
}
