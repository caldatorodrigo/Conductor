export interface PessoaEmailModel {
  codPessoaemail?: number;
  codPessoa?: number;
  desEmail?: string;
  flgPessoal?: boolean;
  flgAtivo?: boolean;
}
