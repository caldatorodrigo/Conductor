export interface PessoaFATCAModel {
  codPessoafatca?: number;
  codPessoa?: number;
  estudante?: boolean;
  diplomata?: boolean;
  presencaSubstancial?: boolean;
  abdicouNacionalidade?: boolean;
  renunciou	?: boolean;
  possuiGreencard	?: boolean;
  certificAbandono	?: boolean;
  resideNosEua	?: boolean;
  diasVisitaAnoCorrente?: number;
  diasVisitaAnoPassado?: number;
  diasVisitaAnoAnterior?: number;
}
