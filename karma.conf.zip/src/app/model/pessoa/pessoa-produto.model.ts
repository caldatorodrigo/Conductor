import { ProdutoModel } from '../produto/produto.model';

export interface PessoaProdutoModel {
  codPessoaProduto?: number;
  codPessoa?: number;
  produto?: ProdutoModel;
  flgAtivo?: boolean;
}
