export interface PessoaContaExternaModel {
  codPessoacontaexterna?: number;
  codPessoa?: number;
  numBanco?: string;
  numConta?: string;
  numAgencia?: string;
  digAgencia?: string;
  digConta?: string;
  tpoConta?: string;
  flgAtivo?: boolean;
}
