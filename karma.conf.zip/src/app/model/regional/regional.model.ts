import { RegiaoModel } from '../regiao/regiao.model';
import { CadastroLojaModel } from '../loja/cadastro-loja.model';

export interface RegionalModel { 
    codigoRegional?: number;
    descricaoRegional?: string;
    regiao?: RegiaoModel;
    lojas?: Array<CadastroLojaModel>;
}
