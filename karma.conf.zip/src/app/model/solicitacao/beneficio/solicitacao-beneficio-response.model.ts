import { SolicitacaoBeneficioDataModel } from './solicitacao-beneficio-data.model';

export interface SolicitacaoBeneficioResponseModel { 
    data?: SolicitacaoBeneficioDataModel;
    exceptionMessage?: string;
    hostname?: string;
    message?: string;
    status?: boolean;
}