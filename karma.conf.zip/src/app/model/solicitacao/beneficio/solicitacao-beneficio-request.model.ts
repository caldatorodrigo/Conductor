import { SolicitacaoBeneficioDataModel } from "./solicitacao-beneficio-data.model";

export interface SolicitacaoBeneficioRequestModel {
  data?: SolicitacaoBeneficioDataModel;
  system?: string;
  process?: number;
}
