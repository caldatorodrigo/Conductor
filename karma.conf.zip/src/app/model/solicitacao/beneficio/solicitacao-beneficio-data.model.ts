import { LojaModel } from "../../loja/loja.model";
import { PessoaModel } from "../../pessoa/pessoa.model";
import { SolicitacaoBeneficioDocumentoModel } from "./documento/solicitacao-beneficio-documento.model";
import { BeneficioPagamentoModel } from '../../beneficio/pagamento/beneficio-pagamento.model';
import { StatusModel } from '../../status/status.model';

export interface SolicitacaoBeneficioDataModel {
  codSolicbeneficio?: number;
  codBeneficio?: number;
  loja?: LojaModel;
  status?: StatusModel;
  dtaSolicitacao?: string;
  pessoa?: PessoaModel;
  numConta?: string;
  documentos?: Array<SolicitacaoBeneficioDocumentoModel>;
  formaPagamento?: Array<BeneficioPagamentoModel>;
}