import { StatusTipoModel } from "src/app/model/tipos/tipo-status.model";
import { DocumentoModel } from "src/app/model/documento/documento.model";
import { StatusModel } from "src/app/model/status/status.model";

export interface SolicitacaoBeneficioDocumentoModel {
  codSolicBeneficioDoc?: number;
  codSolicBeneficio?: number;
  documento?: DocumentoModel;
  status?: StatusModel;
  digitalizacao?: Boolean;
  assinatura?: Boolean;
  enviado?: Boolean;
  recebido?: Boolean;
  biometria?: Boolean;
  biometriaT1?: Boolean;
  biometriaT2?: Boolean;
  clienteNovo?: Boolean;
  ratingBiometria?: number;
  ratingBiometriaT1?: number;
  ratingBiometriaT2?: number;
  caminhoArquivo?: string;
  urlArquivo?: string;
}
