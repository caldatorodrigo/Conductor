import { PessoaModel } from '../../pessoa/pessoa.model';
import { LojaModel } from '../../loja/loja.model';
import { StatusModel } from '../../status/status.model';

export interface PacoteTarifaModel {
  codigo: string;
  descricao: string;
}

export interface SolicitacaoContaCorrenteModel {
  codSolicConta?: number;
  codConta?: number;
  pessoa?: PessoaModel;
  loja?: LojaModel;
  codAgencia?: string;
  numConta?: string;
  digConta?: string;
  pacotetarifa?: PacoteTarifaModel;
  tpoConta?: number;
  numIdContaCartao?: number;
  codProdutoCartao?: number;
  senhaCartao?: boolean;
  senhaMovimentacao?: boolean;
  senhaAcesso?: boolean;
  status?: StatusModel;
}
