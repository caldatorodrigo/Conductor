export interface SolicitacaoProvaVidaDocumentoModel {
    codSolicprovavidadoc?: number;
    codSolicprovavida?: number;
    tpoDocumento?: number;
    flgDigitalizacao?: Boolean;
    flgAssinatura?: Boolean;
    flgEnviado?: Boolean;
    flgRecebido?: Boolean;
    flgBiometria?: Boolean;
    flgBiometriaT1?: Boolean;
    flgBiometriaT2?: Boolean;
    flgClienteNovo?: Boolean;
    pctRatingbiometria?: number;
    desCaminhoarquivo?: string;
    desUrlarquivo?: string;
  }
  