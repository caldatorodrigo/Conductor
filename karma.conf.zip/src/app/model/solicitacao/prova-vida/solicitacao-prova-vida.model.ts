import { PessoaModel } from '../../pessoa/pessoa.model';
import { LojaModel } from '../../loja/loja.model';
import { StatusModel } from '../../status/status.model';
import { SolicitacaoProvaVidaDocumentoModel } from './documento/solicitacao-prova-vida-documento.model';

export interface SolicitacaoProvaVidaModel { 
    codSolicProvaVida?: number;
    codBeneficio?: number;
    dtaSolicitacao?: string;
    pessoa: PessoaModel;
    loja: LojaModel;
    statusDTO : StatusModel;
    solicProvaVidaDoc: Array<SolicitacaoProvaVidaDocumentoModel>;   
}
