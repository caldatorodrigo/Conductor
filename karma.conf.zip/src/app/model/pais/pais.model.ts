export interface PaisModel {
  codPais?: number;
  desPais?: string;
  flgAtivo?: boolean;
}
