export interface IdentityModel { 
    readonly name?: string;
    readonly authenticationType?: string;
    readonly isAuthenticated?: boolean;
}
