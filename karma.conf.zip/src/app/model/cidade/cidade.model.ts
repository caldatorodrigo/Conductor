export interface CidadeModel {
  codCidade?: number;
  desCidade?: string;
  uf?: string;
  flgAtivo?: boolean;
}
