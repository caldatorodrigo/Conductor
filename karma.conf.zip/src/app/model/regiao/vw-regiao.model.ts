export interface VwRegiaoModel { 
    codRegRegiao?: number;
    descRegRegiao?: string;
}
