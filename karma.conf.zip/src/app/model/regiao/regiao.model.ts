import { RegionalModel } from '../regional/regional.model';

export interface RegiaoModel { 
    codigoRegiao?: number;
    descricaoRegiao?: string;
    regionais?: Array<RegionalModel>;
}
