export class NotificationEvent {
    constructor(
        public notificationType: string,
        public message: string
    ){}
}