import { IdentityModel } from '../security/identity.model';
import { PerfilModel } from '../perfil/perfil.model';
import { CadastroLojaModel } from '../loja/cadastro-loja.model';
import { VwRegiaoModel } from '../regiao/vw-regiao.model';

export interface UsuarioModel { 
    readonly identity?: IdentityModel;
    matricula?: string;
    nome?: string;
    status?: boolean;
    login?: string;
    senha?: string;
    email?: string;
    siglaSistema?: string;
    token?: string;
    perfil?: PerfilModel;
    loja?: CadastroLojaModel;
    lojas?: Array<CadastroLojaModel>;
    vwRegiao?: Array<VwRegiaoModel>;
}