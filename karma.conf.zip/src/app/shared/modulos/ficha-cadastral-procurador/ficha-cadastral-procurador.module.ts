import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FichaCadastralProcuradorComponent } from './components/ficha-cadastral-procurador.component';



@NgModule({
    declarations: [
        // FichaCadastralProcuradorComponent
    ],
    imports: [
        // CommonModule
    ],
    exports: [
        // FichaCadastralProcuradorComponent
    ]
})
export class FichaCadastralModule {

}