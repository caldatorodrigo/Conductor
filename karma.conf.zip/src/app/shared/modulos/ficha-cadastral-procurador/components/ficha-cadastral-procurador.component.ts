import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ficha-cadastral-procurador',
  templateUrl: './ficha-cadastral-procurador.component.html',
  styleUrls: ['./ficha-cadastral-procurador.component.scss']
})
export class FichaCadastralProcuradorComponent implements OnInit {
  show:any;
  apareceFormulario:any;
  fechaAbas:any;

  constructor() { }

  ngOnInit() {
  }


}
