import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, Validators } from "@angular/forms";
import { BeneficioPagamentoModel } from "src/app/model/beneficio/pagamento/beneficio-pagamento.model";
import { BeneficioPagamentoService } from "src/app/modulos/beneficio/services/beneficio-pagamento.service";
import { SolicitacaoBeneficioDataModel } from "src/app/model/solicitacao/beneficio/solicitacao-beneficio-data.model";
import { BeneficioSolicitacaoService } from 'src/app/modulos/beneficio/services/beneficio-solicitacao.service';
import { PessoaService } from 'src/app/modulos/pessoa/services/pessoa.service';

interface MeioPagamento{
  codigo:	string;
  descricao:	string;
  ativo:	boolean;
}

interface MeioPagamentoResponse{
  data: Array<MeioPagamento>;
  exceptionMessage:	string;
  hostname:	string;
  message:	string;
  status:	boolean;
}

@Component({
  selector: "app-dados-estaticos",
  templateUrl: "./dados-estaticos.component.html",
  styleUrls: ["./dados-estaticos.component.scss"]
})
export class DadosEstaticosComponent implements OnInit {
  ngOnInit(): void {
  }

  @Input() canEdit = true;
  beneficioPagamento: BeneficioPagamentoModel[];
  @Input() solicitacaoBeneficio: SolicitacaoBeneficioDataModel;
  formaPagamentoTratada: BeneficioPagamentoModel | any;
  meioPagamentoResponse: MeioPagamentoResponse;
  meioPagamentoList: Array<MeioPagamento>;

  beneficioPagamentoForm = this.fb.group({
    tipoPagamento: [null],
  });

  //construtores
  constructor(
    private fb: FormBuilder,
    private beneficioPagamentoService: BeneficioPagamentoService,
    private beneficioSolicitacaoService: BeneficioSolicitacaoService,
    private pessoaService: PessoaService,
  ) {
    
    this.pessoaService.getAllTipoMeioPagamento().toPromise().then((data: any) => {
      this.meioPagamentoResponse = <MeioPagamentoResponse>data;
      this.meioPagamentoList = this.meioPagamentoResponse.data;
      console.log("meioPagamentoList==" + JSON.stringify(this.meioPagamentoList));
      // this.beneficioPagamentoService.solicitacaoSubjectObs()
        // .subscribe((data: any) => {
          // this.solicitacaoBeneficio = <SolicitacaoBeneficioDataModel>data;
          
          this.formaPagamentoTratada = this.tratarFormaPagamento(this.solicitacaoBeneficio);
          if(this.formaPagamentoTratada) {
            this.beneficioPagamentoForm.setValue({
              tipoPagamento: ((this.formaPagamentoTratada.tipoMeioPagamento===null||this.formaPagamentoTratada.tipoMeioPagamento===undefined)?0:this.formaPagamentoTratada.tipoMeioPagamento.codigo),
            });
            this.beneficioSolicitacaoService.addSolicitacao(this.solicitacaoBeneficio );
          }
        // });
    });
  }

  private tratarFormaPagamento(
    solicitacao: SolicitacaoBeneficioDataModel
  ): BeneficioPagamentoModel {
    let retorno = {} as BeneficioPagamentoModel;

    if (
      solicitacao.formaPagamento == null ||
      solicitacao.formaPagamento == undefined
    ) {
      return retorno;
    }

    for (var i = 0; i < solicitacao.formaPagamento.length; i++) {
      if (solicitacao.formaPagamento[i].principal == true) {
        retorno = solicitacao.formaPagamento[i];
        break;
      }
    }

    return retorno;
  }

  onSubmit() {}

  escolherFormaPagamento(itemTipoPagamento: MeioPagamento) {    
    console.log('itemTipoPagamento.descricao='+itemTipoPagamento.descricao);
    this.beneficioPagamentoService.addFormaPagamentoEscolhida(itemTipoPagamento);
  }
}
