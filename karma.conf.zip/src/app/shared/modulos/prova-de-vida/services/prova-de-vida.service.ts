import { Injectable } from '@angular/core';
import {
  HttpHeaders,
  HttpErrorResponse,
  HttpClient
} from '@angular/common/http';
import { catchError, retry, map } from 'rxjs/operators';
import { throwError, Observable } from 'rxjs';
import { environment } from 'src/environments/environment';

var httpOptions = {
  headers: new HttpHeaders()
};

@Injectable()
export class ProvaDeVidaService {
  API_INSS_SERVER_NAME: string;
  BASE_URL_API = 'api';

  constructor(private httpClient: HttpClient) {
    this.API_INSS_SERVER_NAME = environment.API_INSS_SERVER_NAME;
    httpOptions.headers.set('Access-Control-Allow-Origin', '*');
    httpOptions.headers.set('Content-Type', 'application/json');
  }

  public getSolicitacaoProvaVidaByBeneficioPromise( codigoBeneficio: string ): Promise<any> {
    return this.httpClient
      .get<any>(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_API}/SolicProvaVida/v1/consultar-por-codbeneficio/${codigoBeneficio}`,
        httpOptions
      ).pipe(
        map( res => { 
          console.log('res='+JSON.stringify(res.data));
          return (res.data ? res.data : []);
        })
      )
      .toPromise()
  }

  public inserirSolicitacaoProvaVidaPromise( solicitacaoProvaVida: any ): Promise<any> {
    console.log('inserirSolicitacaoProvaVidaPromise solicitacaoProvaVida='+JSON.stringify(solicitacaoProvaVida));
    return this.httpClient
      .post<any>(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_API}/SolicProvaVida/v1/inserir`,
        solicitacaoProvaVida
      ).pipe(
        map( res => { 
          console.log('res='+JSON.stringify(res.data));
          return (res.data ? res.data : {});
        })
      )
      .toPromise()
  }

  public inserirSolicitacaoProvaVida( solicitacaoProvaVida: any ) {
    console.log('inserirSolicitacaoProvaVida solicitacaoProvaVida='+JSON.stringify(solicitacaoProvaVida));
    this.httpClient
      .post(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_API}/SolicProvaVida/v1/inserir`,
        solicitacaoProvaVida
      )
      .subscribe(
        resp => {
          console.log(
            'respPost inserirSolicitacaoProvaVida=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em inserirSolicitacaoProvaVida=' + JSON.stringify(err)
          )
      );
  }

  public atualizarSolicitacaoProvaVida(solicitacaoProvaVida: any) {
    console.log(
      'atualizarPessoaPEP solicitacaoProvaVida=' +
        JSON.stringify(solicitacaoProvaVida)
    );
    this.httpClient
      .put(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_API}/SolicProvaVida/v1/alterar`,
        solicitacaoProvaVida
      )
      .subscribe(
        resp => {
          console.log(
            'respPost atualizarPessoaPEP=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em atualizarPessoaPEP=' + JSON.stringify(err)
          )
      );
  }

  public finalizarCapturaProvaVida( solicitacaoProvaVida: any ) {
    console.log('finalizarCapturaProvaVida solicitacaoProvaVida='+JSON.stringify(solicitacaoProvaVida));
    this.httpClient
      .post(
        `${this.API_INSS_SERVER_NAME}/${this.BASE_URL_API}/SolicProvaVida/v1/finalizar-captura`,
        solicitacaoProvaVida
      )
      .subscribe(
        resp => {
          console.log(
            'respPost finalizarCapturaProvaVida=' + JSON.stringify(resp)
          );
        },
        err =>
          console.error(
            'erro em finalizarCapturaProvaVida=' + JSON.stringify(err)
          )
      );
  }

}
