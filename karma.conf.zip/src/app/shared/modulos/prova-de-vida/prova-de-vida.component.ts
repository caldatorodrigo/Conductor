import { Component, Input } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BeneficioDataModel } from 'src/app/model/beneficio/beneficio-data.model';
import { BeneficioSolicitacaoService } from 'src/app/modulos/beneficio/services/beneficio-solicitacao.service';
import { ProvaDeVidaService } from './services/prova-de-vida.service';
import { SolicitacaoProvaVidaModel } from 'src/app/model/solicitacao/prova-vida/solicitacao-prova-vida.model';
import { AlertService } from '../../services/alert.service';
import { MatSnackBar, MatTableDataSource } from '@angular/material';
import { StatusModel } from 'src/app/model/status/status.model';

@Component({
  selector: 'app-prova-de-vida',
  templateUrl: './prova-de-vida.component.html',
  styleUrls: ['./prova-de-vida.component.scss']
})
export class ProvaDeVidaComponent {

  dataSource;
  @Input() beneficio: BeneficioDataModel;
  solicitacaoProvaVidaList: Array<SolicitacaoProvaVidaModel>;

  showBotaoNovaSolicitacaoProvaVida: Boolean = false;
  showDetalhesSolicitacao: Boolean = false;

  displayedColumns: string[] = [
    'selected',
    'solicitacao',
    'numBeneficio',
    'cpf',
    'nome',
    'status',
    'detalhe',
    'analise'
  ];

  provaVidaForm = this.fb.group({
    InputProvadeVida: [null],
  });

  constructor(
                private fb: FormBuilder,
                private beneficioService: BeneficioSolicitacaoService,
                private provaVidaService: ProvaDeVidaService,
                private snackBar: MatSnackBar,
                private alertService: AlertService,
   ) {
      window.scroll(0,0);
      if (this.dataSource) {
         this.dataSource = undefined;
      }
  }

  ngOnInit() {
    this.provaVidaService
      .getSolicitacaoProvaVidaByBeneficioPromise(this.beneficio.codBeneficio+'')
      .then(
        res => {
          this.solicitacaoProvaVidaList = <SolicitacaoProvaVidaModel[]>res;
        })
      .catch(
        err=> {
          console.error('erro ao obter solicitacaoProvaVidaList=>'+JSON.stringify(err))
          this.alertService.setLoading(false);
          this.alertService.dispatch('Erro ao obter solicitacaoProvaVidaList=>', err);
        }
      ).finally( () => {
        this.alertService.setLoading(false);
        console.log("solicitacaoProvaVidaList carregada ==>" + JSON.stringify(this.solicitacaoProvaVidaList));
        if ((this.solicitacaoProvaVidaList) && (this.solicitacaoProvaVidaList.length>0)) {
          this.dataSource = new MatTableDataSource(this.solicitacaoProvaVidaList);
          this.showBotaoNovaSolicitacaoProvaVida = false;
          console.log('PROVA DE VIDA - dataSource =>' ,  this.dataSource );
        } else {
          this.showBotaoNovaSolicitacaoProvaVida = true;
        }
      });
  }

  public novaSolicitacaoProvaVida() {
    let novaSolicitacao = {} as SolicitacaoProvaVidaModel;
    novaSolicitacao.codBeneficio = this.beneficio.codBeneficio;
    novaSolicitacao.pessoa = Object.assign( this.beneficio.pessoa, {} );
    novaSolicitacao.loja = Object.assign( this.beneficio.loja, {} );

    let status = {} as StatusModel;
    status.ativo = true;
    status.codigo = 1;
    novaSolicitacao.statusDTO = Object.assign(status,{});

    console.log('PROVA DE VIDA=>' + JSON.stringify(novaSolicitacao));
    let retorno = false as Boolean;

    this.alertService.setLoading(true);
    this.provaVidaService.inserirSolicitacaoProvaVidaPromise(novaSolicitacao)
    .then(
      res => {
        retorno = <Boolean>res.status;
      })
    .catch(
      err=> {
        console.error('erro ao criar solicitacao de prova de vida inserirSolicitacaoProvaVidaPromise=>'+JSON.stringify(err))
        this.alertService.setLoading(false);
        this.alertService.dispatch('Erro ao Criar Solicitacao=>', err);
      }
    ).finally( () => {

      // Recarrega tabela apos insert
      this.provaVidaService
      .getSolicitacaoProvaVidaByBeneficioPromise(this.beneficio.codBeneficio+'')
      .then(
        res => {
          this.solicitacaoProvaVidaList = <SolicitacaoProvaVidaModel[]>res;
        })
      .catch(
        err=> {
          console.error('erro ao obter solicitacaoProvaVidaList=>'+JSON.stringify(err))
          this.alertService.setLoading(false);
          this.alertService.dispatch('Erro ao obter solicitacaoProvaVidaList=>', err);
        }
      ).finally( () => {
        this.alertService.setLoading(false);
        console.log("solicitacaoProvaVidaList carregada ==>" + JSON.stringify(this.solicitacaoProvaVidaList));
        if ((this.solicitacaoProvaVidaList) && (this.solicitacaoProvaVidaList.length>0)) {
          this.dataSource = new MatTableDataSource(this.solicitacaoProvaVidaList);
          this.showBotaoNovaSolicitacaoProvaVida = false;
          console.log('PROVA DE VIDA - dataSource =>' ,  this.dataSource );
        } else {
          this.showBotaoNovaSolicitacaoProvaVida = true;
        }
      });

    });
  }

  public trocarSolicitacao(solicitacao : SolicitacaoProvaVidaModel) {
    this.showDetalhesSolicitacao = true;
  }

  emptyTable(dataSource) {
    if(dataSource && dataSource.data && dataSource.data.length === 0) {
      return false;
    } else {
      return true;
    }
  }

}
