import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ModalComponentComponent } from '../modal-component/modal-component.component';
import { MatDialog } from '@angular/material';
import { ModalReprovaComponent } from '../modal-reprova/modal-reprova.component';
import { SolicitacaoBeneficioDataModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-data.model';
import { PessoaDocumentoModel } from 'src/app/model/pessoa/pessoa-documento.model';
import { PessoaFisicaModel } from 'src/app/model/pessoa/pessoa-fisica.model';
import { TipoDocumentoModel } from 'src/app/model/tipos/tipo-documento.model';
import { PessoaModel } from 'src/app/model/pessoa/pessoa.model';
import { PessoaRelativoModel } from 'src/app/model/pessoa/pessoa-relativo.model';

@Component({
  selector: 'app-analise-abertura-conta-beneficio',
  templateUrl: './analise-abertura-conta-beneficio.component.html',
  styleUrls: ['./analise-abertura-conta-beneficio.component.scss']
})
export class AnaliseAberturaContaBeneficioComponent implements OnInit {

  @Input() dadosPessoais;
  @Input() dadosEnderecos;
  @Input() dataFilaComparaDoc = [];

  dadosPessoaisForm = this.fb.group({
    nome: [null],
    numCpf: [null],
    numeroRG: [null],
    digitoRG: [null],
    dataNascimento: [null],
    orgaoEmissorRG: [null],
    dataEmissaoRG: [null],
    documentoIdentificacao: [null],
    numDocumento: [null],
    orgaoEmissorDocumento: [null],
    ufEmissaoDocumento: [],
    dataEmissaoDocumento: [null],
    nomePai: [null],
    nomeMae: [null]
  });

  animal: string;
  nickname: string;
  apareceDocs: any;

  // dataSourceDocuments: MatTableDataSource<any>;
  // displayedColumnsDocuments: ['docEsquerdo', 'docDireito', 'compara', 'remove'];
  displayedColumnsDocuments: string[] = [
    'docEsquerdo',
    'docDireito',
    'compara',
    'remove'
  ];

  hasUnitNumber = false;

  states = [
    { name: 'RG', abbreviation: 'AL' },
    { name: 'CNH', abbreviation: 'AK' },
    { name: 'Cetidão Nas', abbreviation: 'AS' }
  ];
  constructor(private fb: FormBuilder, public dialog: MatDialog) {}

  openDialog(item): void {
    const descDados = item.docEsquerdo.descDados || item.docDireito.descDados;
    console.log(descDados);
    const dialogRef = this.dialog.open(ModalComponentComponent, {
      data: item,
      height: 'auto'
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  modalReprova(): void {
    const dialogRef = this.dialog.open(ModalReprovaComponent, {});
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');
    });
  }

  ngOnInit(): void {
    this.dadosPessoaisForm.setValue({
      nome: this.dadosPessoais.pessoa.nomPessoa,
      numCpf: this.dadosPessoais.pessoaFisica.numCpf,
      numeroRG: this.dadosPessoais.pessoaDoc.numDocumento,
      digitoRG: this.dadosPessoais.pessoaDoc.digDocumento,
      orgaoEmissorRG: this.dadosPessoais.pessoaDoc.slgOrgemissor,
      dataNascimento: this.dadosPessoais.pessoaFisica.dtaNascimento,
      dataEmissaoRG: this.dadosPessoais.pessoaDoc.dtaEmissao,
      documentoIdentificacao: this.dadosPessoais.pessoaDoc.tpoDocumento
        .descricao,
      numDocumento: this.dadosPessoais.pessoaDoc.numDocumento,
      orgaoEmissorDocumento: this.dadosPessoais.pessoaDoc.slgOrgemissor,
      ufEmissaoDocumento: this.dadosPessoais.pessoaDoc.slgUf,
      dataEmissaoDocumento: this.dadosPessoais.pessoaDoc.dtaEmissao,
      nomePai: this.dadosPessoais.relativos.relativoPai.nomPessoarelativo,
      nomeMae: this.dadosPessoais.relativos.relativoMae.nomPessoarelativo
    });
  }

}
