import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'app-modal-reprova',
  templateUrl: './modal-reprova.component.html',
  styleUrls: ['./modal-reprova.component.scss']
})
export class ModalReprovaComponent {
  motivosSelecionados = [];
  observacao = '';

  constructor(
    private alertService: AlertService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ModalReprovaComponent>
  ) {}

  recusar(validForm) {
    if (validForm) {
      this.dialogRef.close({
        motivosRecusa: this.motivosSelecionados,
        desObservacao: this.observacao
      });
    } else {
      const errors = [];
      if (this.motivosSelecionados.length === 0) {
        errors.push('selecione ao menos 1 motivo de recusa');
      }

      if (this.observacao.length < 2) {
        errors.push('informe uma descrição válida');
      }

      this.alertService.dispatch('Por favor, ' + errors.join(', e '));
    }
  }

  cancelar() {
    this.dialogRef.close();
  }
}
