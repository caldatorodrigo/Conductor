import { Component, AfterViewInit, isDevMode } from "@angular/core";
import {
  FormBuilder,
  Validators,
  FormGroup,
  FormControl
} from "@angular/forms";
import { CadastroBusService } from "../../services/cadastro-bus.service";
import { BeneficioDataModel } from "src/app/model/beneficio/beneficio-data.model";
import { BeneficioSolicitacaoService } from "src/app/modulos/beneficio/services/beneficio-solicitacao.service";
import { SolicitacaoBeneficioDataModel } from "src/app/model/solicitacao/beneficio/solicitacao-beneficio-data.model";
import { last } from "rxjs/operators";
import { error } from "util";
import { PessoaService } from "src/app/modulos/pessoa/services/pessoa.service";
import { TipoProfissaoModel } from "src/app/model/tipos/tipo-profissao.model";
import { TipoEstadoCivilModel } from "src/app/model/tipos/tipo-estado-civil.model";
import { MatSnackBar } from "@angular/material";
import { MatIcon } from "@angular/material"
import { PessoaModel } from 'src/app/model/pessoa/pessoa.model';
import { stringify } from 'querystring';
import { TipoResidenciaModel } from 'src/app/model/tipos/tipo-residencia.model';
import { PessoaRelativoModel } from 'src/app/model/pessoa/pessoa-relativo.model';
import { TipoRelacaoModel } from 'src/app/model/tipos/tipo-relacao.model';
import { PessoaFisicaModel } from 'src/app/model/pessoa/pessoa-fisica.model';
import { BeneficioPagamentoService } from 'src/app/modulos/beneficio/services/beneficio-pagamento.service';
import { BeneficioPagamentoModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento.model';
import { BeneficioPagamentoResponseModel } from 'src/app/model/beneficio/pagamento/beneficio-pagamento-response-data.model';
import { CapturaCartaoModel } from 'src/app/model/beneficio/captura/captura-cartao.model';
import { SolicitacaoBeneficioDocumentoResponse } from 'src/app/model/documento/solicitacao-beneficio-documento-response.model';
import { SolicitacaoBeneficioDocumentoModel } from 'src/app/model/solicitacao/beneficio/documento/solicitacao-beneficio-documento.model';
import { PessoaEnderecoModel } from 'src/app/model/pessoa/pessoa-endereco.model';
import { PessoaDocumentoModel } from 'src/app/model/pessoa/pessoa-documento.model';
import { TipoDocumentoModel } from 'src/app/model/tipos/tipo-documento.model';
import { PessoaTelefoneModel } from 'src/app/model/pessoa/pessoa-telefone.model';
import { CpfPipe } from 'src/app/core/pipes/cpf.pipe';
import { DocumentoModel } from 'src/app/model/documento/documento.model';
import { PessoaEmailModel } from 'src/app/model/pessoa/pessoa-email.model';
import { PaisModel } from 'src/app/model/pais/pais.model';
import { SolicitacaoBeneficioRequestModel } from 'src/app/model/solicitacao/beneficio/solicitacao-beneficio-request.model';
import { StatusTipoModel } from 'src/app/model/tipos/tipo-status.model';
import { StatusModel } from 'src/app/model/status/status.model';
import { AlertService } from '../../services/alert.service';
import { stringToKeyValue } from '@angular/flex-layout/extended/typings/style/style-transforms';
import { PessoaPatrimonioModel } from 'src/app/model/pessoa/pessoa-patrimonio.model';
import { TipoPatrimonioModel } from 'src/app/model/tipos/tipo-patrimonio.model';
import { AlertType } from '../../models/alert.model';
import { resolve } from 'url';
import { PessoaFATCAModel } from 'src/app/model/pessoa/pessoa-fatca.model';
import { PessoaPEPModel } from 'src/app/model/pessoa/pessoa-pep.model';
import { MatDialog } from "@angular/material";
import { DigitalizacaoComponent } from 'src/app/modulos/digitalizacao/components/digitalizacao/digitalizacao.component';
import { CapturaImagemComponent } from "src/app/modulos/captura-imagem/captura-imagem.component";
import { Util } from 'src/app/core/utils/util';

interface SiglaSexo {
  id?: string;
  name?: string;
  checked?: boolean;
}

interface ProfissaoResponse {
  data?: Array<TipoProfissaoModel>;
}

interface EstadoCivilResponse {
  data?: Array<TipoEstadoCivilModel>;
}

interface Endereco {
  cep?: string;
  logradouro?: string;
  numeroLogradouro? :string;
  complementoLogradouro?: string;
  bairro?: string;
  cidade?: string;
  uf?: string;
  tipoResidencia?: string;
}

interface UF {
  uf? : string;
  descricao? : string;
}

interface UfResponse {
  data?: Array<UF>;
}

interface Cidade {
  codCidade? : string;
  desCidade?: string;
  uf?: string;
  flgAtivo?: boolean;
}

interface CidadeResponse {
  data?: Array<Cidade>;
}

interface TipoResidenciaResponse {
  data?: Array<TipoResidenciaModel>
}

interface TipoDocumentoPessoaResponse {
  data?: Array<DocumentoModel>
  exceptionMessage?:	string;
  hostname?:	string;
  message?:	string;
  status?:	boolean;
}

@Component({
  selector: "ficha-cadastro-dados-pessoais",
  templateUrl: "./cadastro.component.html",
  styleUrls: ["./cadastro.component.scss"]
})
export class CadastroComponent {
    public solicBenfPgto_escolhida:BeneficioPagamentoModel;
  beneficio: BeneficioDataModel = {};
  solicitacaoBeneficio: SolicitacaoBeneficioDataModel;
  solicitacaoBeneficioPagamentoPrincipal : BeneficioPagamentoModel;

  dadosPessoaisParteIForm: FormGroup;
  dadosaPessoaisParte2Form: FormGroup;
  dadosEnderecoForm: FormGroup;
  dadosContatoForm: FormGroup;
  // dadosCapturaDoc: FormGroup;
  dadosCapturaCartaoForm: FormGroup;
  dadosPatrimonioForm: FormGroup;
  dadosFATCAForm: FormGroup;
  dadosPEPForm: FormGroup;

  profissaoResponse: ProfissaoResponse;
  estadoCivilResponse: EstadoCivilResponse;
  ufResponse : UfResponse;
  profissoesList: Array<TipoProfissaoModel>;
  estadoCivilList: Array<TipoEstadoCivilModel>;
  ufList: Array<UF>;
  ufResTemp: string;
  cidadeResponse : CidadeResponse;
  cidadeList: Array<Cidade>;
  tipoResidenciaResponse : TipoResidenciaResponse;
  tipoResidenciaList: Array<TipoResidenciaModel>;
  solicitacaoBeneficioPagamentoResponse : BeneficioPagamentoResponseModel;
  solicitacaoBeneficioPagamentoList : Array<BeneficioPagamentoModel>;
  solicitacaoBeneficioDocumentoResponse : SolicitacaoBeneficioDocumentoResponse;
  solicitacaoBeneficioDocumentoList: Array<SolicitacaoBeneficioDocumentoModel>;
  tipoDocumentoPessoaResponse: TipoDocumentoPessoaResponse;
  tipoDocumentoPessoaList: Array<DocumentoModel>;
  pessoaFATCA: PessoaFATCAModel;
  pessoaPEP : PessoaPEPModel;

  showFichaCadastralProcurador: Boolean = false;
  showDadosPessoaisParte2: Boolean = false;
  showDadosEndereco: Boolean = false;
  showDadosContato : Boolean = false;
  showCapturaCartao: Boolean = false;
  showProsseguirCapturaCartao: Boolean = false;
  showDocumentos: Boolean = false;
  showExtrasContaCorrente: Boolean = false;
  showDigitalizacao:boolean = false;

  showBlockExtrasContaCorrente = {
    patrimonio: false,
    FATCA: false,
    PEP: false
  };

  /* VARIAVEIS PRA DEIXAR OS CAMPOS APENAS PARA LEITURA */
  isReadonlyDocumentoPart1 = true;
  isReadonlyDocumentoPart2 = true;
  isReadonlyEndereco = true;
  isReadonlyContato = true;
  isReadonlyCapturaCartao = true;
  isReadonlyPatrimonio = true;
  isReadonlyFATCA = true;
  isReadonlyPEP = true;

  /* VARIAVEIS PRA ADICIONAR FUNDO CINZA */
  backGroundCinzaParte1 = false;
  backGroundCinzaParte2 = false;
  backGroundCinzaEndereco = false;
  backGroundCinzaContato = false;
  backGroundCinzaCapturaCartao = false;
  backGroundCinzaPatrimonio = false;
  backGroundCinzaFATCA = false;
  backGroundCinzaPEP = false;

  selectReadyOnly = false;

  /* VARIAVEIS PRA ESCONDER O BOTAO PROSSEGUIR */
  escondeBotaoProsseguirDocPart1 = false;
  escondeBotaoProsseguirDocPart2 = false;
  escondeBotaoProsseguirEndereco = false;
  escondeBotaoProsseguirContato = false;
  escondeBotaoProsseguirPatrimonio = false;
  escondeBotaoProsseguirFATCA = false;
  escondeBotaoProsseguirPEP = false;

  /* VARIAVEIS PRA APARECER O BOTAO ALT */
  apareceBotaoAlteraDocPart1 = false;
  apareceBotaoAlteraDocPart2 = false;
  apareceBotaoAlteraEndereco = false;
  apareceBotaoAlteraContato = false;
  apareceBotaoAlteraPatrimonio = false;
  apareceBotaoAlteraFATCA = false;
  apareceBotaoAlteraPEP = false;

  possuiBensAndImoveis: Boolean = false;
  possuiDomicilioFiscalExterior: Boolean = false;
  possuiPEP: Boolean = false;
  showFichaCadastroPatrimonio : Boolean = false;
  showFichaDomicilioFiscalExterior : Boolean = false;
  showFichaPEP : Boolean = false;

  botaoAlterarSalvar = 'Alterar';
  botaoAlterarSalvar2 = 'Alterar';
  botaoAlterarSalvarContato = 'Alterar';
  botaoAlterarSalvarEndereco = 'Alterar';
  botaoAlterarSalvarPatrimonio = 'Alterar';
  botaoAlterarSalvarFATCA = 'Alterar';
  botaoAlterarSalvarPEP = 'Alterar';

  mapCartoesCapturados : Map<string, CapturaCartaoModel>;
  collapse : Boolean = true;

  fechaAbas;
  escondePainelDocumentos;
  telefoneFixoProprio;

    public dadosCapturaDocsForm: FormGroup = new FormGroup({
        manualOuBiometricoValue: new FormControl()
    });

  constructor(
    private fb: FormBuilder,
    private beneficioSolicitacaoService: BeneficioSolicitacaoService,
    private beneficioPagamentoService: BeneficioPagamentoService,
    private pessoaService: PessoaService,
    private cadastroBUS: CadastroBusService,
    public snackBar: MatSnackBar,
    private alertService: AlertService,
    public dialog: MatDialog
  ) {
    console.log(
      "------------- ini - carregou app-ficha-cadastral ------------"
    );

    this.mapCartoesCapturados = new Map<string, CapturaCartaoModel>();

    this.dadosPessoaisParteIForm = this.fb.group({
      nomeCliente: [null, Validators.required],
      dataNascimento: [null],
      siglaSexo: [null],
      profissoes: [null],
      estadoCivil: [null],
      nomeConjugue: [null],
      nomePai: [null],
      nomeMae: [null],
      nomeEmpresaTrabalho: [null]
    });

    this.dadosaPessoaisParte2Form = this.fb.group({
      numCpf: [null],
      numeroRG: [null],
      digitoRG: [null],
      orgaoEmissorRG: [null],
      dataEmissaoRG: [null],
      documentoIdentificacao: [null],
      numDocumento: [null],
      orgaoEmissorDocumento: [null],
      ufEmissaoDocumento : [null],
      dataEmissaoDocumento: [null]
    });

    this.dadosEnderecoForm = this.fb.group({
      cepResidencial: [null],
      logradouroResidencial: [null],
      numeroLogradouroResidencial: [null],
      complementoLogradouroResidencial: [null],
      bairroResidencial: [null],
      cidadeResidencial: [null],
      ufResidencial: [null],
      tipoResidenciaResidencial: [null]
    });

    this.dadosContatoForm = this.fb.group({
      email: [null],
      dddTelefoneFixo: [null],
      telefoneFixo: [null],
      telefoneFixoProprio: [null],
      dddTelefoneCelular: [null],
      telefoneCelular: [null],
      telefoneCelularProprio: [null],
    });

    this.dadosPatrimonioForm = this.fb.group({
      valorImoveis: [null],
      valorAutomoveis: [null],
      valorInvestimentos: [null],
      valorOutros: [null],
    });

    this.dadosFATCAForm = this.fb.group({
      nomeCompletoFATCA: [null],
      cpfFATCA: [null],
      localNascimentoFATCA: [null],
      enderecoResidencialFATCA: [null],
      numeroEnderecoResidencialFATCA: [null],
      complementoEnderecoResidencialFATCA: [null],
      bairroEnderecoResidencialFATCA: [null],
      flgEstudante: [null],
      flgDiplomata: [null],
      flgPresencaSubstancial: [null],
      flgAbdicouNacionalidade:[null],
      flgRenunciou: [null],
      flgPossuiGreencard: [null],
      flgCertificAbandono: [null],
      flgResideNosEua: [null],
      diasVisitaAnoCorrente: [null],
      diasVisitaAnoPassado: [null],
      diasVisitaAnoAnterior: [null],
    });

    this.dadosPEPForm = this.fb.group({
      possuirCargoPublico: [null],
      funcao:  [null],
      dtaInicio: [null],
      dtaFim: [null],
      empresa: [null],
      relacaoAgentePubli: [null],
      nomeRelacionado: [null],
      cpfRelalionado:  [null],
      funcaoRelacionado:  [null],
      tipoRelacionamento:  [null],
    });

    // this.dadosCapturaDoc = this.fb.group({
    //   tituloDocumento: [null],
    //   statusDocumento: [null],
    //   botaoAcaoDocumento: [null]
    // })

    this.dadosCapturaCartaoForm = this.fb.group({
      idContaCartao: [null]
    });

    this.pessoaService.listaProfissoes().subscribe((data: any) => {
      this.profissaoResponse = <ProfissaoResponse>data;
      this.profissoesList = this.profissaoResponse.data;
      // console.log("profissoesList=" + JSON.stringify(this.profissoesList));
    });

    this.pessoaService.getAllEstadoCivil().subscribe((data: any) => {
      this.estadoCivilResponse = <EstadoCivilResponse>data;
      this.estadoCivilList = this.estadoCivilResponse.data;
      // console.log("estadoCivilList=" + JSON.stringify(this.estadoCivilList));
    });

    this.pessoaService.getAllUF().subscribe((data: any) => {
      this.ufResponse = <UfResponse>data;
      this.ufList = <UF[]>this.ufResponse.data;
      // console.log("ufList=" + JSON.stringify(this.ufList));
    });

    this.pessoaService.getAllTipoResidencia().subscribe((data: any) => {
      this.tipoResidenciaResponse = <TipoResidenciaResponse>data;
      this.tipoResidenciaList = <TipoResidenciaModel[]>this.tipoResidenciaResponse.data;
      // console.log("tipoResidenciaList=" + JSON.stringify(this.tipoResidenciaList));
    });

    this.pessoaService.getAllTiposDocumentoPessoa().subscribe((data: any) => {
      this.tipoDocumentoPessoaResponse = <TipoDocumentoPessoaResponse>data;
      this.tipoDocumentoPessoaList = <DocumentoModel[]>this.tipoDocumentoPessoaResponse.data;
      // console.log("@@@@@@@@tipoDocumentoPessoaList=" + JSON.stringify(this.tipoDocumentoPessoaList));
    });

    this.cadastroBUS.beneficioSubject.subscribe(
      (data: any) => {
        this.beneficio = <BeneficioDataModel>data;
        console.log(
          "cadastro.beneficioSubject=" +
            JSON.stringify(this.beneficio)
        );
      },
      error => {
        console.log("+++++++ error beneficioSubject++++++++++ " + error);
      },
      () => {
        console.log("+++++++ completed beneficioSubject++++++++++");
      }
    );

    this.beneficioSolicitacaoService.getSolicitacao().subscribe(
      (data: any) => {
        this.solicitacaoBeneficio = <SolicitacaoBeneficioDataModel>data;
        console.log(
          "app-ficha-cadastral.solicitacaoBeneficioZZZX=" +
            JSON.stringify(this.solicitacaoBeneficio)
        );

        let relativoConjugue : PessoaRelativoModel = this.obterRelativo(257, this.solicitacaoBeneficio.pessoa.relativos);
        let relativoMae : PessoaRelativoModel = this.obterRelativo(254, this.solicitacaoBeneficio.pessoa.relativos);
        let relativoPai : PessoaRelativoModel = this.obterRelativo(253, this.solicitacaoBeneficio.pessoa.relativos);
        this.dadosPessoaisParteIForm.setValue({
          nomeCliente: this.solicitacaoBeneficio.pessoa.nomPessoa,
          dataNascimento: this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.dtaNascimento,
          siglaSexo: this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.slgSexo,
          profissoes: this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.tpoProfissao,
          estadoCivil: this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.tpoEstcivil,
          nomeConjugue: (relativoConjugue===null?"": ((relativoConjugue.nomPessoarelativo===null||relativoConjugue.nomPessoarelativo===null)?"":relativoConjugue.nomPessoarelativo) ),
          nomePai: (relativoPai===null?"": ((relativoPai.nomPessoarelativo===null||relativoPai.nomPessoarelativo===null)?"":relativoPai.nomPessoarelativo) ),
          nomeMae: (relativoMae===null?"": ((relativoMae.nomPessoarelativo===null||relativoMae.nomPessoarelativo===null)?"":relativoMae.nomPessoarelativo) ),
          nomeEmpresaTrabalho: (this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.nomEmpresa==undefined?"":this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.nomEmpresa)
        });

        let cpfFormatter : CpfPipe = new CpfPipe();
        let pessoaDocumetoRG : PessoaDocumentoModel = this.obtemDocumentoRG( this.solicitacaoBeneficio );
        let pessoaDocumentoNaoRG : PessoaDocumentoModel = this.obtemDocumentoNaoRG( this.solicitacaoBeneficio );
        this.dadosaPessoaisParte2Form.setValue({
          numCpf: (this.isObjectNullOrUndefined(this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.numCpf) ? '' : new Util().convertToCPF(this.solicitacaoBeneficio.pessoa.dadosPessoaFisica.numCpf)),
          numeroRG: pessoaDocumetoRG.numDocumento,
          digitoRG: pessoaDocumetoRG.digDocumento,
          orgaoEmissorRG: pessoaDocumetoRG.slgOrgemissor,
          dataEmissaoRG: pessoaDocumetoRG.dtaEmissao,
          documentoIdentificacao: pessoaDocumentoNaoRG.tpoDocumento.descricao,
          numDocumento: pessoaDocumentoNaoRG.numDocumento,
          orgaoEmissorDocumento: pessoaDocumentoNaoRG.slgOrgemissor,
          ufEmissaoDocumento : pessoaDocumentoNaoRG.slgUf,
          dataEmissaoDocumento: pessoaDocumentoNaoRG.dtaEmissao,
        });

        let endereco: Endereco = this.obtemEnderecoResidencial(this.solicitacaoBeneficio);
        this.ufResTemp = endereco.uf;
        this.dadosEnderecoForm.setValue ({
          cepResidencial: endereco.cep,
          logradouroResidencial: endereco.logradouro,
          numeroLogradouroResidencial: endereco.numeroLogradouro,
          complementoLogradouroResidencial: endereco.complementoLogradouro,
          bairroResidencial: endereco.bairro,
          cidadeResidencial: endereco.cidade,
          ufResidencial: endereco.uf,
          tipoResidenciaResidencial: endereco.tipoResidencia
        });

        let pessoaTelefoneCelular: PessoaTelefoneModel = this.obterTelefonePessoaCelular( this.solicitacaoBeneficio );
        let pessoaTelefoneNaoCelular: PessoaTelefoneModel = this.obterTelefonePessoaNaoCelular( this.solicitacaoBeneficio );
        console.log('pessoaTelefoneCelular='+JSON.stringify(pessoaTelefoneCelular));
        console.log('pessoaTelefoneNaoCelular='+JSON.stringify(pessoaTelefoneNaoCelular));
        this.dadosContatoForm.setValue({
          email: ( (this.isObjectNullOrUndefined(this.solicitacaoBeneficio.pessoa.emails)||
                   (this.solicitacaoBeneficio.pessoa.emails.length<=0))?'': this.solicitacaoBeneficio.pessoa.emails[0].desEmail),
          dddTelefoneFixo:  pessoaTelefoneNaoCelular.numDdd,
          telefoneFixo: pessoaTelefoneNaoCelular.numTelefone,
          telefoneFixoProprio: pessoaTelefoneNaoCelular.flgPessoal,
          dddTelefoneCelular: pessoaTelefoneCelular.numDdd,
          telefoneCelular: pessoaTelefoneCelular.numTelefone,
          telefoneCelularProprio: pessoaTelefoneCelular.flgPessoal,
        });

        this.obterCidadesFromUF();

      },
      error => {
        console.log("+++++++ error ++++++++++ " + error);
      },
      () => {


        this.beneficioPagamentoService.getBeneficioPagamentoByCodigoSolicitacaoBeneficioPromise(''+this.solicitacaoBeneficio.codSolicbeneficio).then(
          (res) => {
            this.solicitacaoBeneficioPagamentoResponse = <BeneficioPagamentoResponseModel>res;
            this.solicitacaoBeneficioPagamentoList = <BeneficioPagamentoModel[]>this.solicitacaoBeneficioPagamentoResponse.data
            console.log(
              '__________cadastro.getBeneficioPagamentoByCodigoSolicitacaoBeneficio=' +
                JSON.stringify( this.solicitacaoBeneficioPagamentoList )
            );

            this.dadosCapturaCartaoForm.setValue({
              idContaCartao: ""
            });

          }
        ).catch(x=>{
          console.error('erro ao obter solicitacaoBeneficioPagamentoList='+JSON.stringify(x));
        })
        ;

        console.log("+++++++ completed ++++++++++");
      }
    );

    console.log(
      "------------- fim - carregou this.solicitacaoBeneficioPagamentoList=",this.solicitacaoBeneficioPagamentoList
    );
  }



  obterCidadesFromUF () {
    let uf : string;
    let ufSelecionada: UF = <UF>this.dadosEnderecoForm.get("ufResidencial").value
    // console.log('ufSelecionada='+ufSelecionada.uf);
    if (ufSelecionada.uf===undefined) {
      uf = this.ufResTemp ;
    } else {
      uf = ufSelecionada.uf;
    }
    this.pessoaService.getCidadePorUF( uf ).subscribe((data: any) => {
      this.cidadeResponse = <CidadeResponse>data;
      this.cidadeList = <Cidade[]>this.cidadeResponse.data;
      // console.log("cidadeList=" + JSON.stringify(this.cidadeList));
    });
  }

  isObjectNullOrUndefined(object: any) {
    let retorno : Boolean = false;
    if( (object===null) || object===undefined ) {
      retorno = true;
    }
    return retorno;
  }

  private obtemDocumentoRG (solicitacao: SolicitacaoBeneficioDataModel): PessoaDocumentoModel {
    let pessoaDocumentoRG = {} as PessoaDocumentoModel;
    let tipoDocumentoRG = {} as TipoDocumentoModel;
    tipoDocumentoRG.ativo = false;
    tipoDocumentoRG.codigo = 0;
    tipoDocumentoRG.descricao = '';
    pessoaDocumentoRG.numDocumento = '';
    pessoaDocumentoRG.digDocumento = '';
    pessoaDocumentoRG.slgOrgemissor = '';
    pessoaDocumentoRG.dtaEmissao  = new Date('01/01/1900');
    pessoaDocumentoRG.tpoDocumento = Object.assign({}, tipoDocumentoRG );
    pessoaDocumentoRG.slgUf = '';

    if (
        (solicitacao.pessoa.documentos != null) &&
        (solicitacao.pessoa.documentos != undefined) &&
        (solicitacao.pessoa.documentos.length > 0)
    ) {
      for (var i = 0; i < solicitacao.pessoa.documentos.length; i++) {

        if ((solicitacao.pessoa.documentos[i].tpoDocumento.descricao === 'RG') &&
            (solicitacao.pessoa.documentos[i].tpoDocumento != null) &&
            (solicitacao.pessoa.documentos[i].tpoDocumento != undefined)
        ){
          pessoaDocumentoRG.numDocumento = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].numDocumento)? '' : solicitacao.pessoa.documentos[i].numDocumento);
          pessoaDocumentoRG.digDocumento = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].digDocumento)? '' : solicitacao.pessoa.documentos[i].digDocumento);
          pessoaDocumentoRG.slgOrgemissor = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].slgOrgemissor)? '' : solicitacao.pessoa.documentos[i].slgOrgemissor);
          pessoaDocumentoRG.dtaEmissao  = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].dtaEmissao)? new Date() : solicitacao.pessoa.documentos[i].dtaEmissao);
          if(!this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].tpoDocumento)) {
            pessoaDocumentoRG.tpoDocumento = Object.assign({},solicitacao.pessoa.documentos[i].tpoDocumento);
          }
          pessoaDocumentoRG.slgUf = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].slgUf)? '' : solicitacao.pessoa.documentos[i].slgUf);
          return pessoaDocumentoRG;
        }
      }
    }
    return pessoaDocumentoRG ;
  }

  private obtemDocumentoNaoRG (solicitacao: SolicitacaoBeneficioDataModel): PessoaDocumentoModel {
    let pessoaDocumentoNaoRG = {} as PessoaDocumentoModel;
    let tipoDocumentoNaoRG = {} as TipoDocumentoModel;
    tipoDocumentoNaoRG.ativo = false;
    tipoDocumentoNaoRG.codigo = 0;
    tipoDocumentoNaoRG.descricao = '';
    pessoaDocumentoNaoRG.numDocumento = '';
    pessoaDocumentoNaoRG.digDocumento = '';
    pessoaDocumentoNaoRG.slgOrgemissor = '';
    pessoaDocumentoNaoRG.dtaEmissao  = new Date('01/01/1900');
    pessoaDocumentoNaoRG.tpoDocumento = Object.assign({}, tipoDocumentoNaoRG );
    pessoaDocumentoNaoRG.slgUf = '';

    if (
        (solicitacao.pessoa.documentos != null) &&
        (solicitacao.pessoa.documentos != undefined) &&
        (solicitacao.pessoa.documentos.length > 0)
    ) {
      for (var i = 0; i < solicitacao.pessoa.documentos.length; i++) {

        if ((solicitacao.pessoa.documentos[i].tpoDocumento.descricao != 'RG') &&
            (solicitacao.pessoa.documentos[i].tpoDocumento != null) &&
            (solicitacao.pessoa.documentos[i].tpoDocumento != undefined)
        ){
          pessoaDocumentoNaoRG.numDocumento = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].numDocumento)? '' : solicitacao.pessoa.documentos[i].numDocumento);
          pessoaDocumentoNaoRG.digDocumento = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].digDocumento)? '' : solicitacao.pessoa.documentos[i].digDocumento);
          pessoaDocumentoNaoRG.slgOrgemissor = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].slgOrgemissor)? '' : solicitacao.pessoa.documentos[i].slgOrgemissor);
          pessoaDocumentoNaoRG.dtaEmissao  = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].dtaEmissao)? new Date() : solicitacao.pessoa.documentos[i].dtaEmissao);
          if(!this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].tpoDocumento)) {
            pessoaDocumentoNaoRG.tpoDocumento = Object.assign({},solicitacao.pessoa.documentos[i].tpoDocumento);
          }
          pessoaDocumentoNaoRG.slgUf = (this.isObjectNullOrUndefined(solicitacao.pessoa.documentos[i].slgUf)? '' : solicitacao.pessoa.documentos[i].slgUf);
          return pessoaDocumentoNaoRG;
        }
      }
    }
    return pessoaDocumentoNaoRG ;
  }


  obtemEnderecoResidencial( solicitacao: SolicitacaoBeneficioDataModel): Endereco {
    let endereco = {} as Endereco;
    if (
      solicitacao.pessoa.enderecos != null &&
      solicitacao.pessoa.enderecos != undefined
    ) {
      for (var i = 0; i < solicitacao.pessoa.enderecos.length; i++) {
        if (solicitacao.pessoa.enderecos[i].flgResidencial === true) {
          endereco.cep = (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].numCep)? '' : solicitacao.pessoa.enderecos[i].numCep);
          endereco.logradouro = (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].desLogradouro)? '' : solicitacao.pessoa.enderecos[i].desLogradouro);
          endereco.numeroLogradouro = (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].numEndereco)? '' : solicitacao.pessoa.enderecos[i].numEndereco);
          endereco.complementoLogradouro =
          (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].desComplemento)? '' : solicitacao.pessoa.enderecos[i].desComplemento);
          endereco.bairro = (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].desBairro)? '' : solicitacao.pessoa.enderecos[i].desBairro);
          endereco.cidade = (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].desCidade)? '' : solicitacao.pessoa.enderecos[i].desCidade);
          endereco.uf = (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].slgUf) ? '' : solicitacao.pessoa.enderecos[i].slgUf);
          endereco.tipoResidencia = (this.isObjectNullOrUndefined(solicitacao.pessoa.enderecos[i].tpoResidencia.desTiporesidencia) ? '' : solicitacao.pessoa.enderecos[i].tpoResidencia.desTiporesidencia);
          return endereco;
        }
      }
    } else {
      endereco.cep = '';
      endereco.logradouro = '';
      endereco.numeroLogradouro = '';
      endereco.complementoLogradouro = '';
      endereco.bairro = '';
      endereco.cidade = '';
      endereco.uf = '';
      endereco.tipoResidencia = '';
    }
    return endereco ;
  }

  private obterTelefonePessoaCelular (solicitacao: SolicitacaoBeneficioDataModel): PessoaTelefoneModel {
    let pessoaTelefoneCelular = {} as PessoaTelefoneModel;
    pessoaTelefoneCelular.numDdd = '';
    pessoaTelefoneCelular.numTelefone = '';
    pessoaTelefoneCelular.flgCelular = false;
    pessoaTelefoneCelular.flgPessoal = false;

    if (
        (solicitacao.pessoa.telefones != null) &&
        (solicitacao.pessoa.telefones != undefined) &&
        (solicitacao.pessoa.telefones.length > 0)
    ) {
      for (var i = 0; i < solicitacao.pessoa.telefones.length; i++) {
        if ((solicitacao.pessoa.telefones[i].flgCelular) &&
            (solicitacao.pessoa.telefones[i].numTelefone != null) &&
            (solicitacao.pessoa.telefones[i].numTelefone != undefined)
        ){
          pessoaTelefoneCelular.numDdd = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].numDdd)? '' : solicitacao.pessoa.telefones[i].numDdd);
          pessoaTelefoneCelular.numTelefone = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].numTelefone)? '' : solicitacao.pessoa.telefones[i].numTelefone);
          pessoaTelefoneCelular.flgCelular = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].flgCelular)? false : solicitacao.pessoa.telefones[i].flgCelular);
          pessoaTelefoneCelular.flgPessoal  = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].flgPessoal)? false : solicitacao.pessoa.telefones[i].flgPessoal);
          return pessoaTelefoneCelular;
        }
      }
    }
    return pessoaTelefoneCelular ;
  }

  private obterTelefonePessoaNaoCelular (solicitacao: SolicitacaoBeneficioDataModel): PessoaTelefoneModel {
    let pessoaTelefoneNaoCelular = {} as PessoaTelefoneModel;
    pessoaTelefoneNaoCelular.numDdd = '';
    pessoaTelefoneNaoCelular.numTelefone = '';
    pessoaTelefoneNaoCelular.flgCelular = false;
    pessoaTelefoneNaoCelular.flgPessoal = false;

    if (
        (solicitacao.pessoa.telefones != null) &&
        (solicitacao.pessoa.telefones != undefined) &&
        (solicitacao.pessoa.telefones.length > 0)
    ) {
      for (var i = 0; i < solicitacao.pessoa.telefones.length; i++) {
        if ((!solicitacao.pessoa.telefones[i].flgCelular) &&
            (solicitacao.pessoa.telefones[i].numTelefone != null) &&
            (solicitacao.pessoa.telefones[i].numTelefone != undefined)
        ){
          pessoaTelefoneNaoCelular.numDdd = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].numDdd)? '' : solicitacao.pessoa.telefones[i].numDdd);
          pessoaTelefoneNaoCelular.numTelefone = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].numTelefone)? '' : solicitacao.pessoa.telefones[i].numTelefone);
          pessoaTelefoneNaoCelular.flgCelular = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].flgCelular)? false : solicitacao.pessoa.telefones[i].flgCelular);
          pessoaTelefoneNaoCelular.flgPessoal  = (this.isObjectNullOrUndefined(solicitacao.pessoa.telefones[i].flgPessoal)? false : solicitacao.pessoa.telefones[i].flgPessoal);
          return pessoaTelefoneNaoCelular;
        }
      }
    }
    return pessoaTelefoneNaoCelular ;
  }

  prosseguir(parte: string) {
    if (parte === "parte1") {

      let pessoaParteI: PessoaModel = {};
      pessoaParteI = Object.assign({}, this.solicitacaoBeneficio.pessoa );
      console.log('pessoaParteI='+JSON.stringify(pessoaParteI));

      // pessoa.nomeCliente
      if( this.dadosPessoaisParteIForm.get("nomeCliente").dirty ){
        pessoaParteI.nomPessoa = this.dadosPessoaisParteIForm.get("nomeCliente").value;
        pessoaParteI.nomPessoa = pessoaParteI.nomPessoa.toUpperCase();
      }

      // TODO: chamar atualizarPessoa para atualizar o nome
      // TODO: verificar se vale atualizar o Pessoa e fazer uma unica chamada
      // TODO: criar um servico para atualizar apenas nome do cliente senao sera necessario atualizar
      //       todo o objeto pessoa o que parece concorrer com as chamadas individuais dos
      //       fragmentos do objeto pessoa.
      // pessoaParteI.dadosPessoaFisica = Object.assign({}, dadosPessoaFisicaParteI);
      // this.pessoaService.atualizarPessoa( pessoaParteI );

      // trata dadosPessoaFisica
      let dadosPessoaFisicaParteI : PessoaFisicaModel = {};
      if( (this.solicitacaoBeneficio.pessoa.dadosPessoaFisica!=null) ||
          (this.solicitacaoBeneficio.pessoa.dadosPessoaFisica!=undefined)) {
            dadosPessoaFisicaParteI = Object.assign({}, this.solicitacaoBeneficio.pessoa.dadosPessoaFisica);
      }

      // dadosPessoaFisica.dataNascimento
      if( this.dadosPessoaisParteIForm.get("dataNascimento").dirty ) {
        dadosPessoaFisicaParteI.dtaNascimento = this.dadosPessoaisParteIForm.get("dataNascimento").value;
      }

      // dadosPessoaFisica.siglaSexo
      console.log('this.dadosPessoaisParteIForm.get(siglaSexo).dirty='+this.dadosPessoaisParteIForm.get("siglaSexo").dirty );
      if( this.dadosPessoaisParteIForm.get("siglaSexo").dirty ) {
        dadosPessoaFisicaParteI.slgSexo = this.dadosPessoaisParteIForm.get("siglaSexo").value;
      }

      // dadosPessoaFisica.profissoes
      if( this.dadosPessoaisParteIForm.get("profissoes").dirty ) {
        let tipoProfissaoPF: TipoProfissaoModel = <TipoProfissaoModel>this.dadosPessoaisParteIForm.get("profissoes").value;
        dadosPessoaFisicaParteI.tpoProfissao = Object.assign({}, tipoProfissaoPF);
      }

      // dadosPessoaFisica.estadoCivil
      if( this.dadosPessoaisParteIForm.get("estadoCivil").dirty ) {
        let estadoCivilPF: TipoEstadoCivilModel = <TipoEstadoCivilModel>this.dadosPessoaisParteIForm.get("estadoCivil").value
        dadosPessoaFisicaParteI.tpoEstcivil = Object.assign({}, estadoCivilPF);
      }

      // dadosPessoaFisica.nomeEmpresaTrabalho
      if( this.dadosPessoaisParteIForm.get("nomeEmpresaTrabalho").dirty ) {
        dadosPessoaFisicaParteI.nomEmpresa = this.dadosPessoaisParteIForm.get("nomeEmpresaTrabalho").value;
      }

      this.pessoaService.atualizarPessoaFisica( dadosPessoaFisicaParteI );

      console.log('this.solicitacaoBeneficio.pessoa.relativos='+JSON.stringify(this.solicitacaoBeneficio.pessoa.relativos));
      if( (this.solicitacaoBeneficio.pessoa.relativos===undefined) ||
          (this.solicitacaoBeneficio.pessoa.relativos.length === 0)) {

            if( this.dadosPessoaisParteIForm.get("nomeMae").dirty ){
              console.log('dados da mae alterados');

              let relativoMae : PessoaRelativoModel = {};
              relativoMae.codPessoa = pessoaParteI.codPessoa;
              relativoMae.slgSexo = "F";
              relativoMae.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomeMae").value;
              relativoMae.nomPessoarelativo = relativoMae.nomPessoarelativo.toUpperCase();

              let tipoRelacaoMae : TipoRelacaoModel = {};
              tipoRelacaoMae.codTiporelacao = 254;
              tipoRelacaoMae.flgAtivo = true;
              relativoMae.tpoRelacao = Object.assign({}, tipoRelacaoMae);

              this.pessoaService.inserirPessoaRelativo( relativoMae );

            } else {
              console.log('dados da mae NAO FORAM alterados');
            }


            if( this.dadosPessoaisParteIForm.get("nomePai").dirty ){
              console.log('dados da pai alterados');

              let relativoPai : PessoaRelativoModel = {};
              relativoPai.codPessoa = pessoaParteI.codPessoa;
              relativoPai.slgSexo = "M";
              relativoPai.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomePai").value;
              relativoPai.nomPessoarelativo = relativoPai.nomPessoarelativo.toUpperCase();

              let tipoRelacaoPai : TipoRelacaoModel = {};
              tipoRelacaoPai.codTiporelacao = 253;
              tipoRelacaoPai.flgAtivo = true;
              relativoPai.tpoRelacao = Object.assign({}, tipoRelacaoPai);

              this.pessoaService.inserirPessoaRelativo( relativoPai );

            } else {
              console.log('dados da mae NAO FORAM alterados');
            }

            if( this.dadosPessoaisParteIForm.get("nomeConjugue").dirty ){
              console.log('dados do conjugue alterados');

              let relativoConjugue : PessoaRelativoModel = {};
              relativoConjugue.codPessoa = pessoaParteI.codPessoa;
              relativoConjugue.slgSexo = "";
              relativoConjugue.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomeConjugue").value;
              relativoConjugue.nomPessoarelativo = relativoConjugue.nomPessoarelativo.toUpperCase();

              let tipoRelacaoConjugue : TipoRelacaoModel = {};
              tipoRelacaoConjugue.codTiporelacao = 257;
              tipoRelacaoConjugue.flgAtivo = true;
              relativoConjugue.tpoRelacao = Object.assign({}, tipoRelacaoConjugue);

              this.pessoaService.inserirPessoaRelativo( relativoConjugue );

            } else {
              console.log('dados da mae NAO FORAM alterados');
            }

      } else {
        // Se ja existe relativo faz PUT

        let relativoConjugue : PessoaRelativoModel = this.obterRelativo(257, this.solicitacaoBeneficio.pessoa.relativos);
        let relativoPai : PessoaRelativoModel = this.obterRelativo(253, this.solicitacaoBeneficio.pessoa.relativos);
        let relativoMae : PessoaRelativoModel = this.obterRelativo(254, this.solicitacaoBeneficio.pessoa.relativos);

        console.log('dadosdopaidirty='+this.dadosPessoaisParteIForm.get("nomePai").dirty);

        if (relativoConjugue != null) {
          if( this.dadosPessoaisParteIForm.get("nomeConjugue").dirty ){
            relativoConjugue.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomeConjugue").value;
            relativoConjugue.nomPessoarelativo = relativoConjugue.nomPessoarelativo.toUpperCase();
            this.pessoaService.atualizarPessoaRelativo( relativoConjugue );
          }
        } else {
          if( this.dadosPessoaisParteIForm.get("nomeConjugue").dirty ){
            // FAZ POST
            let relativoConjugueNovo : PessoaRelativoModel = {};
            relativoConjugueNovo.codPessoa = pessoaParteI.codPessoa;
            relativoConjugueNovo.slgSexo = "";
            relativoConjugueNovo.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomeConjugue").value;
            relativoConjugueNovo.nomPessoarelativo = relativoConjugueNovo.nomPessoarelativo.toUpperCase();

            let tipoRelacaoConjugueNovo : TipoRelacaoModel = {};
            tipoRelacaoConjugueNovo.codTiporelacao = 257;
            tipoRelacaoConjugueNovo.flgAtivo = true;
            relativoConjugueNovo.tpoRelacao = Object.assign({}, tipoRelacaoConjugueNovo);
            this.pessoaService.inserirPessoaRelativo( relativoConjugueNovo );
          }
        }


        if (relativoPai != null) {
          if( this.dadosPessoaisParteIForm.get("nomePai").dirty ){
            relativoPai.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomePai").value;
            relativoPai.nomPessoarelativo = relativoPai.nomPessoarelativo.toUpperCase();
            this.pessoaService.atualizarPessoaRelativo( relativoPai );
          }
        } else {
          if( this.dadosPessoaisParteIForm.get("nomePai").dirty ){
            // FAZ POST
            let relativoPaiNovo : PessoaRelativoModel = {};
            relativoPaiNovo.codPessoa = pessoaParteI.codPessoa;
            relativoPaiNovo.slgSexo = "M";
            relativoPaiNovo.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomePai").value;
            relativoPaiNovo.nomPessoarelativo = relativoPaiNovo.nomPessoarelativo.toUpperCase();

            let tipoRelacaoPaiNovo : TipoRelacaoModel = {};
            tipoRelacaoPaiNovo.codTiporelacao = 253;
            tipoRelacaoPaiNovo.flgAtivo = true;
            relativoPaiNovo.tpoRelacao = Object.assign({}, tipoRelacaoPaiNovo);
            this.pessoaService.inserirPessoaRelativo( relativoPaiNovo );
          }
        }

        if (relativoMae != null) {
          if( this.dadosPessoaisParteIForm.get("nomeMae").dirty ){
            relativoMae.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomeMae").value;
            relativoMae.nomPessoarelativo = relativoMae.nomPessoarelativo.toUpperCase();
            this.pessoaService.atualizarPessoaRelativo( relativoMae );
          }
        } else {
          if( this.dadosPessoaisParteIForm.get("nomeMae").dirty ){
            // FAZ POST
            let relativoMaeNovo : PessoaRelativoModel = {};
            relativoMaeNovo.codPessoa = pessoaParteI.codPessoa;
            relativoMaeNovo.slgSexo = "F";
            relativoMaeNovo.nomPessoarelativo = this.dadosPessoaisParteIForm.get("nomeMae").value;
            relativoMaeNovo.nomPessoarelativo = relativoMaeNovo.nomPessoarelativo.toUpperCase();

            let tipoRelacaoMaeNovo : TipoRelacaoModel = {};
            tipoRelacaoMaeNovo.codTiporelacao = 254;
            tipoRelacaoMaeNovo.flgAtivo = true;
            relativoMaeNovo.tpoRelacao = Object.assign({}, tipoRelacaoMaeNovo);
            this.pessoaService.inserirPessoaRelativo( relativoMaeNovo );
          }
        }

      }

      console.log('---------------------------------------------------');
      this.showDadosPessoaisParte2 = true;
    }

    // Pessoa parte 2
    if(parte === "parte2"){

      let pessoaDocumentoParte2RG : PessoaDocumentoModel = {};
      let pessoaDocumentoParte2NaoRG : PessoaDocumentoModel = {};
      let indexPessoaDocumentoRG : number = this.findIndexPessoaDocumentoRG(this.solicitacaoBeneficio);
      let indexPessoaDocumentoNaoRG : number = this.findIndexPessoaDocumentoNaoRG(this.solicitacaoBeneficio);
      let houveAlteracaoParteRG : Boolean = this.houveAlteracaoDocumentoPessoaParteRG();
      let houveAlteracaoParteNaoRG : Boolean = this.houveAlteracaoDocumentoPessoaParteNaoRG();

      // Caso houve alguma alteracao nos campos do RG
      if (houveAlteracaoParteRG) {
        // Caso possua RG
        if( indexPessoaDocumentoRG > -1 ) {
          pessoaDocumentoParte2RG = Object.assign({}, this.solicitacaoBeneficio.pessoa.documentos[indexPessoaDocumentoRG] );
          console.log('************************this.solicitacaoBeneficio.pessoa.documentos[indexPessoaDocumentoRG]='+ JSON.stringify(this.solicitacaoBeneficio.pessoa.documentos[indexPessoaDocumentoRG]));
          pessoaDocumentoParte2RG = Object.assign({}, this.popularDadosDocumentoRGFromForm(pessoaDocumentoParte2RG));
          this.pessoaService.atualizarPessoaDocumento( pessoaDocumentoParte2RG );
        } else {
          pessoaDocumentoParte2RG = Object.assign({}, this.popularDadosDocumentoRGFromForm(pessoaDocumentoParte2RG));
          pessoaDocumentoParte2RG.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
          // TODO: Tirar codigo fixo do RG e buscar da
          //       lista de Dominios (http://10.203.146.22/api/Documento/v1/consultar-por-tipo/1/false)
          let tipoDocumento : TipoDocumentoModel = {};
          tipoDocumento.codigo = 1;
          tipoDocumento.ativo = true;
          pessoaDocumentoParte2RG.tpoDocumento = Object.assign({}, tipoDocumento);

          let pais: PaisModel = {};
          pais.codPais = 1;
          pais.flgAtivo = true;
          pessoaDocumentoParte2RG.codPais = Object.assign({}, pais);
          pessoaDocumentoParte2RG.flgAtivo = true;
          pessoaDocumentoParte2RG.flgDocdeidentificacao = true;
          this.pessoaService.inserirPessoaDocumento( pessoaDocumentoParte2RG );
        }
      }

      // Caso houve alguma alteracao nos campos NAO RG
      if (houveAlteracaoParteNaoRG) {
        // Caso possua outro documento diferente de RG
        if( indexPessoaDocumentoNaoRG > -1 ) {
          pessoaDocumentoParte2NaoRG = Object.assign({}, this.solicitacaoBeneficio.pessoa.documentos[indexPessoaDocumentoNaoRG] );
          pessoaDocumentoParte2NaoRG = Object.assign({}, this.popularDadosDocumentoNaoRGFromForm(pessoaDocumentoParte2NaoRG));
          this.pessoaService.atualizarPessoaDocumento( pessoaDocumentoParte2NaoRG );
        } else {
          pessoaDocumentoParte2NaoRG = Object.assign({}, this.popularDadosDocumentoNaoRGFromForm(pessoaDocumentoParte2NaoRG));
          console.log('#############pessoaDocumentoParte2NaoRG='+ JSON.stringify(pessoaDocumentoParte2NaoRG));

          pessoaDocumentoParte2NaoRG.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
          pessoaDocumentoParte2NaoRG.codPais = {};
          let pais: PaisModel = {};
          pais.codPais = 1;
          pais.flgAtivo = true;
          pessoaDocumentoParte2NaoRG.codPais = Object.assign({}, pais);
          pessoaDocumentoParte2NaoRG.flgAtivo = true;
          pessoaDocumentoParte2NaoRG.flgDocdeidentificacao = true;
          this.pessoaService.inserirPessoaDocumento( pessoaDocumentoParte2NaoRG );
        }
      }

      this.showDadosEndereco = true;
    }

    // Pessoa Endereco
    if(parte === "parte3"){
      if (this.houveAlteracaoEndereco()) {
        let pessoaEnderecoParte3 : PessoaEnderecoModel = {};
        let indexEnderecoResidencial : number = this.findIndexPessoaEnderecoResidencial(this.solicitacaoBeneficio);

        if( (!this.isObjectNullOrUndefined( this.solicitacaoBeneficio.pessoa.enderecos )) && (indexEnderecoResidencial>-1) ) {
          pessoaEnderecoParte3 = Object.assign({}, this.solicitacaoBeneficio.pessoa.enderecos[indexEnderecoResidencial] );
          pessoaEnderecoParte3 = Object.assign({}, this.popularDadosEnderecoFromForm(pessoaEnderecoParte3));
          this.pessoaService.atualizarPessoaEndereco( pessoaEnderecoParte3 );
        } else {
          pessoaEnderecoParte3 = Object.assign({}, this.popularDadosEnderecoFromForm(pessoaEnderecoParte3));
          pessoaEnderecoParte3.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
          pessoaEnderecoParte3.flgResidencial = true;
          pessoaEnderecoParte3.flgResidenciaatual = true;
          pessoaEnderecoParte3.flgAtivo = true;
          this.pessoaService.inserirPessoaEndereco( pessoaEnderecoParte3 );
        }
      }
      this.showDadosContato = true;
    }

    // Pessoa Contato
    if(parte === "parte4") {

      // -------------- ini: contato-telefones ------------------
      let pessoaTelefoneFixo : PessoaTelefoneModel = {};
      let pessoaTelefoneCelular : PessoaTelefoneModel = {};
      let indexPessoaTelefoneFixo : number = this.findIndexPessoaTelefoneFixo(this.solicitacaoBeneficio);
      let indexTelefoneCelular : number = this.findIndexPessoaTelefoneCelular(this.solicitacaoBeneficio);
      let houveAlteracaoTelefoneFixo : Boolean = this.houveAlteracaoParteTelefoneFixo();
      let houveAlteracaoTelefoneCelular : Boolean = this.houveAlteracaoParteTelefoneCelular();

      // Caso houve alguma alteracao nos campos do telefone fixo
      if (houveAlteracaoTelefoneFixo) {
        // Caso possua Telefone Fixo
        if( indexPessoaTelefoneFixo > -1 ) {
          pessoaTelefoneFixo = Object.assign({}, this.solicitacaoBeneficio.pessoa.telefones[indexPessoaTelefoneFixo] );
          pessoaTelefoneFixo = Object.assign({}, this.popularDadosTelefoneFixoFromForm(pessoaTelefoneFixo));
          this.pessoaService.atualizarPessoaTelefone( pessoaTelefoneFixo );
        } else {
          pessoaTelefoneFixo = Object.assign({}, this.popularDadosTelefoneFixoFromForm(pessoaTelefoneFixo));
          pessoaTelefoneFixo.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
          pessoaTelefoneFixo.flgAtivo = true;
          pessoaTelefoneFixo.flgCelular = false;
          pessoaTelefoneFixo.codPais = ((this.isObjectNullOrUndefined(this.solicitacaoBeneficio.pessoa.pais)&&(this.solicitacaoBeneficio.pessoa.pais.codPais>0))?this.solicitacaoBeneficio.pessoa.pais.codPais:1);
          console.log('antes POST pessoaTelefoneFixo='+JSON.stringify(pessoaTelefoneFixo));
          this.pessoaService.inserirPessoaTelefone( pessoaTelefoneFixo );
        }
      }

      // Caso houve alguma alteracao nos campos do telefone celular
      if (houveAlteracaoTelefoneCelular) {
        // Caso possua Telefone celular
        if( indexTelefoneCelular > -1 ) {
          pessoaTelefoneCelular = Object.assign({}, this.solicitacaoBeneficio.pessoa.telefones[indexTelefoneCelular] );
          pessoaTelefoneCelular = Object.assign({}, this.popularDadosTelefoneCelularFromForm(pessoaTelefoneCelular));
          this.pessoaService.atualizarPessoaTelefone( pessoaTelefoneCelular );
        } else {
          pessoaTelefoneCelular = Object.assign({}, this.popularDadosTelefoneCelularFromForm(pessoaTelefoneCelular));
          pessoaTelefoneCelular.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
          pessoaTelefoneCelular.codPais =((this.isObjectNullOrUndefined(this.solicitacaoBeneficio.pessoa.pais)&&(this.solicitacaoBeneficio.pessoa.pais.codPais>0))?this.solicitacaoBeneficio.pessoa.pais.codPais:1);
          pessoaTelefoneCelular.flgAtivo = true;
          pessoaTelefoneCelular.flgCelular = true;
          console.log('antes POST pessoaTelefoneCelular='+JSON.stringify(pessoaTelefoneCelular));
          this.pessoaService.inserirPessoaTelefone( pessoaTelefoneCelular );
        }
      }
      // -------------- fim: contato-telefones ------------------

      // -------------- ini: contato-email ------------------
      let pessoaEmail : PessoaEmailModel = {};
      if( this.dadosContatoForm.get('email').dirty ) {

        if(  ( this.isObjectNullOrUndefined(this.solicitacaoBeneficio.pessoa.emails ) ) ||
             ( this.solicitacaoBeneficio.pessoa.emails.length<=0 ) ) {
          pessoaEmail.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
          pessoaEmail.desEmail =  ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('email').value ) ? '' : this.dadosContatoForm.get('email').value);
          pessoaEmail.flgAtivo = true;
          this.pessoaService.inserirPessoaEmail( pessoaEmail );
        } else {
          pessoaEmail = Object.assign({}, this.solicitacaoBeneficio.pessoa.emails[0]);
          pessoaEmail.desEmail = ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('email').value ) ? '' : this.dadosContatoForm.get('email').value);
          this.pessoaService.atualizarPessoaEmail( pessoaEmail );
        }
      }
      // -------------- fim: contato-email ------------------

      if ( (this.beneficio.procuradores != null) &&
           (this.beneficio.procuradores != undefined) &&
           (this.beneficio.procuradores.length > 0) ) {
          this.showFichaCadastralProcurador = true;
          this.atualizarStatusSolicitacaoBeneficio(26);
      } else {

          let isContaCorrenteFormaPagamento : Boolean = false;
          let respx : BeneficioPagamentoModel[];
          this.beneficioPagamentoService
          .getBeneficioPagamentoByCodigoSolicitacaoBeneficioPromise(''+this.solicitacaoBeneficio.codSolicbeneficio)
            .then(
              resposta => {
                respx = <BeneficioPagamentoModel[]> resposta.data;
            }).finally(
              ()=> {
                this.solicitacaoBeneficioPagamentoList = <BeneficioPagamentoModel[]> respx;
                if(this.solicitacaoBeneficioPagamentoList) {
                  isContaCorrenteFormaPagamento = !!this.solicitacaoBeneficioPagamentoList
                                                  .find ( fp => ( fp.principal &&
                                                                  fp.tipoMeioPagamento &&
                                                                  fp.tipoMeioPagamento.codigo === 22)
                                                  )
                }

                if ( isContaCorrenteFormaPagamento ) {
                  this.popularDadosPatrimonio();
                  this.showBlockExtrasContaCorrente.patrimonio = true;
                } else {
                  this.showFichaCadastralProcurador = false;
                  this.showCapturaCartao = true;
                  this.atualizarStatusSolicitacaoBeneficio(27);
                }
            });
      }

    }

    if(parte==="parte4.1") {

      let houveAlteracaoPatrimonio : Boolean = this.houveAlteracaoPatrimonio();
      let pessoaPatrimonioList: Array<PessoaPatrimonioModel>;
      this.alertService.setLoading(true);

      this.pessoaService
      .getPessoaPatrimonioPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
         res => {
          pessoaPatrimonioList = res as PessoaPatrimonioModel[];
        }
      )
      .catch(
        err=> {
          console.error('erro ao recarregar pessoaPatrimonioList=>'+JSON.stringify(err))
          this.alertService.setLoading(false);
          this.alertService.dispatch('Erro ao atualizar pessoaPatrimonioList=>'+err);
        }
      )
      .finally( () => {
        this.alertService.setLoading(false);
        if (houveAlteracaoPatrimonio) {
          if ( this.dadosPatrimonioForm.get('valorImoveis').dirty ) {
            this.manterPatrimonio('IMOVEIS', pessoaPatrimonioList);
            this._markFieldFromFormPristine(this.dadosPatrimonioForm, 'valorImoveis');
          }

          if ( this.dadosPatrimonioForm.get('valorAutomoveis').dirty ) {
            this.manterPatrimonio('AUTOMOVEIS', pessoaPatrimonioList);
            this._markFieldFromFormPristine(this.dadosPatrimonioForm, 'valorAutomoveis');
          }

          if ( this.dadosPatrimonioForm.get('valorInvestimentos').dirty ) {
            this.manterPatrimonio('INVESTIMENTOS', pessoaPatrimonioList);
            this._markFieldFromFormPristine(this.dadosPatrimonioForm, 'valorInvestimentos');
          }

          if ( this.dadosPatrimonioForm.get('valorOutros').dirty ) {
            this.manterPatrimonio('OUTROS', pessoaPatrimonioList);
            this._markFieldFromFormPristine(this.dadosPatrimonioForm, 'valorOutros');
          }

          this.alertService.setLoading(true);
          this.pessoaService
          .getPessoaPatrimonioPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
             res => {
              pessoaPatrimonioList = <PessoaPatrimonioModel[]>res;
            })
          .catch(
              err=> {
                console.error('erro ao recarregar pessoaPatrimonioList=>'+JSON.stringify(err))
                this.alertService.setLoading(false);
                this.alertService.dispatch('Erro ao atualizar pessoaPatrimonioList=>'+err);
              }
          ).finally( () => {
            this.alertService.setLoading(false);
            console.log("pessoaPatrimonioList recarregada apos inclusao de patrimonio=" +
            JSON.stringify(this.solicitacaoBeneficio));
            this._markFormPristine(this.dadosPatrimonioForm);
          });
        }
      });
      this.populaDadosFormularioFATCA();
    }

    if(parte==="parte4.2") {

      this.showBlockExtrasContaCorrente.FATCA = true;
      this.alertService.setLoading(true);

       this.pessoaService
       .getPessoaFATCAPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
          res => {
           this.pessoaFATCA = res as PessoaFATCAModel;
         }
       )
       .catch(
         err=> {
           console.error('erro ao recarregar pessoaFATCA=>'+JSON.stringify(err))
           this.alertService.setLoading(false);
           this.alertService.dispatch('Erro ao atualizar pessoaFATCA=>'+err);
         }
       )
       .finally( () => {
           this.alertService.setLoading(false);
           if (this.dadosFATCAForm.dirty) {
             this.manterPessoaFATCA();
             this._markFormPristine(this.dadosFATCAForm);
             this.alertService.setLoading(true);
           }
           this.alertService.setLoading(false);
         });

      this.popularDadosFormularioPEP();

    }

    if(parte==="parte4.3") {

      this.showBlockExtrasContaCorrente.PEP = true;
      this.alertService.setLoading(true);

      this.pessoaService
        .getPessoaPEPPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
          res => {
          this.pessoaPEP = res as PessoaPEPModel;
        }
      )
      .catch(
        err=> {
          console.error('erro ao recarregar pessoaPEP=>'+JSON.stringify(err))
          this.alertService.setLoading(false);
          this.alertService.dispatch('Erro ao atualizar pessoaPEP=>'+err);
        }
      )
      .finally( () => {
          this.alertService.setLoading(false);
          if (this.dadosPEPForm.dirty) {
            this.alertService.setLoading(true);
            this.manterPessoaPEP();
            this._markFormPristine(this.dadosPEPForm);
            this.alertService.setLoading(false);
          }

          if ( (this.beneficio.procuradores != null) &&
              (this.beneficio.procuradores != undefined) &&
              (this.beneficio.procuradores.length > 0) ) {
            this.showFichaCadastralProcurador = true;
            this.atualizarStatusSolicitacaoBeneficio(26);
          } else {
            this.showFichaCadastralProcurador = false;
            this.showCapturaCartao = true;
            this.atualizarStatusSolicitacaoBeneficio(27);
          }

          this.alertService.setLoading(false);
      });



    }

    if(parte==="parte5") {
    }

  }

  private popularDadosFormularioPEP() {

    this.showBlockExtrasContaCorrente.PEP = true;
    this.alertService.setLoading(true);

    this.pessoaService
      .getPessoaPEPPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
       res => {
        this.pessoaPEP = res as PessoaPEPModel;
      }
    )
    .catch(
      err=> {
        console.error('erro ao recarregar pessoaPEP=>'+JSON.stringify(err))
        this.alertService.setLoading(false);
        this.alertService.dispatch('Erro ao atualizar pessoaPEP=>'+err);
      }
    )
    .finally( () => {
        this.possuiPEP = ( this.pessoaPEP.codPessoaPEP ? true : false );
        if (this.possuiPEP) {
          this.showFichaPEP = true;
        } else {
          this.showFichaPEP = false;
        }

        this.alertService.setLoading(false);
        console.log("pessoaPEP recarregada" + JSON.stringify(this.solicitacaoBeneficio));
        this._markFormPristine(this.dadosPEPForm);

        if (this.dadosPEPForm.dirty) {
          this.manterPessoaPEP();
          this._markFormPristine(this.dadosPEPForm);
          this.alertService.setLoading(true);
        }

        this.dadosPEPForm.setValue({
          possuirCargoPublico: (this.pessoaPEP.funcao?true:false),
          funcao: (this.pessoaPEP.funcao ? this.pessoaPEP.funcao : '' ),
          dtaInicio: (this.pessoaPEP.dtaInicio ? this.pessoaPEP.dtaInicio : '' ),
          dtaFim:  (this.pessoaPEP.dtaFim ? this.pessoaPEP.dtaFim : '' ),
          empresa: (this.pessoaPEP.empresa ? this.pessoaPEP.empresa : '' ),
          relacaoAgentePubli: (this.pessoaPEP.relacaoAgentePubli ? this.pessoaPEP.relacaoAgentePubli : false ),
          nomeRelacionado: '',
          cpfRelalionado:  '',
          funcaoRelacionado:  '',
          tipoRelacionamento:  '',
        });

        this.alertService.setLoading(false);
      });
  }

  private populaDadosFormularioFATCA() {

     this.showBlockExtrasContaCorrente.FATCA = true;
     this.alertService.setLoading(true);

      this.pessoaService
      .getPessoaFATCAPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
         res => {
          this.pessoaFATCA = res as PessoaFATCAModel;
        }
      )
      .catch(
        err=> {
          console.error('erro ao recarregar pessoaFATCA=>'+JSON.stringify(err))
          this.alertService.setLoading(false);
          this.alertService.dispatch('Erro ao atualizar pessoaFATCA=>'+err);
        }
      )
      .finally( () => {

          this.possuiDomicilioFiscalExterior = ( this.pessoaFATCA.codPessoafatca  ? true : false );
          if (this.possuiDomicilioFiscalExterior) {
            this.showFichaDomicilioFiscalExterior = true;
          } else {
            this.showFichaDomicilioFiscalExterior = false;
          }

          this.alertService.setLoading(false);
          console.log("pessoaFATCA recarregada" + JSON.stringify(this.solicitacaoBeneficio));
          this._markFormPristine(this.dadosFATCAForm);

          if (this.dadosFATCAForm.dirty) {
            this.manterPessoaFATCA();
            this._markFormPristine(this.dadosFATCAForm);
            this.alertService.setLoading(true);
          }

          this.dadosFATCAForm.setValue({
            nomeCompletoFATCA: '',
            cpfFATCA: '',
            localNascimentoFATCA: '',
            enderecoResidencialFATCA: '',
            numeroEnderecoResidencialFATCA: '',
            complementoEnderecoResidencialFATCA: '',
            bairroEnderecoResidencialFATCA: '',

            flgEstudante: (this.pessoaFATCA.estudante ? this.pessoaFATCA.estudante : false),
            flgDiplomata: (this.pessoaFATCA.diplomata ? this.pessoaFATCA.diplomata : false),
            flgPresencaSubstancial: (this.pessoaFATCA.presencaSubstancial ? this.pessoaFATCA.presencaSubstancial : false),
            flgAbdicouNacionalidade: (this.pessoaFATCA.abdicouNacionalidade ? this.pessoaFATCA.abdicouNacionalidade : false),
            flgRenunciou: (this.pessoaFATCA.renunciou ? this.pessoaFATCA.renunciou : false),
            flgPossuiGreencard: (this.pessoaFATCA.possuiGreencard ? this.pessoaFATCA.possuiGreencard : false),
            flgCertificAbandono: (this.pessoaFATCA.certificAbandono ? this.pessoaFATCA.certificAbandono : false),
            flgResideNosEua: (this.pessoaFATCA.resideNosEua ? this.pessoaFATCA.resideNosEua : false ),

            diasVisitaAnoCorrente: (this.pessoaFATCA.diasVisitaAnoCorrente ? this.pessoaFATCA.diasVisitaAnoCorrente : 0),
            diasVisitaAnoPassado: (this.pessoaFATCA.diasVisitaAnoPassado ? this.pessoaFATCA.diasVisitaAnoPassado : 0),
            diasVisitaAnoAnterior: (this.pessoaFATCA.diasVisitaAnoAnterior ? this.pessoaFATCA.diasVisitaAnoAnterior : 0),
          });

          this.alertService.setLoading(false);

        });

  }

  private _markFieldFromFormPristine(form: FormGroup, nomeCampo: string ): void {
    Object.keys(form.controls).forEach(control => {
        if (control==nomeCampo) {
          form.controls[control].markAsPristine();
        }
    });
  }

  private _markFormPristine(form: FormGroup): void {
    Object.keys(form.controls).forEach(control => {
        form.controls[control].markAsPristine();
    });
  }

  compareProfissao(item1: any, item2: any): boolean {
    return (
      item1.codTipoprofissao === item2.codTipoprofissao &&
      item1.desTipoprofissao === item2.desTipoprofissao
    );
  }

  compareEstadoCivil(item1: any, item2: any): boolean {
    // console.log('item1.codTipoestadocivil['+item1.codTipoestadocivil+'] item2.codTipoestadocivil['+item2.codTipoestadocivil+']' );
    return (
      item1.codTipoestadocivil === item2.codTipoestadocivil &&
      item1.desTipoestadocivil === item2.desTipoestadocivil
    );
  }

  compareUF(item1: any, item2: any): boolean {
    // console.log('item1.uf['+item1.uf+'] item2['+item2+']' );
    return (
      item1.uf === item2
    );
  }
  compareUFEmissaoDocumento(item1: any, item2: any): boolean {
    return (
      item1.slgUf === item2
    );
  }

  compareCidade(item1: any, item2: any): boolean {
    // console.log('item1.codCidade['+item1.desCidade+'] item2['+item2+']' );
    return (
      item1.desCidade == item2
    );
  }

  compareTipoResidencia(item1: any, item2: any): boolean {
    // console.log('item1.codCidade['+item1.desTiporesidencia+'] item2['+item2+']' );
    return (
      item1.desTiporesidencia == item2
    );
  }

  compareDocumentoIdentificacao(item1: any, item2: any): boolean {
    //TODO: alterar
    // return (
    //   item1.descricao == item2
    // );
    return true;
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
      horizontalPosition: "right",
      verticalPosition: "top"
    });
  }

  /* FUNCOES PRA DEIXAR OS CAMPOS APENAS PARA LEITURA */
  readonlyDocPart1() {
    this.isReadonlyDocumentoPart1 = !this.isReadonlyDocumentoPart1;
  }

  readonlyDocPart2() {
    this.isReadonlyDocumentoPart2 = !this.isReadonlyDocumentoPart2;
  }

  readonlyEndereco() {
    this.isReadonlyEndereco = !this.isReadonlyEndereco;
  }

  readonlyContato() {
    this.isReadonlyContato = !this.isReadonlyContato;
  }

  readonlyCapturaCartao(){
    this.isReadonlyCapturaCartao = !this.isReadonlyCapturaCartao;
  }

  readonlyPatrimonio() {
    this.isReadonlyPatrimonio = !this.isReadonlyPatrimonio;
  }

  readonlyPEP() {
    this.isReadonlyPEP = !this.isReadonlyPEP;
  }

  readonlyFATCA() {
    this.isReadonlyFATCA = !this.isReadonlyFATCA;
  }

  alteraText(nomeBotao : string){
    if(nomeBotao === 'documentoPart1'){
      if(this.botaoAlterarSalvar == 'Alterar'){
        this.botaoAlterarSalvar = 'Salvar';
      } else{
          if(this.botaoAlterarSalvar == 'Salvar'){
            this.botaoAlterarSalvar = 'Alterar';
            this.prosseguir('parte1');
            this.openSnackBar('Salvo Com Sucesso', 'X');
          }
      }
    }

    if(nomeBotao === 'documentoPart2'){
      if(this.botaoAlterarSalvar2 == 'Alterar'){
        this.botaoAlterarSalvar2 = 'Salvar';
      } else{
          if(this.botaoAlterarSalvar2 == 'Salvar'){
            this.botaoAlterarSalvar2 = 'Alterar';
            this.prosseguir('parte2');
            this.openSnackBar('Salvo Com Sucesso', 'X');
          }
      }
    }

    if(nomeBotao === 'endereco'){
      if(this.botaoAlterarSalvarEndereco == 'Alterar'){
        this.botaoAlterarSalvarEndereco = 'Salvar';
      } else{
          if(this.botaoAlterarSalvarEndereco == 'Salvar'){
            this.botaoAlterarSalvarEndereco = 'Alterar';
            this.prosseguir('parte3');
            this.openSnackBar('Salvo Com Sucesso', 'X');
          }
      }
    }

    if(nomeBotao === 'contato'){
      if(this.botaoAlterarSalvarContato == 'Alterar'){
        this.botaoAlterarSalvarContato = 'Salvar';
      } else{
          if(this.botaoAlterarSalvarContato == 'Salvar'){
            this.botaoAlterarSalvarContato = 'Alterar';
            this.prosseguir('parte4');
            this.openSnackBar('Salvo Com Sucesso', 'X');
          }
      }
    }

    if(nomeBotao === 'patrimonio'){
      if(this.botaoAlterarSalvarPatrimonio == 'Alterar'){
        this.botaoAlterarSalvarPatrimonio = 'Salvar';
      } else{
          if(this.botaoAlterarSalvarPatrimonio == 'Salvar'){
            this.botaoAlterarSalvarPatrimonio = 'Alterar';
            this.prosseguir('parte4.1');
            this.openSnackBar('Salvo Com Sucesso', 'X');
          }
      }
    }

    if(nomeBotao === 'fatca'){
      if(this.botaoAlterarSalvarFATCA == 'Alterar'){
        this.botaoAlterarSalvarFATCA = 'Salvar';
      } else{
          if(this.botaoAlterarSalvarFATCA == 'Salvar'){
            this.botaoAlterarSalvarFATCA = 'Alterar';
            this.prosseguir('parte4.2');
            this.openSnackBar('Salvo Com Sucesso', 'X');
          }
      }
    }

    if(nomeBotao === 'pep'){
      if(this.botaoAlterarSalvarPEP == 'Alterar'){
        this.botaoAlterarSalvarPEP = 'Salvar';
      } else{
          if(this.botaoAlterarSalvarPEP == 'Salvar'){
            this.botaoAlterarSalvarPEP = 'Alterar';
            this.prosseguir('parte4.2');
            this.openSnackBar('Salvo Com Sucesso', 'X');
          }
      }
    }

  }



  /* FUNCOES PRA ADICIONAR FUNDO CINZA */
  get myStyles(): any {
    return {
        'background-color' : this.backGroundCinzaParte1 ? 'whitesmoke' : '#fff',
    };
  }

  get myStyles2(): any {
    return {
        'background-color' : this.backGroundCinzaParte2 ? 'whitesmoke' : '#fff',
    };
  }

  get myStyles3(): any {
    return {
        'background-color' : this.backGroundCinzaEndereco ? 'whitesmoke' : '#fff',
    };
  }

  get myStyles4(): any {
    return {
        'background-color' : this.backGroundCinzaContato ? 'whitesmoke' : '#fff',
    };
  }

  get myStyles5(): any {
    return{
      'background-color' : this.backGroundCinzaCapturaCartao ? 'whitesmoke' : '#fff',
    }
  }

  private obterRelativo( codigoTipoRelacao : number, relativos: Array<PessoaRelativoModel> ) : PessoaRelativoModel {
    let retorno: PessoaRelativoModel = {};
    let encontrou: boolean = false;
    if(relativos === undefined || relativos.length === 0) {
      return null;
    }
    for(var i=0; i<relativos.length; i++) {
      if(relativos[i].tpoRelacao.codTiporelacao===codigoTipoRelacao) {
        retorno = Object.assign({}, relativos[i]);
        encontrou = true;
        break;
      }
    }
    return (encontrou ? retorno : null);
  }

  /* ESCONDE BOTAO PROSSEGUIR*/

  hideBotaoProseguirDocPart1(){
    this.escondeBotaoProsseguirDocPart1 = true;
  }

  hideBotaoProseguirDocPart2(){
    this.escondeBotaoProsseguirDocPart2 = true;
  }

  hideBotaoProseguirEndereco(){
    this.escondeBotaoProsseguirEndereco = true;
  }

  hideBotaoProseguirContato(){
    this.escondeBotaoProsseguirContato = true;
  }

  hideBotaoProseguirPatrimonio(){
    this.escondeBotaoProsseguirPatrimonio = true;
  }

  hideBotaoProseguirFATCA(){
    this.escondeBotaoProsseguirFATCA = true;
  }

  hideBotaoProseguirPEP(){
    this.escondeBotaoProsseguirPEP = true;
  }

  /* APARECE BOTAO ALTERAR */

  showBotaoApareceAlteraDocPart1(){
    this.apareceBotaoAlteraDocPart1 = true;
  }

  showBotaoApareceAlteraDocPart2(){
    this.apareceBotaoAlteraDocPart2 = true;
  }

  showBotaoApareceAlteraEndereco(){
    this.apareceBotaoAlteraEndereco = true;
  }

  showBotaoApareceAlteraContato(){
    this.apareceBotaoAlteraContato = true;
  }

  showBotaoApareceAlterarPatrimonio(){
    this.apareceBotaoAlteraPatrimonio = true;
  }

  showBotaoApareceAlterarFATCA(){
    this.apareceBotaoAlteraFATCA = true;
  }

  showBotaoApareceAlterarPEP(){
    this.apareceBotaoAlteraPEP = true;
  }

  // ::: botão de captura do cartão  cpf:17757432847 nb:1499177893 | cpf:53836043327 nb:700.322.674-0
  public capturarCartao(solicitacaoBeneficioPagamento:BeneficioPagamentoModel):void {
    this.backGroundCinzaCapturaCartao = true;
    this.alertService.setLoading(true);
    let dadosCapturaCartao:CapturaCartaoModel = {};
    dadosCapturaCartao.solicitacaoPagamento = Object.assign({}, solicitacaoBeneficioPagamento);
    dadosCapturaCartao.pessoa = Object.assign({}, this.solicitacaoBeneficio.pessoa);
    dadosCapturaCartao.usuario = '';

    this.beneficioSolicitacaoService.inserirSolicitacaoBeneficioCapturaCartao(dadosCapturaCartao).subscribe(
        r => {
            //if (isDevMode()) r.data.idContaCartao = "1"; // ::: RETIRAR! é apenas para testes
            if (r.data.idContaCartao != null && r.data.idContaCartao != undefined && r.data.idContaCartao != "") {
                dadosCapturaCartao.solicitacaoPagamento.numIdcontacartao = r.data.idContaCartao;
                this.mapCartoesCapturados.set("" + dadosCapturaCartao.solicitacaoPagamento.tipoMeioPagamento.codigo, dadosCapturaCartao);
                solicitacaoBeneficioPagamento.numIdcontacartao = r.data.idContaCartao;
                this.solicBenfPgto_escolhida = solicitacaoBeneficioPagamento;
                this.showProsseguirCapturaCartao = true;
            }
            else if (r.data.urlCallBack != undefined && r.data.urlCallBack != null && r.data.urlCallBack != "") {
                window.open(r.data.urlCallBack);
            }
            else {
                console.log("A API NÃO RETORNOU O ID DO CARTÃO E NEM URL. InssApi, controller SolicBeneficio, método CapturarCartao");
                console.log("OBJETO solicitacaoBeneficioPagamento: \n" + JSON.stringify(solicitacaoBeneficioPagamento));
                console.log("OBJETO retorno da chamada: \n" + JSON.stringify(r));
            }
            this.backGroundCinzaCapturaCartao = false;
            this.alertService.setLoading(false);
        },
        e => {
            console.log("OCORREU UM ERRO AO CHAMAR InssApi, controller SolicBeneficio, método CapturarCartao");
            console.log("OBJETO solicitacaoBeneficioPagamento: \n" + JSON.stringify(solicitacaoBeneficioPagamento));
            console.log("OBJETO retorno da chamada: \n" + JSON.stringify(e));
            this.backGroundCinzaCapturaCartao = false;
            this.alertService.setLoading(false);
        }
    );
  }

    public async prosseguirParaDocumentos() { // ::: cpf:17757432847 nb:1499177893 | cpf:53836043327 nb:7003226740
        this.alertService.setLoading(true);

        var retornoPositivo:boolean = false;
        await this.beneficioSolicitacaoService.solicBeneficioPgtoAlterar(this.solicBenfPgto_escolhida).toPromise().then(r => {
            retornoPositivo = true;
        }).catch(e => {
            retornoPositivo = false;
        });
        /*if (retornoPositivo) {
            console.clear();
            console.log(JSON.stringify(this.solicitacaoBeneficio));
            await this.beneficioSolicitacaoService.solicBeneficioInserirDocs(this.solicitacaoBeneficio).toPromise().then(r => {
                retornoPositivo = (r.data != undefined && r.data != null && r.data == true);
            }).catch(e => {
                retornoPositivo = false;
            });
        }*/
        if (!retornoPositivo) {
            this.alertService.setLoading(false);
            this.openSnackBar('Erro ao atualizar os dados. Não é possível prosseguir.', 'X');
            return;
        }

        this.beneficioSolicitacaoService.getSolicitacaoBeneficioDocumento("" + this.solicitacaoBeneficio.codSolicbeneficio).subscribe(
            (data:any) => {
                this.solicitacaoBeneficioDocumentoResponse = <SolicitacaoBeneficioDocumentoResponse>data;
                this.solicitacaoBeneficioDocumentoList = <SolicitacaoBeneficioDocumentoModel[]>this.solicitacaoBeneficioDocumentoResponse.data;
                console.log("prosseguirParaDocumentos.solicitacaoBeneficioDocumentoList=" + JSON.stringify(this.solicitacaoBeneficioDocumentoList));
                for(var x:number = 0; x < this.solicitacaoBeneficioDocumentoList.length; x++) {
                    console.log("item[" + x + "]" + JSON.stringify( this.solicitacaoBeneficioDocumentoList[x] )) ;
                    for(var y:number = 0; y < this.solicitacaoBeneficioDocumentoList[x].documento.configuracao.length; y++) {
                        console.log("configuracao[" + y + "]=" + JSON.stringify(this.solicitacaoBeneficioDocumentoList[x].documento.configuracao[y]));
                    }
                    console.log("-------------------------------------------------------\n=================================================================");
                }
                // this.dadosCapturaDoc.setValue({
                //   // tituloDocumento: this.solicitacaoBeneficioDocumentoResponse.data[0].documento.descricao,
                //   tituloDocumento: this.solicitacaoBeneficioDocumentoList[0].documento.descricao,
                //   statusDocumento: this.solicitacaoBeneficioDocumentoList[0].status.descricao,
                //   botaoAcaoDocumento: this.solicitacaoBeneficioDocumentoList[0].documento.configuracao[0].itemConfiguracao.descricao,
                // });
                console.log("CAPTURA-DOCUMENTO" + this.solicitacaoBeneficioDocumentoList[0].documento.descricao)
                this.atualizarStatusSolicitacaoBeneficio(28);
            },
            e => {
                console.log("+++++++ error prosseguirParaDocumentos ++++++++++ " + e);
                this.alertService.setLoading(false);
            },
            () => {
                console.log("+++++++ completed prosseguirParaDocumentos++++++++++");
                this.alertService.setLoading(false);
            },
        )
        this.showDocumentos = true;
    }

  findIndexPessoaEnderecoResidencial( solicitacao: SolicitacaoBeneficioDataModel): number {
    let i : number = -1;
    if ( ( solicitacao.pessoa.enderecos != null) &&
         ( solicitacao.pessoa.enderecos != undefined ) ) {
      for (i = 0; i < solicitacao.pessoa.enderecos.length; i++) {
        if (solicitacao.pessoa.enderecos[i].flgResidencial === true) {
          break;
        }
      }
    }
    return i;
  }

  findIndexPessoaDocumentoRG( solicitacao: SolicitacaoBeneficioDataModel ): number {
    let item : number = -1;
    if ( ( solicitacao.pessoa.documentos != null) &&
         ( solicitacao.pessoa.documentos != undefined ) ) {
      for (var i = 0; i < solicitacao.pessoa.documentos.length; i++) {
        if( (solicitacao.pessoa.documentos[i].tpoDocumento != null) &&
            (solicitacao.pessoa.documentos[i].tpoDocumento != undefined)) {
          if (solicitacao.pessoa.documentos[i].tpoDocumento.descricao === 'RG') {
            item = i;
            break;
          }
        }
      }
    }
    return item;
  }

  findIndexPessoaDocumentoNaoRG( solicitacao: SolicitacaoBeneficioDataModel ): number {
    let item : number = -1;
    if ( ( solicitacao.pessoa.documentos != null) &&
         ( solicitacao.pessoa.documentos != undefined ) ) {
      for (var i = 0; i < solicitacao.pessoa.documentos.length; i++) {
        if( (solicitacao.pessoa.documentos[i].tpoDocumento != null) &&
            (solicitacao.pessoa.documentos[i].tpoDocumento != undefined)) {
          if (solicitacao.pessoa.documentos[i].tpoDocumento.descricao != 'RG') {
            item = i;
            break;
          }
        }
      }
    }
    return item;
  }

  findIndexPessoaTelefoneFixo( solicitacao: SolicitacaoBeneficioDataModel ): number {
    let item : number = -1;
    if ( ( solicitacao.pessoa.telefones != null) &&
         ( solicitacao.pessoa.telefones != undefined ) ) {
      for (var i = 0; i < solicitacao.pessoa.telefones.length; i++) {
        if (solicitacao.pessoa.telefones[i].flgCelular != true) {
          item = i;
          break;
        }
      }
    }
    return item;
  }

  findIndexPessoaTelefoneCelular( solicitacao: SolicitacaoBeneficioDataModel ): number {
    let item : number = -1;
    if ( ( solicitacao.pessoa.telefones != null) &&
         ( solicitacao.pessoa.telefones != undefined ) ) {
      for (var i = 0; i < solicitacao.pessoa.telefones.length; i++) {
        if (solicitacao.pessoa.telefones[i].flgCelular === true) {
          item = i;
          break;
        }
      }
    }
    return item;
  }

  popularDadosEnderecoFromForm(pessoaEndereco: PessoaEnderecoModel) : PessoaEnderecoModel {

      if( this.dadosEnderecoForm.get('cepResidencial').dirty ) {
        pessoaEndereco.numCep =  ( this.isObjectNullOrUndefined( this.dadosEnderecoForm.get('cepResidencial').value ) ? '' : this.dadosEnderecoForm.get('cepResidencial').value);
      }

      if( this.dadosEnderecoForm.get('logradouroResidencial').dirty ) {
        pessoaEndereco.desLogradouro = ( this.isObjectNullOrUndefined( this.dadosEnderecoForm.get('logradouroResidencial').value ) ? '' : this.dadosEnderecoForm.get('logradouroResidencial').value);
        pessoaEndereco.desLogradouro = pessoaEndereco.desLogradouro.toUpperCase();
      }

      if( this.dadosEnderecoForm.get('numeroLogradouroResidencial').dirty ) {
        pessoaEndereco.numEndereco  = ( this.isObjectNullOrUndefined( this.dadosEnderecoForm.get('numeroLogradouroResidencial').value ) ? '' : this.dadosEnderecoForm.get('numeroLogradouroResidencial').value);
      }

      if( this.dadosEnderecoForm.get('complementoLogradouroResidencial').dirty ) {
        pessoaEndereco.desComplemento = ( this.isObjectNullOrUndefined( this.dadosEnderecoForm.get('complementoLogradouroResidencial').value ) ? '' : this.dadosEnderecoForm.get('complementoLogradouroResidencial').value);
        pessoaEndereco.desComplemento = pessoaEndereco.desComplemento.toUpperCase();
      }

      if( this.dadosEnderecoForm.get('bairroResidencial').dirty ) {
        pessoaEndereco.desBairro = ( this.isObjectNullOrUndefined( this.dadosEnderecoForm.get('bairroResidencial').value ) ? '' : this.dadosEnderecoForm.get('bairroResidencial').value);
        pessoaEndereco.desBairro = pessoaEndereco.desBairro.toUpperCase();
      }

      if( this.dadosEnderecoForm.get('cidadeResidencial').dirty ) {
        let cidade : Cidade = <Cidade>this.dadosEnderecoForm.get('cidadeResidencial').value;
        pessoaEndereco.desCidade = cidade.desCidade;
        pessoaEndereco.desCidade = pessoaEndereco.desCidade.toUpperCase();
      }

      if( this.dadosEnderecoForm.get('ufResidencial').dirty ) {
        let uf : UF = <UF>this.dadosEnderecoForm.get('ufResidencial').value;
        pessoaEndereco.slgUf = uf.uf;
      }

      if( this.dadosEnderecoForm.get('tipoResidenciaResidencial').dirty ) {
        let tipoResidencia: TipoResidenciaModel = <TipoResidenciaModel>this.dadosEnderecoForm.get('tipoResidenciaResidencial').value;
        pessoaEndereco.tpoResidencia = Object.assign({},tipoResidencia);
      }

      return pessoaEndereco;
  }

  popularDadosDocumentoRGFromForm(pessoaDocumentoRG: PessoaDocumentoModel) : PessoaDocumentoModel {

    if( this.dadosaPessoaisParte2Form.get('numeroRG').dirty ) {
      pessoaDocumentoRG.numDocumento = ( this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('numeroRG').value ) ? '' : this.dadosaPessoaisParte2Form.get('numeroRG').value);
    }

    if( this.dadosaPessoaisParte2Form.get('digitoRG').dirty ) {
      pessoaDocumentoRG.digDocumento = ( this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('digitoRG').value ) ? '' : this.dadosaPessoaisParte2Form.get('digitoRG').value);
    }

    if( this.dadosaPessoaisParte2Form.get('orgaoEmissorRG').dirty ) {
      pessoaDocumentoRG.slgOrgemissor = ( this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('orgaoEmissorRG').value ) ? '' : this.dadosaPessoaisParte2Form.get('orgaoEmissorRG').value);
      pessoaDocumentoRG.slgOrgemissor = pessoaDocumentoRG.slgOrgemissor.toUpperCase();
    }

    if( this.dadosaPessoaisParte2Form.get('dataEmissaoRG').dirty ) {
      pessoaDocumentoRG.dtaEmissao = ( this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('dataEmissaoRG').value ) ? '' : this.dadosaPessoaisParte2Form.get('dataEmissaoRG').value);
    }

    return pessoaDocumentoRG;
  }

  popularDadosDocumentoNaoRGFromForm(pessoaDocumentoNaoRG: PessoaDocumentoModel) : PessoaDocumentoModel {
      let documentoIdentificacao : DocumentoModel = <DocumentoModel>this.dadosaPessoaisParte2Form.get('documentoIdentificacao').value;
      let tipoDoc : TipoDocumentoModel = {};
      console.log('documentoIdentificacaoXXX='+documentoIdentificacao.descricao);
      if(this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('documentoIdentificacao').value )) {
        tipoDoc.ativo = true;
        tipoDoc.codigo = 0;
        tipoDoc.descricao = '';
      } else {
        tipoDoc.ativo = true;
        tipoDoc.codigo = documentoIdentificacao.codigo;
        tipoDoc.descricao = documentoIdentificacao.descricao;
        console.log('*** 02 tipoDoc=' + JSON.stringify(tipoDoc));
      }
      pessoaDocumentoNaoRG.tpoDocumento = Object.assign({}, tipoDoc);

    if( this.dadosaPessoaisParte2Form.get('numDocumento').dirty ) {
      pessoaDocumentoNaoRG.numDocumento = ( this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('numDocumento').value ) ? '' : this.dadosaPessoaisParte2Form.get('numDocumento').value);
    }

    if( this.dadosaPessoaisParte2Form.get('orgaoEmissorDocumento').dirty ) {
      pessoaDocumentoNaoRG.slgOrgemissor = ( this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('orgaoEmissorDocumento').value ) ? '' : this.dadosaPessoaisParte2Form.get('orgaoEmissorDocumento').value);
      pessoaDocumentoNaoRG.slgOrgemissor = pessoaDocumentoNaoRG.slgOrgemissor.toUpperCase();
    }

    if( this.dadosaPessoaisParte2Form.get('ufEmissaoDocumento').dirty ) {
      let uf : UF = <UF>this.dadosaPessoaisParte2Form.get('ufEmissaoDocumento').value;
      pessoaDocumentoNaoRG.slgUf = uf.uf;
    }

    if( this.dadosaPessoaisParte2Form.get('dataEmissaoDocumento').dirty ) {
      pessoaDocumentoNaoRG.dtaEmissao = ( this.isObjectNullOrUndefined( this.dadosaPessoaisParte2Form.get('dataEmissaoDocumento').value ) ? '' : this.dadosaPessoaisParte2Form.get('dataEmissaoDocumento').value);
    }

    return pessoaDocumentoNaoRG;
  }

  popularDadosTelefoneFixoFromForm(pessoaTelefone: PessoaTelefoneModel) : PessoaTelefoneModel {
    if( this.dadosContatoForm.get('dddTelefoneFixo').dirty ) {
      pessoaTelefone.numDdd = ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('dddTelefoneFixo').value ) ? '' : this.dadosContatoForm.get('dddTelefoneFixo').value);
    }

    if( this.dadosContatoForm.get('telefoneFixo').dirty ) {
      pessoaTelefone.numTelefone = ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('telefoneFixo').value ) ? '' : this.dadosContatoForm.get('telefoneFixo').value);
    }

    if( this.dadosContatoForm.get('telefoneFixoProprio').dirty ) {
      pessoaTelefone.flgPessoal = ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('telefoneFixoProprio').value ) ? false : this.dadosContatoForm.get('telefoneFixoProprio').value);
    }
    return pessoaTelefone;
  }

  popularDadosTelefoneCelularFromForm(pessoaTelefone: PessoaTelefoneModel) : PessoaTelefoneModel {

    if( this.dadosContatoForm.get('dddTelefoneCelular').dirty ) {
      pessoaTelefone.numDdd = ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('dddTelefoneCelular').value ) ? '' : this.dadosContatoForm.get('dddTelefoneCelular').value);
    }

    if( this.dadosContatoForm.get('telefoneCelular').dirty ) {
      pessoaTelefone.numTelefone = ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('telefoneCelular').value ) ? '' : this.dadosContatoForm.get('telefoneCelular').value);
    }

    if( this.dadosContatoForm.get('telefoneCelularProprio').dirty ) {
      pessoaTelefone.flgPessoal = ( this.isObjectNullOrUndefined( this.dadosContatoForm.get('telefoneCelularProprio').value ) ? false : this.dadosContatoForm.get('telefoneCelularProprio').value);
    }

    return pessoaTelefone;
  }


   //FUNCAO PARA CARREGAR O NGX-LOADING
   componenteLoading() {
    this.alertService.setLoading(true);
    setTimeout(() => {
      this.alertService.setLoading(false);
    }, 15000);
  }

  onChange(){
    console.log("SWITCH DEU CERTO");
  }

  houveAlteracaoDocumentoPessoaParteRG() : Boolean {
    let houveAlteracao: Boolean = false;
    if( ( this.dadosaPessoaisParte2Form.get('numeroRG').dirty ) ||
        ( this.dadosaPessoaisParte2Form.get('digitoRG').dirty ) ||
        ( this.dadosaPessoaisParte2Form.get('orgaoEmissorRG').dirty ) ||
        ( this.dadosaPessoaisParte2Form.get('dataEmissaoRG').dirty ) ) {
      houveAlteracao = true;
    }
    return houveAlteracao;
  }

  houveAlteracaoDocumentoPessoaParteNaoRG() : Boolean {
    let houveAlteracao: Boolean = false;
    if( ( this.dadosaPessoaisParte2Form.get('documentoIdentificacao').dirty ) ||
        ( this.dadosaPessoaisParte2Form.get('numDocumento').dirty ) ||
        ( this.dadosaPessoaisParte2Form.get('orgaoEmissorDocumento').dirty ) ||
        ( this.dadosaPessoaisParte2Form.get('ufEmissaoDocumento').dirty ) ||
        ( this.dadosaPessoaisParte2Form.get('dataEmissaoDocumento').dirty ) ) {
      houveAlteracao = true;
    }
    return houveAlteracao;
  }

  houveAlteracaoParteTelefoneFixo() : Boolean {
    let houveAlteracao: Boolean = false;
    if( ( this.dadosContatoForm.get('dddTelefoneFixo').dirty ) ||
        ( this.dadosContatoForm.get('telefoneFixo').dirty ) ||
        ( this.dadosContatoForm.get('telefoneFixoProprio').dirty ) ) {
      houveAlteracao = true;
    }
    return houveAlteracao;
  }

  houveAlteracaoParteTelefoneCelular() : Boolean {
    let houveAlteracao: Boolean = false;
    if( ( this.dadosContatoForm.get('dddTelefoneCelular').dirty ) ||
        ( this.dadosContatoForm.get('telefoneCelular').dirty ) ||
        ( this.dadosContatoForm.get('telefoneCelularProprio').dirty ) ) {
      houveAlteracao = true;
    }
    return houveAlteracao;
  }

  houveAlteracaoEndereco() : Boolean {
    let houveAlteracao: Boolean = false;
    if(
        ( this.dadosEnderecoForm.get('cepResidencial').dirty ) ||
        ( this.dadosEnderecoForm.get('logradouroResidencial').dirty )  ||
        ( this.dadosEnderecoForm.get('numeroLogradouroResidencial').dirty )  ||
        ( this.dadosEnderecoForm.get('complementoLogradouroResidencial').dirty )  ||
        ( this.dadosEnderecoForm.get('bairroResidencial').dirty )  ||
        ( this.dadosEnderecoForm.get('cidadeResidencial').dirty ) ||
        ( this.dadosEnderecoForm.get('ufResidencial').dirty ) ||
        ( this.dadosEnderecoForm.get('tipoResidenciaResidencial').dirty )
    ) {
      houveAlteracao = true;
    }
    return houveAlteracao;
  }

  houveAlteracaoPatrimonio() : Boolean {
    let houveAlteracao: Boolean = false;
    if( ( this.dadosPatrimonioForm.get('valorImoveis').dirty ) ||
        ( this.dadosPatrimonioForm.get('valorAutomoveis').dirty ) ||
        ( this.dadosPatrimonioForm.get('valorInvestimentos').dirty ) ||
        ( this.dadosPatrimonioForm.get('valorOutros').dirty ) ) {
      houveAlteracao = true;
    }
    return houveAlteracao;
  }

  public trocarPossuiBensAndImoveis(){

    let pessoaPatrimonioList: Array<PessoaPatrimonioModel>;
    this.showFichaCadastroPatrimonio = !this.showFichaCadastroPatrimonio;
    this.possuiBensAndImoveis = !this.possuiBensAndImoveis;

    this.alertService.setLoading(true);
    this.pessoaService
    .getPessoaPatrimonioPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
        res => {
        pessoaPatrimonioList = <PessoaPatrimonioModel[]>res;
      })
    .catch(
        err=> {
          console.error('erro ao recarregar pessoaPatrimonioList=>'+JSON.stringify(err))
          this.alertService.setLoading(false);
          this.alertService.dispatch('Erro ao atualizar pessoaPatrimonioList=>'+err);
        }
    ).finally( () => {

      // Se alterado para nao remove todos os patrimonios caso exista.
      if(!this.possuiBensAndImoveis) {
        if ((pessoaPatrimonioList) && (pessoaPatrimonioList.length>0)) {
          pessoaPatrimonioList.forEach(
            item => {
              this.pessoaService.excluirPessoaPatrimonio(item.codPessoaPatrimonio);
            }
          )
          this.dadosPatrimonioForm.setValue({
            valorImoveis: '',
            valorAutomoveis: '',
            valorInvestimentos: '',
            valorOutros: '',
          });
        }
      }

      this.alertService.setLoading(false);
      this._markFormPristine(this.dadosPatrimonioForm);
    });

  }

  public trocarPossuiDomicilioFiscalExterior() {
    this.possuiDomicilioFiscalExterior = !this.possuiDomicilioFiscalExterior;
    this.showFichaDomicilioFiscalExterior = !this.showFichaDomicilioFiscalExterior;
    this.alertService.setLoading(true);

    this.pessoaService
    .getPessoaFATCAPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
        res => {
        this.pessoaFATCA = res as PessoaFATCAModel;
      }
    )
    .catch(
      err=> {
        console.error('erro ao recarregar pessoaFATCA=>'+JSON.stringify(err));
        this.alertService.setLoading(false);
        this.alertService.dispatch('Erro ao atualizar pessoaFATCA=>'+err);
      }
    )
    .finally( () => {

        // Se alterado para 'Não' remove os dados de FATCA caso exista.
        if( (!this.possuiDomicilioFiscalExterior) ) {

          if ( this.pessoaFATCA && this.pessoaFATCA.codPessoafatca ) {
            this.pessoaService.excluirPessoaFATCA(this.pessoaFATCA.codPessoafatca);

            this.dadosFATCAForm.setValue({
              nomeCompletoFATCA: '',
              cpfFATCA: '',
              localNascimentoFATCA: '',
              enderecoResidencialFATCA: '',
              numeroEnderecoResidencialFATCA: '',
              complementoEnderecoResidencialFATCA: '',
              bairroEnderecoResidencialFATCA: '',

              flgEstudante: false,
              flgDiplomata: false,
              flgPresencaSubstancial: false,
              flgAbdicouNacionalidade: false,
              flgRenunciou: false,
              flgPossuiGreencard: false,
              flgCertificAbandono: false,
              flgResideNosEua: false,

              diasVisitaAnoCorrente: 0,
              diasVisitaAnoPassado:  0,
              diasVisitaAnoAnterior: 0,
            });
          }
        }

        if (this.possuiDomicilioFiscalExterior) {
          this.showFichaDomicilioFiscalExterior = true;
        } else {
          this.showFichaDomicilioFiscalExterior = false;
        }

        this.alertService.setLoading(false);
        this._markFormPristine(this.dadosFATCAForm);

    });

  }


  public trocarPossuiPEP() {

    this.possuiPEP = !this.possuiPEP;
    this.showFichaPEP = !this.showFichaPEP;
    this.alertService.setLoading(true);

    this.pessoaService
    .getPessoaPEPPromise(this.solicitacaoBeneficio.pessoa.codPessoa+'').then(
        res => {
          this.pessoaPEP = res as PessoaPEPModel;
      }
    )
    .catch(
      err=> {
        console.error('erro ao recarregar pessoaPEP=>'+JSON.stringify(err));
        this.alertService.setLoading(false);
        this.alertService.dispatch('Erro ao atualizar pessoaPEP=>'+err);
      }
    )
    .finally( () => {

        // Se alterado para 'Não' remove os dados de FATCA caso exista.
        if( (!this.possuiPEP) ) {

          if ( this.pessoaPEP && this.pessoaPEP.codPessoaPEP ) {

            this.pessoaService.excluirPessoaPEP (this.pessoaPEP.codPessoaPEP);

            this.dadosPEPForm.setValue({
              possuirCargoPublico: false,
              funcao: '',
              dtaInicio: '',
              dtaFim:  '',
              empresa: '',
              relacaoAgentePubli: false,
              nomeRelacionado: '',
              cpfRelalionado:  '',
              funcaoRelacionado:  '',
              tipoRelacionamento:  '',
            });

          }
        }

        if (this.possuiPEP) {
          this.showFichaPEP = true;
        } else {
          this.showFichaPEP = false;
        }

        this.alertService.setLoading(false);
        this._markFormPristine(this.dadosPEPForm);

    });

  }


  public popularDadosPatrimonio() {

    this.possuiBensAndImoveis = !!(this.solicitacaoBeneficio.pessoa.patrimonios.length>0);
    this.showFichaCadastroPatrimonio = this.possuiBensAndImoveis;

    let valorImoveis: string = '';
    let valorAutomoveis: string = '';
    let valorInvestimentos: string = '';
    let valorOutros : string = '';

    // "codigo": 1,
    // "descricao": "IMOVEIS",
    // "codigo": 2,
    // "descricao": "AUTOMOVEIS",
    // "codigo": 3,
    // "descricao": "INVESTIMENTOS",
    // "codigo": 4,
    // "descricao": "OUTROS",

    this.solicitacaoBeneficio.pessoa.patrimonios.forEach(
      item => {
        if ( item.tipo.descricao==='IMOVEIS' ) {
          valorImoveis = item.vlrEstimado+'';
        } else if(item.tipo.descricao==='AUTOMOVEIS') {
          valorAutomoveis = item.vlrEstimado+'';
        } else if(item.tipo.descricao==='INVESTIMENTOS') {
          valorInvestimentos = item.vlrEstimado+'';
        } else {
          valorOutros = item.vlrEstimado+'';
        }
      }
    )

    this.dadosPatrimonioForm = this.fb.group({
      valorImoveis:valorImoveis,
      valorAutomoveis: valorAutomoveis,
      valorInvestimentos: valorInvestimentos,
      valorOutros: valorOutros,
    });

  }

  // "codigo": 1,
  // "descricao": "IMOVEIS",
  // "codigo": 2,
  // "descricao": "AUTOMOVEIS",
  // "codigo": 3,
  // "descricao": "INVESTIMENTOS",
  // "codigo": 4,
  // "descricao": "OUTROS",
  public obterCodigoTipoPatrimonio(descricao: string) : number {
    let codigo : number = 0;
    switch (descricao) {
      case 'IMOVEIS':
          codigo = 1;
          break;
      case 'AUTOMOVEIS':
          codigo = 2;
          break;
      case 'INVESTIMENTOS':
          codigo = 3;
          break;
      case 'OUTROS':
          codigo = 4;
          break;
      default:
        codigo = 4;
    }
    return codigo;
  }

  public existeTipoPatrimonio(tipo : string, patrimonioList: Array<PessoaPatrimonioModel>) : Boolean {
    let retorno : Boolean = false;
    retorno = !!patrimonioList
              .find ( p => ( p.tipo &&
                             p.tipo.descricao &&
                             p.tipo.descricao === tipo)
              );
    return retorno;
  }

  public obtemPatrimonio(tipo : string, patrimonioList: Array<PessoaPatrimonioModel>) : PessoaPatrimonioModel {
    let patrimonio : PessoaPatrimonioModel = {};
    patrimonio = patrimonioList
                     .find ( p => ( p.tipo &&
                                    p.tipo.descricao &&
                                    p.tipo.descricao === tipo)
                     );
    return patrimonio;
  }

  public obterValorCampoFormPatrimonio(tipo: string) : string {
    let valor : string;

    switch (tipo) {
      case 'IMOVEIS':
          valor = this.dadosPatrimonioForm.get('valorImoveis').value ? this.dadosPatrimonioForm.get('valorImoveis').value : '';
          console.log('IMOVEIS=' + valor);
          break;
      case 'AUTOMOVEIS':
          valor = this.dadosPatrimonioForm.get('valorAutomoveis').value ? this.dadosPatrimonioForm.get('valorAutomoveis').value : '';
          console.log('AUTOMOVEIS='+ valor);
          break;
      case 'INVESTIMENTOS':
          valor = this.dadosPatrimonioForm.get('valorInvestimentos').value ? this.dadosPatrimonioForm.get('valorInvestimentos').value : '';
          console.log('INVESTIMENTOS='+ valor);
          break;
      case 'OUTROS':
          valor = this.dadosPatrimonioForm.get('valorOutros').value ? this.dadosPatrimonioForm.get('valorOutros').value : '';
          console.log('OUTROS='+ valor);
          break;
      default:
          valor = '';
          console.error('tipo de patrimonio invalido=' + tipo);
    }

    return valor;
  }


  public obterValorCampoForm( form: FormGroup, campo: string, valorDefault: any ) : any {
    let retorno : any;
    if( form && form.get(campo) ) {
        retorno = ( form.get(campo).value ? form.get(campo).value : valorDefault );
    }
    return retorno;
  }

  public obterDadosPessoaFATCAForm(fatca: PessoaFATCAModel) : PessoaFATCAModel {
    fatca.estudante = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgEstudante', false );
    fatca.diplomata = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgDiplomata', false );
    fatca.presencaSubstancial = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgPresencaSubstancial', false );
    fatca.abdicouNacionalidade = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgAbdicouNacionalidade', false );
    fatca.renunciou = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgRenunciou', false );
    fatca.possuiGreencard = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgPossuiGreencard', false );
    fatca.certificAbandono = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgCertificAbandono', false );
    fatca.resideNosEua = <boolean>this.obterValorCampoForm( this.dadosFATCAForm, 'flgResideNosEua', false );
    fatca.diasVisitaAnoCorrente = <number>this.obterValorCampoForm( this.dadosFATCAForm, 'diasVisitaAnoCorrente', 0 );
    fatca.diasVisitaAnoPassado = <number>this.obterValorCampoForm( this.dadosFATCAForm, 'diasVisitaAnoPassado', 0 );
    fatca.diasVisitaAnoAnterior = <number>this.obterValorCampoForm( this.dadosFATCAForm, 'diasVisitaAnoAnterior', 0 );
    return fatca;
  }

  public obterDadosPessoaPEPForm(pep: PessoaPEPModel) : PessoaPEPModel {
    pep.funcao = <string>this.obterValorCampoForm( this.dadosPEPForm, 'funcao', '' );
    pep.dtaInicio = <string>this.obterValorCampoForm( this.dadosPEPForm, 'dtaInicio', '' );
    pep.dtaFim = <string>this.obterValorCampoForm( this.dadosPEPForm, 'dtaFim', '' );
    pep.empresa = <string>this.obterValorCampoForm( this.dadosPEPForm, 'empresa', '' );
    pep.relacaoAgentePubli = <boolean>this.obterValorCampoForm( this.dadosPEPForm, 'relacaoAgentePubli', '' );
    return pep;
  }

  public obterNomeCampoFormPatrimonio(tipo: string) : string {
    let valor : string;

    switch (tipo) {
      case 'IMOVEIS':
          valor = 'valorImoveis';
          break;
      case 'AUTOMOVEIS':
          valor = 'valorAutomoveis';
          break;
      case 'INVESTIMENTOS':
          valor = 'valorInvestimentos';
          break;
      case 'OUTROS':
          valor = 'valorOutros';
          break;
      default:
          valor = '';
    }

    return valor;
  }

  public manterPatrimonio( tipo : string, patrimonioList: Array<PessoaPatrimonioModel> ) {
    let pessoaPatrimonio : PessoaPatrimonioModel = {};
    if (this.existeTipoPatrimonio(tipo, patrimonioList)) {
      pessoaPatrimonio = this.obtemPatrimonio(tipo, patrimonioList);
      pessoaPatrimonio.vlrEstimado = + this.obterValorCampoFormPatrimonio(pessoaPatrimonio.tipo.descricao);
      this.pessoaService.atualizarPessoaPatrimonio ( pessoaPatrimonio );
    } else {
      pessoaPatrimonio.ativo = true;
      pessoaPatrimonio.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
      pessoaPatrimonio.vlrEstimado = + this.obterValorCampoFormPatrimonio(tipo);
      let tipoPatrimonio : TipoPatrimonioModel = {};
      tipoPatrimonio.codigo = this.obterCodigoTipoPatrimonio(tipo);
      tipoPatrimonio.descricao = tipo;
      pessoaPatrimonio.tipo = Object.assign(tipoPatrimonio, {});
      this.pessoaService.inserirPessoaPatrimonio( pessoaPatrimonio );
    }
  }

  public manterPessoaFATCA() {
    let pessoaFATCATemp : PessoaFATCAModel = {};
    if (this.pessoaFATCA.codPessoa > 0) {
      pessoaFATCATemp = Object.assign(this.pessoaFATCA, {});
      pessoaFATCATemp = this.obterDadosPessoaFATCAForm(pessoaFATCATemp);
      this.pessoaService.atualizarPessoaFATCA ( pessoaFATCATemp );
    } else {
      pessoaFATCATemp.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
      pessoaFATCATemp = this.obterDadosPessoaFATCAForm(pessoaFATCATemp);
      this.pessoaService.inserirPessoaFATCA ( pessoaFATCATemp );
    }
  }

  public manterPessoaPEP() {
    let pessoaPEPTemp : PessoaPEPModel = {};
    if (this.pessoaPEP.codPessoaPEP > 0) {
      pessoaPEPTemp = Object.assign(this.pessoaPEP, {});
      pessoaPEPTemp = this.obterDadosPessoaPEPForm( pessoaPEPTemp );
      this.pessoaService.atualizarPessoaPEP ( pessoaPEPTemp );
    } else {
      pessoaPEPTemp.codPessoa = this.solicitacaoBeneficio.pessoa.codPessoa;
      pessoaPEPTemp = this.obterDadosPessoaPEPForm( pessoaPEPTemp );
      this.pessoaService.inserirPessoaPEP ( pessoaPEPTemp );
    }
  }

  public atualizarStatusSolicitacaoBeneficio( codigoStatus: number ) {
    let solicitacaoBeneficioStatusRequest : SolicitacaoBeneficioRequestModel = {};
    let solicitacaoBeneficioStatusDataRequest : SolicitacaoBeneficioDataModel = {};
    let status : StatusModel = {};
    let tipo : StatusTipoModel = {};
    status.codigo = codigoStatus;
    status.ativo = true;
    tipo.codigo = 21;
    status.tipo = Object.assign({}, tipo);
    solicitacaoBeneficioStatusDataRequest.status = Object.assign({}, status);
    solicitacaoBeneficioStatusDataRequest.codBeneficio = this.solicitacaoBeneficio.codBeneficio;
    solicitacaoBeneficioStatusDataRequest.codSolicbeneficio = this.solicitacaoBeneficio.codSolicbeneficio;
    solicitacaoBeneficioStatusRequest.data = Object.assign({}, solicitacaoBeneficioStatusDataRequest);
    console.log('atualizarStatusSolicitacaoBeneficio='+JSON.stringify(solicitacaoBeneficioStatusRequest));
    this.beneficioSolicitacaoService.atualizarStatusSolicitacaoBeneficio(solicitacaoBeneficioStatusRequest);
  }

  finalizarSolicitacao() {
    console.log('entrou em finalizarSolicitacao');
    this.alertService.setLoading(true);
    this.beneficioSolicitacaoService.finalizarSolicitacaoBeneficio( this.solicitacaoBeneficio )
      .then( resposta => {
          console.log( 'resposta=' + JSON.stringify( resposta ));
          this.openSnackBar('Cadastro Finalizado', 'X');
        },
        err => {
          this.openSnackBar('Erro ao finalizar cadastro', 'X');
          console.error('erro ao finalizar cadastro=>'+ JSON.stringify(err));
        }
      )
      .finally(() => this.alertService.setLoading(false));
  }


  public executarConfiguracao(codConfiguracao:number, codSolicBeneficioDoc:number, desConfigValor:string):void {
    console.clear();
    console.log("codConfiguracao: " + codConfiguracao + "\ncodSolicBeneficioDoc: " + codSolicBeneficioDoc + "\ndesConfigValor: " + desConfigValor);

    var params:string = codConfiguracao == 4 ? "?codTipoDocumento=" + "55" + "&codSolicBeneficioDoc=" + codSolicBeneficioDoc :
                        codConfiguracao == 5 ? "?codTipoDocumento=" + "55" + "&codSolicBeneficioDoc=" + codSolicBeneficioDoc :
                        codConfiguracao == 1 ? "/" + codSolicBeneficioDoc + "/" + "55" :
                        ""
    ;

    if (params != "") {
        this.beneficioSolicitacaoService.executarConfiguracao(desConfigValor + params).subscribe(
            r => {
                console.log(JSON.stringify(r));
            },
            e => {
                console.log(JSON.stringify(e));
            }
        );
    }
    else {
        if (codConfiguracao == 2) {
            var solBenPag:BeneficioPagamentoModel = this.solicitacaoBeneficioPagamentoList[0];
            var paramsDigitalizacao:string = '{ "CodLoja": "' + solBenPag.loja.codLoja + '", "codigoSistema": "2",  "codigoDocumento": "20",  "codigoFuncao": "7",  "codigoExterno": "34803281807",  "codigoUsuarioUpload": "203419",  "origem": "CPF121249", "nomeArquivo": "RG121249.34803281807.20191211_121249813.PDF", "diretorioDestinoDoc": "\\\\\\\\crefisa.com.br\\\\root\\\\gedchk\\\\", "urlImg" : "http:\\\\centraldenegocios.adobenet.com.br/fotos/", "endPointBanco" : "https://teste.com.br/IncluirDocumento" }';
            var dadosB64:string = window.btoa(paramsDigitalizacao);
            this.dialog.open(DigitalizacaoComponent, {disableClose: true, data: { dadosBase64: dadosB64 }}).afterClosed().subscribe(result => {
                console.log(result);
            });
        }
        else if (codConfiguracao == 41) {
            var solBenPag:BeneficioPagamentoModel = this.solicitacaoBeneficioPagamentoList[0];
            var paramsCapturaFoto:string = '{ "codigoSolicitacao": "' + solBenPag.codSolicbeneficio + '", "codigoDocumento": "11" }';
            this.dialog.open(CapturaImagemComponent, {disableClose: true, data: { dadosBase64: btoa(paramsCapturaFoto) }}).afterClosed().subscribe(result => {
                console.log(result);
            });
        }
        else {
            console.log("codConfiguração não reconhecido");
        }
    }
}

    public exibirBotaoConfiguracao(codConfiguracao: number, solicitacao: SolicitacaoBeneficioDocumentoModel, configuracoesList: any, biometrico: boolean): boolean {
        //console.log(JSON.stringify(configuracoesList));

        var temGerar: boolean = false;
        for (var i = 0; i < configuracoesList.length && !temGerar; i++) temGerar = configuracoesList[i].itemConfiguracao.codigo == 1;

        if (codConfiguracao == 1) { //GERAR
            return true;
        }
        else if (codConfiguracao == 2) { //DIGITALIZAR
            return (!biometrico ? true : solicitacao.caminhoArquivo != null);
        }
        else if (codConfiguracao == 3) { //VISUALIZAR
            return solicitacao.caminhoArquivo != null;
        }
        else if (codConfiguracao == 4) { //ENVIARGRAFOMETRIA
            return (biometrico ? temGerar && solicitacao.digitalizacao == true : solicitacao.digitalizacao == true);
        }
        else if (codConfiguracao == 5) { //RECEBERGRAFOMETRIA
            return (biometrico ? temGerar && solicitacao.enviado == true : solicitacao.enviado == true);
        }
        else if (codConfiguracao == 6) { //OBRIGATÓRIO
            return true;
        }
        else if (codConfiguracao == 41) { //CAPTURAR FOTO
            return true;
        }
    }

    /*  :::
        cpf: 17757432847, nb:1499177893
        a tabela OWR_NFCBCO.TB_INSS_SOLICBENEFICIODOC tem os flags de enviado, recebido, etc
        exceto para gerado, a gente sabe se foi gerado quando o campo 'des_caminhocarquivo' != null
        quando todo processo for finalizado a gente tem que atualizar o campo cod_status da OWR_NFCBCO.TB_INSS_SOLICBENEFICIODOC para 42(entregue, OWR_NFCBCO.TB_INSS_STATUS)
    */

    public manualOuBiometricoOnChange(solicBenefDoc:SolicitacaoBeneficioDocumentoModel):void {
        for(var i:number = 0; i < this.solicitacaoBeneficioDocumentoList.length; i++) {
            if (this.solicitacaoBeneficioDocumentoList[i] == solicBenefDoc) {
                this.solicitacaoBeneficioDocumentoList[i].biometria = !this.solicitacaoBeneficioDocumentoList[i].biometria;
                return;
            }
        }
    }

  /*public atualizarStatusSolicitacaoBeneficio( codigoStatus: number ) {
    let solicitacaoBeneficioStatusRequest : SolicitacaoBeneficioRequestModel = {};
    let solicitacaoBeneficioStatusDataRequest : SolicitacaoBeneficioDataModel = {};
    let status : StatusModel = {};
    let tipo : StatusTipoModel = {};
    status.codigo = codigoStatus;
    status.ativo = true;
    tipo.codigo = 21;
    status.tipo = Object.assign({}, tipo);
    solicitacaoBeneficioStatusDataRequest.status = Object.assign({}, status);
    solicitacaoBeneficioStatusDataRequest.codBeneficio = this.solicitacaoBeneficio.codBeneficio;
    solicitacaoBeneficioStatusDataRequest.codSolicbeneficio = this.solicitacaoBeneficio.codSolicbeneficio;
    solicitacaoBeneficioStatusRequest.data = Object.assign({}, solicitacaoBeneficioStatusDataRequest);
    console.log('atualizarStatusSolicitacaoBeneficio='+JSON.stringify(solicitacaoBeneficioStatusRequest));
    this.beneficioSolicitacaoService.atualizarStatusSolicitacaoBeneficio(solicitacaoBeneficioStatusRequest);
  }*/

  onSubmit() {
    alert('Thanks!');
  }
}
