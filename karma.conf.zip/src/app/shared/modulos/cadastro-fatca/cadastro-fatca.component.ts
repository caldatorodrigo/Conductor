import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'ficha-cadastro-fatca',
  templateUrl: './cadastro-fatca.component.html',
  styleUrls: ['./cadastro-fatca.component.scss']
})
export class CadastroFatcaComponent {
  addressForm = this.fb.group({
    company: null,
    cpfPep: [null, Validators.required],
    firstName: [null, Validators.required],
    lastName: [null, Validators.required],
    address: [null, Validators.required],
    address2: null,
    city: [null, Validators.required],
    state: [null, Validators.required],
    postalCode: [null, Validators.compose([
      Validators.required, Validators.minLength(5), Validators.maxLength(5)])
    ],
    shipping: ['free', Validators.required]
  });

  ufList = [];

  dadosPessoaisParteIForm: FormGroup;
  dadosaPessoaisParte2Form: FormGroup;
  dadosEnderecoForm: FormGroup;
  dadosContatoForm: FormGroup;
  dadosCapturaDoc: FormGroup;
  dadosCapturaCartao: FormGroup;

  hasUnitNumber = false;

  states = [
    {name: 'Alabama', abbreviation: 'AL'},
    {name: 'Alaska', abbreviation: 'AK'},
  ];

  endereco;
  contato;

  constructor(private fb: FormBuilder) {
    this.dadosEnderecoForm = this.fb.group({
      cepResidencial: [null],
      logradouroResidencial: [null],
      numeroLogradouroResidencial: [null],
      complementoLogradouroResidencial: [null],
      bairroResidencial: [null],
      cidadeResidencial: [null],
      ufResidencial: [null],
      tipoResidenciaResidencial: [null]
    });

    this.dadosContatoForm = this.fb.group({
      dddTelefoneFixo: [null],
      telefoneFixo: [null],
      // dddTelefoneCelular: [null],
      // telefoneCelular: [null],
      // telefoneProprio: [null],
      // email: [null],
    });
  }

  onSubmit() {
    alert('Thanks!');
  }
}
