import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material';
import { ModalComponentComponent } from '../modal-component/modal-component.component';
import { ModalReprovaComponent } from '../modal-reprova/modal-reprova.component';

@Component({
  selector: 'app-analise-abertura-conta-corrente',
  templateUrl: './analise-abertura-conta-corrente.component.html',
  styleUrls: ['./analise-abertura-conta-corrente.component.scss']
})
export class AnaliseAberturaContaCorrenteComponent {
  addressForm = this.fb.group({
    company: null,
    inputAnaliseAbertura: null,
    firstName: [null, Validators.required],
    cpf: [null, Validators.required],
    lastName: [null, Validators.required],
    address: [null, Validators.required],
    address2: null,
    city: [null, Validators.required],
    state: [null, Validators.required],
    postalCode: [null, Validators.compose([
      Validators.required, Validators.minLength(5), Validators.maxLength(5)])
    ],
    shipping: ['free', Validators.required]
  });

  animal: string;
  nickname: string;
  apareceDocs: any;

  openDialog(): void {
    const dialogRef = this.dialog.open(ModalComponentComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');

    });
  }

  modalReprova(): void {
    const dialogRef = this.dialog.open(ModalReprovaComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');

    });
  }
  

  hasUnitNumber = false;



  states = [
    {name: 'RG', abbreviation: 'AL'},
    {name: 'CNH', abbreviation: 'AK'},
    {name: 'Cetidão Nas', abbreviation: 'AS'},
  ];

  constructor(private fb: FormBuilder, public dialog: MatDialog,) {}
}
