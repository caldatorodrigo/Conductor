import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AlertService } from '../../services/alert.service';
import { FilasService } from 'src/app/modulos/filas/filas.service';
import { isNullOrUndefined } from 'util';
import { FilaHistoricoAnaliseResponseModel } from 'src/app/model/fila/fila-historico-analise-response.model';
import { MatTableDataSource } from '@angular/material';
import { FilaTipoDTOModel } from 'src/app/model/fila/fila-tipo-dto.model';
import { ExcelService } from '../../services/excel.service';
import { isNgTemplate } from '@angular/compiler';
import { FilaHistoricoAnaliseDetalheModel } from 'src/app/model/fila/fila-historico-analise-detalhe.model';
import { of } from 'rxjs';
import { AlertType } from '../../models/alert.model';
import {sprintf} from "sprintf-js";
import { MomentModule } from 'ngx-moment';
import { formatDate } from '@angular/common';

interface TiposFilaResponse {
  data?: Array<FilaTipoDTOModel>;
  exceptionMessage?: string;
  hostname?: string;
  message?: string;
  status?: boolean;
}

interface ExcelDataSheet {
  dataInicio?: string;
  dataFim?: string;
}

interface HistoricoAnaliseTableFormat {
  tipoFila?: string;
  cpf?: string;
  nome?: string;
  loja?: string;
  analista?: string;
  dataInicioAnalise?: string;
  dataFimAnalise?: string;
  status?: string;
  acoes?: string;
}

@Component({
  selector: 'consulta-historico-analise',
  templateUrl: './consulta-historico.component.html',
  styleUrls: ['./consulta-historico.component.scss']
})
export class ConsultaHistoricoComponent {
  dataSourceAnaliseHistorico;
  fechaAbas;
  filaAnaliseResponse: FilaHistoricoAnaliseResponseModel;
  historicoAnaliseList: Array<FilaHistoricoAnaliseDetalheModel>;
  tiposFilaResponse: TiposFilaResponse;
  tiposFilaList: Array<FilaTipoDTOModel>;
  mappedHistoricoAnaliseList: Array<HistoricoAnaliseTableFormat>;
  exportarHabilitado : boolean = false;
  resultadoEncontrado : boolean = false;

  dadosForm = {
    dataInicio: '',
    dataFim: '',
    numCpf: '',
    tipoFila: ''
  };

  displayedColumns: string[] = [
    'tipoFila',
    'cpf',
    'nome',
    'loja',
    'analista',
    'dtInicioAnalise',
    'dtFimAnalise',
    'status',
    'acoes'
  ];

  consultaHistoricoAnaliseForm = this.fb.group({
    dataInicio: [null],
    dataFim: [null],
    numCpf: [null],
    tipoFila: [null]
  });

  constructor(
    private fb: FormBuilder,
    private filasService: FilasService,
    private alertService: AlertService,
    private excelService: ExcelService
  ) {
    this.filasService.getTiposFila().subscribe(
      resposta => {
        this.tiposFilaResponse = <TiposFilaResponse>resposta;
      },
      err => {
        console.error('erro ao obter tipos de fila=>' + JSON.stringify(err));
      },
      () => {
        this.tiposFilaList = <FilaTipoDTOModel[]>this.tiposFilaResponse.data;
        console.log('this.tiposFilaList=', this.tiposFilaList);
      }
    );
  }

  pesquisar() {
    this.historicoAnaliseList = [];
    this.resultadoEncontrado = false;
    this.exportarHabilitado = false;
    if (!this.validarFiltrosInformadosPesquisa()) {
      this.alertService.dispatch('Informar os termos de pesquisa!', AlertType.WARNING);
      return;
    }
    
    if (this.dataSourceAnaliseHistorico) {
      this.dataSourceAnaliseHistorico = undefined;
    }
    this.obterDadosForm();
    console.log('dadosForm=' + JSON.stringify(this.dadosForm));
    this.getDadosHistoricos();
  }

  getDadosHistoricos() {
    this.alertService.setLoading(true);
    this.filasService
      .getHistoricoFilaAnalise(
        this.dadosForm.dataInicio,
        this.dadosForm.dataFim,
        this.dadosForm.numCpf,
        this.dadosForm.tipoFila
      )
      .then(resposta => {
        console.log('respostaxxx=', resposta);
        this.historicoAnaliseList = resposta as FilaHistoricoAnaliseDetalheModel[];
        console.log('historicoAnaliseListxxx=', this.historicoAnaliseList);
        console.log(
          'historicoAnaliseListxxx=' + JSON.stringify(this.historicoAnaliseList)
        );

        this.mappedHistoricoAnaliseList = [];

        this.historicoAnaliseList.forEach(
          item => {
            const itemFilaAnalise: HistoricoAnaliseTableFormat = {};
            if (item.fila.filasAnalise) {
              item.fila.filasAnalise.forEach(filaAnalise => {

                itemFilaAnalise.tipoFila = 
                  item.fila &&
                  item.fila.tiposFila &&
                  item.fila.tiposFila.desFila
                    ? item.fila.tiposFila.desFila
                    : '';

                itemFilaAnalise.cpf =
                  item.pessoa &&
                  item.pessoa.dadosPessoaFisica &&
                  item.pessoa.dadosPessoaFisica.numCpf
                    ? item.pessoa.dadosPessoaFisica.numCpf
                    : '';

                itemFilaAnalise.nome =
                      item.pessoa &&
                      item.pessoa.nomPessoa
                        ? item.pessoa.nomPessoa
                        : '';

                itemFilaAnalise.loja =
                    item.loja &&
                    item.loja.codLoja
                      ? item.loja.codLoja + ''
                      : '';

                itemFilaAnalise.loja =
                  itemFilaAnalise.loja +
                    (item.loja && item.loja.descLoja ? ('-' + item.loja.descLoja) : '');

                itemFilaAnalise.analista =
                  item.fila &&
                  item.fila.codUsuarioinclusao
                    ? item.fila.codUsuarioinclusao + ''
                    : '';

                itemFilaAnalise.dataInicioAnalise =
                  filaAnalise.dtaIniAnalise
                    ? filaAnalise.dtaIniAnalise
                    : '';

                itemFilaAnalise.dataFimAnalise =
                  filaAnalise.dtaFimAnalise
                    ? filaAnalise.dtaFimAnalise
                    : '';

                itemFilaAnalise.status =
                  item.fila &&
                  item.fila.status &&
                  item.fila.status.descStatus
                    ? item.fila.status.descStatus
                    : '';

                itemFilaAnalise.acoes = 'TODO';
                this.mappedHistoricoAnaliseList.push(itemFilaAnalise);
              });
            }
          }
        );

        if (this.mappedHistoricoAnaliseList && this.mappedHistoricoAnaliseList.length>0) {
          this.exportarHabilitado = true;
          this.resultadoEncontrado = true;
        }
        
      })
      .finally(() => {
        this.dataSourceAnaliseHistorico = new MatTableDataSource(
          this.mappedHistoricoAnaliseList
        );

        console.log(
          'this.mappedHistoricoAnaliseList=' +
            JSON.stringify(this.mappedHistoricoAnaliseList)
        );
        this.alertService.setLoading(false);
      });
  }

  validarFiltrosInformadosPesquisa() {
    if (
          ( 
            this.consultaHistoricoAnaliseForm.get('dataInicio').value && 
            this.consultaHistoricoAnaliseForm.get('dataFim').value  
          ) ||
          ( this.consultaHistoricoAnaliseForm.get('numCpf').value ) ||
          ( this.consultaHistoricoAnaliseForm.get('tipoFila').value )
    ) {
      return true;
    } 
    return false;
  }

  obterDadosForm() {

    if (this.consultaHistoricoAnaliseForm.get('dataInicio').dirty) {
      this.dadosForm.dataInicio = isNullOrUndefined(
        this.consultaHistoricoAnaliseForm.get('dataInicio').value
      )
        ? ''
        : formatDate( this.consultaHistoricoAnaliseForm.get('dataInicio').value, 'yyyy-MM-dd', 'pt-BR' );
    }

    if (this.consultaHistoricoAnaliseForm.get('dataFim').dirty) {
      this.dadosForm.dataFim = isNullOrUndefined(
        this.consultaHistoricoAnaliseForm.get('dataFim').value
      )
        ? ''
        : formatDate( this.consultaHistoricoAnaliseForm.get('dataFim').value, 'yyyy-MM-dd', 'pt-BR' );
    }

    if (this.consultaHistoricoAnaliseForm.get('numCpf').dirty) {
      this.dadosForm.numCpf = isNullOrUndefined(
        this.consultaHistoricoAnaliseForm.get('numCpf').value
      )
        ? ''
        : this.consultaHistoricoAnaliseForm.get('numCpf').value;
    }

    if (this.consultaHistoricoAnaliseForm.get('tipoFila').dirty) {
      this.dadosForm.tipoFila = isNullOrUndefined(
        this.consultaHistoricoAnaliseForm.get('tipoFila').value
      )
        ? ''
        : this.consultaHistoricoAnaliseForm.get('tipoFila').value;
    }
  }

  gerarArquivoExcel() {
    if (isNullOrUndefined(this.mappedHistoricoAnaliseList)) {
      this.obterDadosForm();
      console.log('dadosForm=' + JSON.stringify(this.dadosForm));
      this.getDadosHistoricos();
    }
    this.excelService.exportAsExcelFile(
      this.mappedHistoricoAnaliseList,
      'historico-analise'
    );
    this.exportarHabilitado = false;
  }

  emptyTable(dataSource) {
    return dataSource && dataSource.data && dataSource.data.length == 0;
  }

  convertDate(date: Date) : string {
    let dtFmt: string = '';
    if ( date.toDateString ) {
      dtFmt = sprintf( 
                        '%04d-%02d-%02d',
                        date.getFullYear(), date.getMonth(), date.getDay() 
                      ) ;
      return dtFmt;
    } 
    return dtFmt;
  }
}
