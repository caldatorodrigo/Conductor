import { Component } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'ficha-cadastro-pep',
  templateUrl: './cadastro-pep.component.html',
  styleUrls: ['./cadastro-pep.component.scss']
})
export class CadastroPepComponent {
  addressForm = this.fb.group({
    company: null,
    cpfPep: [null, Validators.required],
    firstName: [null, Validators.required],
    lastName: [null, Validators.required],
    address: [null, Validators.required],
    address2: null,
    city: [null, Validators.required],
    state: [null, Validators.required],
    postalCode: [null, Validators.compose([
      Validators.required, Validators.minLength(5), Validators.maxLength(5)])
    ],
    shipping: ['free', Validators.required]
  });
  contato;
  endereco;
  ufList = [];

  dadosPessoaisParteIForm: FormGroup;
  dadosaPessoaisParte2Form: FormGroup;
  dadosEnderecoForm: FormGroup;
  dadosContatoForm: FormGroup;
  dadosCapturaDoc: FormGroup;
  dadosCapturaCartao: FormGroup;

  hasUnitNumber = false;

  states = [
    {name: 'Alabama', abbreviation: 'AL'},
    {name: 'Alaska', abbreviation: 'AK'},
  ];

  constructor(private fb: FormBuilder) {

    this.dadosEnderecoForm = this.fb.group({
      cepResidencial: [null],
      logradouroResidencial: [null],
      numeroLogradouroResidencial: [null],
      complementoLogradouroResidencial: [null],
      bairroResidencial: [null],
      cidadeResidencial: [null],
      ufResidencial: [null],
      tipoResidenciaResidencial: [null]
    });

    this.dadosContatoForm = this.fb.group({
      dddTelefoneFixo: [null],
      telefoneFixo: [null],
      // dddTelefoneCelular: [null],
      // telefoneCelular: [null],
      // telefoneProprio: [null],
      // email: [null],
    });
  }

  onSubmit() {
    alert('Thanks!');
  }
  
  
  compareUF(item1: any, item2: any): boolean {
    // console.log('item1.uf['+item1.uf+'] item2['+item2+']' );
    return (
      item1.uf === item2
    );
  }
}
