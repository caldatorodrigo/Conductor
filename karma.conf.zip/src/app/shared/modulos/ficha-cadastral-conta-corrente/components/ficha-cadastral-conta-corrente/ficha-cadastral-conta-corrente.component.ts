import { Component, OnInit, Input } from '@angular/core';


@Component({
  selector: 'app-ficha-cadastral-conta-corrente',
  templateUrl: './ficha-cadastral-conta-corrente.component.html',
  styleUrls: ['./ficha-cadastral-conta-corrente.component.scss']
})

export class FichaCadastralContaCorrenteComponent implements OnInit {

  fechaAbas: any;
  show: any;
  apareceFormulario: any;

  ngOnInit() {
  }

  @Input() input: string;

  constructor() { }

}
