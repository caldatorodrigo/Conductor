import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FichaCadastralContaCorrenteComponent } from './components/ficha-cadastral-conta-corrente/ficha-cadastral-conta-corrente.component';


@NgModule({
    declarations: [
        //FichaCadastralContaCorrenteComponent
    ],
    imports: [
        //CommonModule
    ],
    exports: [
        //FichaCadastralContaCorrenteComponent
    ]
})
export class FichaCadastralModule {
 
}