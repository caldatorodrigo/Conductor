import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ModalComponentComponent } from '../modal-component/modal-component.component';
import { MatDialog } from '@angular/material';
import { ModalReprovaComponent } from '../modal-reprova/modal-reprova.component';

@Component({
  selector: 'app-analise-prova-de-vida',
  templateUrl: './analise-prova-de-vida.component.html',
  styleUrls: ['./analise-prova-de-vida.component.scss']
})
export class AnaliseProvaDeVidaComponent {
  addressForm = this.fb.group({
    company: null,
    doc: null,
    firstName: [null, Validators.required],
    lastName: [null, Validators.required],
    address: [null, Validators.required],
    address2: null,
    city: [null, Validators.required],
    state: [null, Validators.required],
    postalCode: [null, Validators.compose([
      Validators.required, Validators.minLength(5), Validators.maxLength(5)])
    ],
    shipping: ['free', Validators.required]
  });

  hasUnitNumber = false;

  documentos = [
    { name: 'RG', abbreviation: 'AL' },
    { name: 'CPF', abbreviation: 'AK' },
  ]

  openDialog(): void {
    const dialogRef = this.dialog.open(ModalComponentComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');

    });
  }

  modalReprova(): void {
    const dialogRef = this.dialog.open(ModalReprovaComponent, {
    });
    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed');

    });
  }

  constructor(private fb: FormBuilder, public dialog: MatDialog,) {}

}
