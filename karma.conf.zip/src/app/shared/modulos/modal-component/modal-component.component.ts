import { Component, Inject } from '@angular/core';
import {
  MAT_DIALOG_DATA,
  MatSelectChange,
  MatDialogRef
} from '@angular/material';
import { compare } from 'src/app/core/utils/util';
import { AlertService } from '../../services/alert.service';

@Component({
  selector: 'app-modal-component',
  templateUrl: './modal-component.component.html',
  styleUrls: ['./modal-component.component.scss']
})
export class ModalComponentComponent {
  enderecos = [];
  disabledForm = true;
  ufList = [];
  cidadeList = [];
  tipoResidenciaList = [];

  ufSelecionadas = [];
  cidadeSelecionadas = [];
  tiposResidenciaSelecionada = [];

  previewImageSrc = 'http://lorempixel.com/g/1920/1920/';
  zoomImageSrc = this.previewImageSrc;

  ctx = {
    item: {}
  };

  dadosPessoais: {
    RG?: any;
    relativos?: any;
  };

  model;

  constructor(
    private alertService: AlertService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private dialogRef: MatDialogRef<ModalComponentComponent>
  ) {
    this.dialogRef.disableClose = false;
    this.ctx.item = data;

    switch (data.tipoDados) {
      case 'enderecos':
        this.model = Object.assign([], data.model);
        this.alertService.setLoading(true);
        const promiseUfCidade = new Promise((resolve, reject) => {
          this.data.dialogMetodos
            .buscarUFs()
            .then(res => {
              this.ufList = res;

              for (let i = 0; i < this.model.length; i++) {
                const end = this.model[i];
                const ufSelecionada = this.ufList.find(
                  uf => uf.uf === end.slgUf
                );
                this.ufSelecionadas.push(ufSelecionada);
                this.procurarCidade(ufSelecionada.uf, i)
                  .then((cidades: any) => {
                    const cidadeSelecionada = cidades.find(
                      cidade => cidade.desCidade === end.desCidade
                    );
                    this.cidadeSelecionadas.push(cidadeSelecionada);
                    resolve();
                  })
                  .catch(err => reject(err));
              }
            })
            .catch(err => reject(err));
        });

        const promiseTipoResidencia = new Promise((resolve, reject) => {
          this.data.dialogMetodos
            .buscarTiposResidencia()
            .then(tipos => {
              for (const end of this.model) {
                const tipoResidenciaSelecionada = tipos.find(
                  tipoReslidencia =>
                    tipoReslidencia.codTiporesidencia ===
                    end.tpoResidencia.codTiporesidencia
                );
                this.tiposResidenciaSelecionada.push(tipoResidenciaSelecionada);
                this.tipoResidenciaList = tipos;
                resolve();
              }
            })
            .catch(err => reject(err));
        });

        Promise.all([promiseUfCidade, promiseTipoResidencia]).then(() =>
          this.alertService.setLoading(false)
        );
        break;

      case 'dadospessoa':
        this.model = Object.assign({}, data.model);
        this.dadosPessoais = {
          RG: this.RG(),
          relativos: this.relativos()
        };
        break;

      default:
        break;
    }
  }

  changeUF(uf: MatSelectChange, index) {
    this.procurarCidade(uf.value.uf, index);
  }

  procurarCidade(uf, index) {
    return new Promise((resolve, reject) => {
      this.data.dialogMetodos.buscarCidadesPorUF(uf).then(res => {
        this.cidadeList = res;
        resolve(this.cidadeList);
      });
    });
  }

  compareSelect = tipo => compare[tipo];

  enableForm() {
    this.disabledForm = !this.disabledForm;
    this.dialogRef.disableClose = !this.disabledForm;

    if (this.disabledForm) {
      this.model = Object.assign({}, this.data.model);
    }
  }

  RG() {
    return this.model.documentos.find(el => el.tpoDocumento.descricao === 'RG');
  }

  relativos() {
    const relativos = {
      relativoMae: {},
      relativoPai: {}
    };
    const findRelativo = cod =>
    this.model.solicitacao.pessoa.relativos.find(
      rel => rel.tpoRelacao.codTiporelacao === cod
    );

    relativos.relativoMae = findRelativo(254);
    relativos.relativoPai = findRelativo(253);

    relativos.relativoMae = relativos.relativoMae
      ? relativos.relativoMae
      : { nomPessoarelativo: '' };
    relativos.relativoPai = relativos.relativoPai
      ? relativos.relativoPai
      : { nomPessoarelativo: '' };

    return relativos;
  }

  salvar() {
    switch (this.data.tipoDados) {
      case 'enderecos':
        this.dialogRef.close({
          tipoDados: this.data.tipoDados,
          model: this.model
        });
        break;
      case 'dadospessoa':
        this.dialogRef.close({
          tipoDados: this.data.tipoDados,
          model: this.model
        });
        break;
      default:
        break;
    }
  }

  googleReadPDF(link) {
    return `https://docs.google.com/viewer?url=${link}&embedded=true`;
  }

  get flex() {
    const flex = {
      dir: 0,
      esq: 0
    };

    const dir = this.data.docs.docDireito.filaComparaTipoDoc.desComparaDocTipo;
    const esq = this.data.docs.docEsquerdo.filaComparaTipoDoc.desComparaDocTipo;

    if (
      (esq === 'DADOS' && dir === 'DADOS') ||
      (esq !== 'DADOS' && dir !== 'DADOS')
    ) {
      flex.dir = 50;
      flex.esq = 50;
    } else if (esq === 'DADOS') {
      flex.esq = 60;
      flex.dir = 40;
    } else {
      flex.esq = 40;
      flex.dir = 60;
    }
    return flex;
  }
}
