import { Component, OnInit, Input } from "@angular/core";
import { MatSnackBar} from "@angular/material";
import { AlertService } from 'src/app/shared/services/alert.service';

@Component({
  selector: "app-ficha-cadastral",
  templateUrl: "./ficha-cadastral.component.html",
  styleUrls: ["./ficha-cadastral.component.scss"]
})
export class FichaCadastralComponent implements OnInit {
  @Input() input: string;
  ngOnInit() {}

  show;
  fechaAbas;
  showPainelBeneficio: Boolean = true;
  showAtivarBeneficio: Boolean = true;
  showFichaCadastroBeneficio: Boolean = true; // painel-beneficio
  showFichaCadastroContaCorrente: Boolean = false; // ativar-beneficio
  showFichaCadastroProcurador: Boolean = false; // prova-vida
  showFichaCadastral: Boolean = true; // ficha cadastral
  showFichaCadastralProcurador: Boolean = false;
  apareceFormulario: Boolean = false; // ficha cadastro
  capturaDoc : Boolean = false; //

  constructor(public snackBar: MatSnackBar, private alertService: AlertService) {
  }

  escondePainelAtualVoltaParaBeneficio() {
    console.log("entrou!!! idPainel=");

    // if (idPainel == "ativar-beneficio") return;
    this.showFichaCadastroProcurador = false;
  }

  mostrarFichasCadastro(idFichaCadastro: string) {
    console.log("entrou mostrarFichasCadastro idPainel=" + idFichaCadastro);

    if (idFichaCadastro == "undefinied") return;

    switch (idFichaCadastro) {
      case "formulario-beneficio":
        this.showFichaCadastroBeneficio = true;
        this.showFichaCadastroContaCorrente = false;
        this.showFichaCadastroProcurador = false;
        break;

      case "formulario-contaCorrente":
        this.showFichaCadastroBeneficio = false;
        this.showFichaCadastroContaCorrente = true;
        this.showFichaCadastroProcurador = false;
        break;

      case "formulario-procurador":
        this.showFichaCadastroBeneficio = false;
        this.showFichaCadastroContaCorrente = false;
        this.showFichaCadastroProcurador = true;
        break;
    }
  }

  habilitarFichaCadastralProcurador() {
    this.showFichaCadastralProcurador = true;

    if (this.showFichaCadastral == true) {
      console.log("ESTA VISIVEL");
      this.apareceFormulario = false;
    }
  }

  habilitaCapturaDocumento(){
    this.capturaDoc = true;
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
      horizontalPosition: "right",
      verticalPosition: "top"
    });
  }

   //FUNCAO PARA TESTAR O NGX-LOADING
   componenteLoading() {
    console.log("clicou");
   this.alertService.setLoading(true);
   setTimeout(() => {
     this.alertService.setLoading(false);
   }, 15000);
 }  
}
