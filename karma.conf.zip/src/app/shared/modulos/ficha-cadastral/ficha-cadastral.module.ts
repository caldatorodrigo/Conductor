import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FichaCadastralComponent } from './components/ficha-cadastral/ficha-cadastral.component';
import { NgxLoadingModule } from 'ngx-loading';
import { SharedModule } from '../../shared.module';

@NgModule({
  declarations: [
    FichaCadastralComponent
  ],
  imports: [
    CommonModule,
    NgxLoadingModule,
    SharedModule,
  ],
  exports:[
    FichaCadastralComponent,
    NgxLoadingModule
  ]
})
export class FichaCadastralModule { 
}
