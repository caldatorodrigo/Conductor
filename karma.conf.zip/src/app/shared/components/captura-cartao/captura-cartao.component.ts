import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-captura-cartao',
  templateUrl: './captura-cartao.component.html',
  styleUrls: ['./captura-cartao.component.scss']
})
export class CapturaCartaoComponent implements OnInit {

  @Input() active = false;
  @Input() disabledAction = false;
  @Input() showTextActive = false;
  @Input() textActive = 'ativo';
  @Input() conta = '';
  @Input() idConta = '';
  @Output() action = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  actionDispatch() {
    this.action.emit();
  }

}
