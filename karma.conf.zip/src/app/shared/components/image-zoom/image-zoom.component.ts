import {
  Component,
  OnInit,
  ElementRef,
  ViewChild,
  Renderer2,
  Input
} from '@angular/core';

interface Coordinates {
  X: number;
  Y: number;
}

@Component({
  selector: 'app-image-zoom',
  templateUrl: './image-zoom.component.html',
  styleUrls: ['./image-zoom.component.scss']
})
export class ImageZoomComponent implements OnInit {
  @ViewChild('squareDiv', { static: false }) squareDiv: ElementRef;
  @ViewChild('imgElement', { static: false }) img: ElementRef;
  @Input() imageSrc = '';
  @Input() widthImage = 500;
  @Input() zoomContainerSize = 500;

  data: {
    offset: Coordinates;
  };

  showZoom = false;

  get squareSize() {
    return this.widthImage / 5;
  }
  backgroundPosition = {
    X: 0,
    Y: 0
  };

  get zoom() {
    return this.zoomContainerSize * 2.3 ;
  }

  constructor(private renderer: Renderer2) {}

  ngOnInit() {}

  mouseOver($event) {}

  mouseEnter() {
    this.showZoom = true;
  }

  mouseOut() {
    this.showZoom = false;
  }

  mouseMove($event) {
    if ($event) {
      const middle = this.squareSize / 2;

      let left = $event.offsetX - middle;
      let top = $event.offsetY - middle;
      const image = $event.target;

      const diffX = image.width - this.squareSize;
      const diffY = image.height - this.squareSize;

      left = left < 0 ? 0 : left + this.squareSize > image.width ? diffX : left;
      top = top < 0 ? 0 : image.height + this.squareSize < top ? diffX : top;

      this.data = {
        offset: {
          X: left,
          Y: top
        }
      };

      const valueX =
        ((this.zoom - this.squareSize) * this.data.offset.X) / this.widthImage;
      const valueY =
        ((this.zoom - this.squareSize) * this.data.offset.Y) / this.widthImage;

      const max = this.zoom - this.widthImage + this.squareSize;


      if ((valueX) <= max - 4) {
        this.backgroundPosition.X = (valueX) * -1;
      }

      if ((valueY + 4) <= max) {
        this.backgroundPosition.Y = (valueY + 4) * -1;
      }
    }
  }

  get imageZoomStyle() {
    return {
      'background-image': `url(${this.imageSrc})`,
      left:
        this.img && this.img.nativeElement
          ? this.img.nativeElement.width + this.img.nativeElement.x + 'px'
          : 0,
      top:
        this.img && this.img.nativeElement
          ? this.img.nativeElement.y + 'px'
          : 0,
      'background-size': `${this.zoom}px ${this.zoom}px`,
      width: this.zoomContainerSize + 'px',
      height: this.zoomContainerSize + 'px',
      'background-position': `${this.backgroundPosition.X}px ${this.backgroundPosition.Y}px`,
      visibility: this.showZoom ? 'visible' : 'hidden'
    };
  }

  get imageStyle() {
    return {
      width: this.widthImage + 'px',
      cursor: this.showZoom ? 'crosshair' : 'default'
    };
  }
}
