import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-panel',
  templateUrl: './panel.component.html',
  styleUrls: ['./panel.component.scss']
})
export class PanelComponent implements OnInit {
  @Input() headerTitle = '';
  @Input() showArrow = false;
  @Input() sub = false;
  @Input() backgroundDisabled = false;
  @Input() hasExtraMargin = false;

  constructor() {}

  ngOnInit() {}
}
