import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotFoundDataTableComponent } from './not-found-data-table.component';

describe('NotFoundDataTableComponent', () => {
  let component: NotFoundDataTableComponent;
  let fixture: ComponentFixture<NotFoundDataTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotFoundDataTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotFoundDataTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
