import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-not-found-data-table',
  templateUrl: './not-found-data-table.component.html',
  styleUrls: ['./not-found-data-table.component.scss']
})
export class NotFoundDataTableComponent implements OnInit {

  @Input() message = 'Nenhum dado a ser exibido!';

  constructor() { }

  ngOnInit() {
  }

}
