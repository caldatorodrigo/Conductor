import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-form-button',
  templateUrl: './form-button.component.html',
  styleUrls: ['./form-button.component.scss']
})
export class FormButtonComponent implements OnInit {

  @Output() action = new  EventEmitter<any>();
  @Input() text = 'Submit';
  @Input() showButton = true;
  @Input() disabledButton = false;
  @Input() showTextExtra = false;
  @Input() textExtra = '';
  @Input() isOutline = false;
  @Input() classExtra = '';

  constructor() { }

  ngOnInit() {
  }

  click() {
    this.action.emit();
  }

  classButton() {
    return this.isOutline ? 'btn-outline' : 'btn-default';
  }

}
