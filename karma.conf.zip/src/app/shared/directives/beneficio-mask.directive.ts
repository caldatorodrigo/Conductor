import { Directive, HostListener } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ValidacaoNumeroBeneficoService } from '../services/validacao-numero-benefico.service';

@Directive({
  selector: '[beneficioMask] [ngModel]',
  providers: [NgModel]
})
export class BeneficioMaskDirective {

  constructor(private model: NgModel, private validacaoNumeroBeneficoService: ValidacaoNumeroBeneficoService) { }

  @HostListener('input', ['$event']) onInput(event) {
    if (event.target.value.length <= 13) {
      this.model.valueAccessor.writeValue(this.validacaoNumeroBeneficoService.convertToNumeroBeneficio(event.target.value));
    }
  }

}
