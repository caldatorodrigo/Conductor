import { Directive } from '@angular/core';
import {
  NG_VALIDATORS,
  Validator,
  ValidatorFn,
  FormControl
} from '@angular/forms';
import { CpfService } from '../services/validacao-cpf.service';

@Directive({
  selector: '[cpfValidator]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: CpfValidatorDirective,
      multi: true
    }
  ]
})
export class CpfValidatorDirective implements Validator {
  validator: ValidatorFn;
  private cpfService = new CpfService();
  constructor() {
    this.validator = this.cpfValidator();
  }
  validate(
    control: import('@angular/forms').AbstractControl
  ): import('@angular/forms').ValidationErrors {
    return this.validator(control);
  }

  cpfValidator(): ValidatorFn {
    return (c: FormControl) => {
      let value: string = c.value as string;

      if (value != null) {
        value = this.cpfService.getDigitos(value);

        if (value.length === 11) {
          if (this.cpfService.cpfIsValid(value)) {
            return null;
          } else {
            return {
              cpfvalidator: {
                valid: false
              }
            };
          }
        }
      }

      return {
        cpfvalidator: {
          valid: false
        }
      };
    };
  }
}
