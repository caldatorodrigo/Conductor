import {
  Directive,
  HostListener,
  ElementRef,
  OnChanges,
  Input,
  SimpleChanges
} from '@angular/core';
import { NgModel } from '@angular/forms';
import { CpfService } from '../services/validacao-cpf.service';
import { Util } from 'src/app/core/utils/util';

@Directive({
  selector: '[cpfMask]'
})
export class CpfMaskDirective {
  util = new Util();
  constructor(private _elementRef: ElementRef, private cpfService: CpfService) {
    if (this._elementRef.nativeElement.value) {
      this._elementRef.nativeElement.value = this.util.convertToCPF(
        this._elementRef.nativeElement.value
      );
    }
  }

  @HostListener('input', ['$event']) onInput(event: any) {
    let modify = '';
    if (this._elementRef.nativeElement.value) {
      modify = this._elementRef.nativeElement.value;
    } else {
      modify = event.target.value;
    }

    modify = this.util.convertToCPF(modify);
    modify =
      modify.length > 14 ? modify.substring(0, modify.length - 1) : modify;
    this._elementRef.nativeElement.value = modify;
  }
}

@Directive({
  selector: '[nbMask]'
})
export class NumBeneficioMaskDirective {
  util = new Util();
  constructor(private _elementRef: ElementRef, private cpfService: CpfService) {
    if (this._elementRef.nativeElement.value) {
      this._elementRef.nativeElement.value = this.util.convertToCPF(
        this._elementRef.nativeElement.value
      );
    }
  }

  @HostListener('input', ['$event']) onInput(event: any) {
    let modify = '';
    if (this._elementRef.nativeElement.value) {
      modify = this._elementRef.nativeElement.value;
    } else {
      modify = event.target.value;
    }

    modify = this.util.convertToCPF(modify);
    modify =
      modify.length > 13 ? modify.substring(0, modify.length - 1) : modify;
    this._elementRef.nativeElement.value = modify;
  }
}

@Directive({
  selector: '[rgMask]'
})
export class RgMaskDirective {
  util = new Util();
  constructor(private _elementRef: ElementRef, private cpfService: CpfService) {
    if (this._elementRef.nativeElement.value) {
      this._elementRef.nativeElement.value = this.util.convertToRG(
        this._elementRef.nativeElement.value
      );
    }
  }

  @HostListener('input', ['$event']) onInput(event: any) {
    let modify = '';
    if (this._elementRef.nativeElement.value) {
      modify = this._elementRef.nativeElement.value;
    } else {
      modify = event.target.value;
    }

    modify = this.util.convertToRG(modify);
    this._elementRef.nativeElement.value = modify;
  }
}

@Directive({
  selector: '[uperCase]'
})
export class UpperCaseDirective {
  util = new Util();
  constructor(private _elementRef: ElementRef, private cpfService: CpfService) {
    if (this._elementRef.nativeElement.value) {
      this._elementRef.nativeElement.value = this._elementRef.nativeElement.value.toUpperCase();
    }
  }

  @HostListener('input', ['$event']) onInput(event: any) {
    let modify = '';
    if (this._elementRef.nativeElement.value) {
      modify = this._elementRef.nativeElement.value;
    } else {
      modify = event.target.value;
    }

    modify = modify.toLocaleUpperCase();
    this._elementRef.nativeElement.value = modify;
  }
}
