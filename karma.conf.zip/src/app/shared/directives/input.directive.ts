import { Directive, HostListener, ElementRef } from '@angular/core';

@Directive({ selector: '[onlyDigits]' })
export class OnlyDigitsDirective {
  constructor(private _elementRef: ElementRef) {}

  @HostListener('input', ['$event'])
  onInput(event: any) {
    let modify = '';
    if (this._elementRef.nativeElement.value) {
      modify = this._elementRef.nativeElement.value;
    } else {
      modify = event.target.value;
    }

    modify = modify.replace(/\D/g, '');
    this._elementRef.nativeElement.value = modify;
  }
}
