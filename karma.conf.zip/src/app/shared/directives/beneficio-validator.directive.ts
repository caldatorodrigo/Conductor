import { Directive } from '@angular/core';
import {
  NG_VALIDATORS,
  Validator,
  ValidatorFn,
  FormControl
} from "@angular/forms";
import { ValidacaoNumeroBeneficoService } from '../services/validacao-numero-benefico.service';

@Directive({
  selector: '[beneficioValidator][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: ValidacaoNumeroBeneficoService,
      multi: true
    }
  ]
})
export class BeneficioValidatorDirective implements Validator {

  validate(
    control: import("@angular/forms").AbstractControl
  ): import("@angular/forms").ValidationErrors {
    return this.validator(control);
  }

  validator: ValidatorFn;
  private beneficioService: ValidacaoNumeroBeneficoService = new ValidacaoNumeroBeneficoService();
  constructor() {
    this.validator = this.beneficioValidator();
  }

  beneficioValidator() : ValidatorFn {
    return (c: FormControl) => {

      let value: string = <string>c.value;

      if (value != null) {

        value = this.beneficioService.getDigitos(value);
        console.log('valuexxx='+value);

        if (value.length == 10) {

          if (this.beneficioService.beneficioIsValid(value)) {
            return null;
          } else {
            return {
              beneficioValidator: {
                valid: false
              }
            };
          }
        } 

      }

      return {
        beneficioValidator: {
          valid: false
        }
        
      };

      
    };
  }

}
