import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CpfValidatorDirective } from './directives/cpf-validator.directive';
import { CpfMaskDirective, RgMaskDirective, NumBeneficioMaskDirective, UpperCaseDirective } from './directives/form-mask.directive';
import { BeneficioMaskDirective } from './directives/beneficio-mask.directive';
import { BeneficioValidatorDirective } from './directives/beneficio-validator.directive';
import { RequiredifDirective } from './directives/requiredif.directive';
import { CadastroComponent } from './modulos/cadastro/cadastro.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { CadastroDocumentosComponent } from './modulos/cadastro-documentos/cadastro-documentos.component';
import { CadastroEnderecoComponent } from './modulos/cadastro-endereco/cadastro-endereco.component';
import { CadastroContatoComponent } from './modulos/cadastro-contato/cadastro-contato.component';
import { CadastroFatcaComponent } from './modulos/cadastro-fatca/cadastro-fatca.component';
import { CadastroPepComponent } from './modulos/cadastro-pep/cadastro-pep.component';
import { DadosEstaticosComponent } from './modulos/dados-estaticos/dados-estaticos.component';
import { ProvaDeVidaComponent } from './modulos/prova-de-vida/prova-de-vida.component';
import { FormaDePagamentoComponent } from './modulos/forma-de-pagamento/forma-de-pagamento.component';
import { CapturaDocumentosComponent } from './modulos/captura-documentos/captura-documentos.component';
import { CapturaCartaoComponent } from './components/captura-cartao/captura-cartao.component';
import { FilaAnaliseAberturaContaComponent } from './modulos/fila-analise-abertura-conta/fila-analise-abertura-conta.component';
import { AntecipacaoRendaComponent } from './modulos/antecipacao-renda/antecipacao-renda.component';
import { RecadastramentoCensoComponent } from './modulos/recadastramento-censo/recadastramento-censo.component';
import { AnaliseAberturaContaBeneficioComponent } from './modulos/analise-abertura-conta-beneficio/analise-abertura-conta-beneficio.component';
import { ModalComponentComponent } from './modulos/modal-component/modal-component.component';
import { ModalReprovaComponent } from './modulos/modal-reprova/modal-reprova.component';
import { ConsultaHistoricoComponent } from './modulos/consulta-historico/consulta-historico.component';
import { AnaliseProvaDeVidaComponent } from './modulos/analise-prova-de-vida/analise-prova-de-vida.component';
import { AnaliseAlteracaoFormaPagamentoComponent } from './modulos/analise-alteracao-forma-pagamento/analise-alteracao-forma-pagamento.component';
import { AnaliseRecadastramentoCensoComponent } from './modulos/analise-recadastramento-censo/analise-recadastramento-censo.component';
import { from } from 'rxjs';
import { CadastroBusService } from './services/cadastro-bus.service';
import { SenhaCartaoComponent } from './modulos/senha-cartao/senha-cartao.component';
import { NovoSolicitacaoContaCorrenteComponent } from './modulos/novo-solicitacao-conta-corrente/novo-solicitacao-conta-corrente.component';
import { FichaCadastralContaCorrenteComponent } from './modulos/ficha-cadastral-conta-corrente/components/ficha-cadastral-conta-corrente/ficha-cadastral-conta-corrente.component';
import { NgxPageScrollModule } from 'ngx-page-scroll';
import { NgxLoadingModule } from 'ngx-loading';
import { FichaCadastralProcuradorComponent } from './modulos/ficha-cadastral-procurador/components/ficha-cadastral-procurador.component';
import { CoreModule } from '../core/core.module';
import { AnaliseAberturaContaCorrenteComponent } from './modulos/analise-abertura-conta-corrente/analise-abertura-conta-corrente.component';
import { AlertComponent } from './components/alert/alert.component';
import { MaterialModule } from './material/material.module';
import { NotFoundDataTableComponent } from './components/not-found-data-table/not-found-data-table.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { ExcelService } from './services/excel.service';
import { PageContainerComponent } from './components/page-container/page-container.component';
import { PanelComponent } from './components/panel/panel.component';
import { ImageZoomComponent } from './components/image-zoom/image-zoom.component';
import { OnlyDigitsDirective } from './directives/input.directive';
import { ProvaDeVidaService } from './modulos/prova-de-vida/services/prova-de-vida.service';
import { FormButtonComponent } from './components/form-button/form-button.component';

@NgModule({
  declarations: [
    CpfValidatorDirective,
    UpperCaseDirective,
    CpfMaskDirective,
    NumBeneficioMaskDirective,
    RgMaskDirective,
    BeneficioValidatorDirective,
    BeneficioMaskDirective,
    RequiredifDirective,
    CadastroComponent,
    CadastroDocumentosComponent,
    CadastroEnderecoComponent,
    CadastroContatoComponent,
    CadastroFatcaComponent,
    CadastroPepComponent,
    DadosEstaticosComponent,
    ProvaDeVidaComponent,
    FormaDePagamentoComponent,
    CapturaDocumentosComponent,
    CapturaCartaoComponent,
    FilaAnaliseAberturaContaComponent,
    AntecipacaoRendaComponent,
    RecadastramentoCensoComponent,
    AnaliseAberturaContaBeneficioComponent,
    ModalComponentComponent,
    ModalReprovaComponent,
    ConsultaHistoricoComponent,
    AnaliseProvaDeVidaComponent,
    AnaliseAlteracaoFormaPagamentoComponent,
    AnaliseRecadastramentoCensoComponent,
    SenhaCartaoComponent,
    NovoSolicitacaoContaCorrenteComponent,
    FichaCadastralContaCorrenteComponent,
    FichaCadastralProcuradorComponent,
    AnaliseAberturaContaCorrenteComponent,
    AlertComponent,
    NotFoundDataTableComponent,
    PageContainerComponent,
    PanelComponent,
    ImageZoomComponent,
    OnlyDigitsDirective,
    FormButtonComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    NgxPageScrollModule,
    NgxLoadingModule,
    MaterialModule,
    FlexLayoutModule,
    CoreModule,
    FormsModule,
  ],
  exports: [
    FormsModule,
    CpfValidatorDirective,
    CpfMaskDirective,
    RgMaskDirective,
    BeneficioValidatorDirective,
    BeneficioMaskDirective,
    RequiredifDirective,
    CadastroComponent,
    CadastroDocumentosComponent,
    CadastroEnderecoComponent,
    CadastroContatoComponent,
    CadastroFatcaComponent,
    CadastroPepComponent,
    DadosEstaticosComponent,
    ProvaDeVidaComponent,
    FormaDePagamentoComponent,
    CapturaDocumentosComponent,
    CapturaCartaoComponent,
    FilaAnaliseAberturaContaComponent,
    AntecipacaoRendaComponent,
    RecadastramentoCensoComponent,
    AnaliseAberturaContaBeneficioComponent,
    ConsultaHistoricoComponent,
    AnaliseProvaDeVidaComponent,
    AnaliseAlteracaoFormaPagamentoComponent,
    AnaliseRecadastramentoCensoComponent,
    SenhaCartaoComponent,
    NovoSolicitacaoContaCorrenteComponent,
    FichaCadastralContaCorrenteComponent,
    FichaCadastralProcuradorComponent,
    NgxLoadingModule,
    AnaliseAberturaContaCorrenteComponent,
    MaterialModule,
    NotFoundDataTableComponent,
    FlexLayoutModule,
    CoreModule,
    PageContainerComponent,
    PanelComponent,
    ImageZoomComponent,
    OnlyDigitsDirective,
    CommonModule,
    FormButtonComponent,
    NumBeneficioMaskDirective,
    ReactiveFormsModule,
    UpperCaseDirective
  ],
  providers: [CadastroBusService, ExcelService, ProvaDeVidaService]
})
export class SharedModule {}
