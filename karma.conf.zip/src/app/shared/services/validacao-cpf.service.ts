import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root"
})

export class CpfService {
  constructor() {}

  getDigitos(value) {
    return value.replace(/\D/g, "");
  }

  cpfIsValid(value): boolean {
    // Só faz a validação se o texto não for vazio.
    // Se for vazio, validar campo requerido não é a responsabilidade desta validação
    if (value.length > 0) {
      let IsValid = false;
      const cpf = this.getDigitos(value); // Obtém o texto digitado no campo, remove tudo menos os digitos
      if (cpf.length === 11) {
        // Se digitou o CPF por completo
        // Verificação dos CPF's que não respeitam a regra de validação mas não são válidos
        const cpf_invalidos = [
          "00000000000",
          "11111111111",
          "22222222222",
          "33333333333",
          "44444444444",
          "55555555555",
          "66666666666",
          "77777777777",
          "88888888888",
          "99999999999"
        ];
        for (let i = 0; i < 10; i++) {
          if (cpf === cpf_invalidos[i]) {
            return IsValid;
          }
        }

        // Calculando o Primeiro Dígito Verificador
        let soma = 0; // Soma para o CPF "ABC.DEF.GHI-XZ": (A*10)+(B*9)+...+(H*3)+(I*2)
        for (let i = 0; i < 9; i++) {
          soma = soma + parseInt(cpf.charAt(i), 10) * (10 - i);
        }
        let dv = 0; // Primeiro dígito verificador (será zero se o resto da divisão de soma por 11 for < 2)
        if (soma % 11 > 1) {
          dv = 11 - (soma % 11);
        }

        if (parseInt(cpf.charAt(9), 10) !== dv) {
          return IsValid;
        }

        // Calculando o Segundo Dígito Verificador
        soma = 0; // Soma para o CPF "ABC.DEF.GHI-XZ": (A*11)+(B*10)+...+(H*4)+(I*3)+(X*2)
        for (let i = 0; i < 10; i++) {
          soma = soma + parseInt(cpf.charAt(i), 10) * (11 - i);
        }
        dv = 0; // Segundo dígito verificador (será zero se o resto da divisão de soma por 11 for < 2)
        if (soma % 11 > 1) {
          dv = 11 - (soma % 11);
        }

        if (parseInt(cpf.charAt(10), 10) !== dv) {
          return IsValid;
        }

        IsValid = true;
      }
      return IsValid;
    }
    return true;
  }
}
