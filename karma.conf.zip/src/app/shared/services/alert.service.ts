import { Injectable } from '@angular/core';
import { MatSnackBar } from '@angular/material';
import { Subject, of, BehaviorSubject } from 'rxjs';
import { AlertTime, ALERT_MIN_TIME, AlertType } from '../models/alert.model';

@Injectable({
  providedIn: 'root'
})
export class AlertService {
  private alert: Subject<any> = new Subject<any>();
  private loading: BehaviorSubject<boolean> = new BehaviorSubject(false);

  constructor(private snackBar: MatSnackBar) {}

  getAlerts = () => {
    return of(alert);
  }

  dispatch = (
    message,
    type = AlertType.DEFAULT,
    time = AlertTime.DEFAULT,
    action?
  ) => {
    const snack = this.snackBar.open(message, action, {
      duration: time * ALERT_MIN_TIME,
      panelClass: type,
      horizontalPosition: 'right',
      verticalPosition: 'top'
    });

    snack.onAction().subscribe(action => {
      console.log(action);
    });
  }

  getLoading = () => this.loading.asObservable();

  setLoading = activate => this.loading.next(activate);
}
