import { Injectable } from "@angular/core";

@Injectable({
  providedIn: "root"
})
export class ValidacaoNumeroBeneficoService {
  
  constructor() {}

  convertToNumeroBeneficio(num) {
    if (num) {
      num = num.toString();
      num = this.getDigitos(num);

      switch (num.length) {
        case 4:
          num = num.replace(/(\d+)(\d{3})/, "$1.$2");
          break;
        case 5:
          num = num.replace(/(\d+)(\d{3})/, "$1.$2");
          break;
        case 6:
          num = num.replace(/(\d+)(\d{3})/, "$1.$2");
          break;
        case 7:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, "$1.$2.$3");
          break;
        case 8:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, "$1.$2.$3");
          break;
        case 9:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, "$1.$2.$3");
          break;
        case 10:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{1})/, "$1.$2.$3-$4");
          break;
        case 11:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
          break;
      }
    }
    return num;
  }

  getDigitos(value) {
    return value.replace(/\D/g, "");
  }

  beneficioIsValid(value): boolean {
    // Só faz a validação se o texto não for vazio.
    // Se for vazio, validar campo requerido não é a responsabilidade desta validação
    if (value.length > 0) {
      let IsValid = false;
      const beneficio = this.getDigitos(value); // Obtém o texto digitado no campo, remove tudo menos os digitos
      if (beneficio.length === 10) {
        // Lista de Pesos
        let pesos: number[] = [2, 9, 8, 7, 6, 5, 4, 3, 2];

        // Calculando o Primeiro Dígito Verificador
        let soma = 0; // Soma para o Beneficio "ABC.DEF.GHI-X": (A*2)+(B*9)+(C*8)+(D*7)+(E*6)+(F*5)+(G*4)+(H*3)+(I*9)
        for (let i = 0; i < 8; i++) {
          soma = soma + parseInt(beneficio.charAt(i), 10) * pesos[i];
        }

        let dv = 0; // Primeiro dígito verificador (será zero se o resto da divisão de soma por 11 for < 2)
        if (soma % 11 > 1) {
          dv = 11 - (soma % 11);
        }

        if (parseInt(beneficio.charAt(9), 10) !== dv) {
          return IsValid;
        }

        IsValid = true;
      }
      return IsValid;
    }
    return true;
  }

}
