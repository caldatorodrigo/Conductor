import { Injectable } from "@angular/core";
import { Subject, BehaviorSubject } from "rxjs";

@Injectable()
export class CadastroBusService {

  public beneficioSubject = new BehaviorSubject<any>('');
  public solicitacaoBeneficioSubject = new Subject<any>();

  constructor() {}

  // BUS de comunicacao para os dados do cadastro
  addBeneficio(data) {
    console.log(
      "entrou em CadastroBusService.addBeneficio data=" + JSON.stringify(data)
    );
    this.beneficioSubject.next(data);
  }

  // BUS de cominicacao para os dados de solicitacao de beneficio
  addSolicitacaoBeneficio(data) {
    console.log(
      "entrou em CadastroBusService.addSolicitacaoBeneficio data=" + JSON.stringify(data)
    );
    this.solicitacaoBeneficioSubject.next(data);
  }

}
