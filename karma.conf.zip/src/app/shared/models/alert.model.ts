export const ALERT_MIN_TIME = 500;

export enum AlertTime {
  VERY_SHORT = 1, //500
  SHORT = 2, //1000
  DEFAULT = 4, //2000
  LONG = 6, //3000
  VERY_LONG = 10 //5000
}

export enum AlertType {
  SUCCESS = 'success' ,
  WARNING = 'warning' ,
  ERROR = 'error' ,
  INFO = 'info' ,
  DEFAULT = 'default',
}
