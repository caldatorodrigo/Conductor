import { throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { AlertService } from '../../shared/services/alert.service';
import { AlertType, AlertTime } from 'src/app/shared/models/alert.model';

export const handlerError = (
  error: HttpErrorResponse,
  alertService: AlertService
) => {
  const errorMessage = error.error
    ? error.error.exceptionMessage || error.error.message
    : error.message;

  switch (error.status) {
    case 0:
      alertService.dispatch(
        'Sever unavailable',
        AlertType.ERROR,
        AlertTime.LONG
      );
      break;
    case 500:
      alertService.dispatch(errorMessage, AlertType.WARNING);
      break;
    case 400:
      if (errorMessage) {
        alertService.dispatch(errorMessage, AlertType.WARNING);
      }
      break;
    default:
      break;
  }
  return throwError(error);
};
