import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatNumeroBeneficio'
})
export class NumeroBeneficioPipe implements PipeTransform {

  transform(value: string, ...args: any[]): any {
    return this.convertToNumeroBeneficio(value);
  }

  convertToNumeroBeneficio(num) {
    if (num) {
      num = num.toString();
      num = this.getDigitos(num);

      switch (num.length) {
        case 4:
          num = num.replace(/(\d+)(\d{3})/, "$1.$2");
          break;
        case 5:
          num = num.replace(/(\d+)(\d{3})/, "$1.$2");
          break;
        case 6:
          num = num.replace(/(\d+)(\d{3})/, "$1.$2");
          break;
        case 7:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, "$1.$2.$3");
          break;
        case 8:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, "$1.$2.$3");
          break;
        case 9:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, "$1.$2.$3");
          break;
        case 10:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{1})/, "$1.$2.$3-$4");
          break;
        case 11:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
          break;
      }
    }
    return num;
  }
  
  getDigitos(value) {
    return value.replace(/\D/g, "");
  }


}
