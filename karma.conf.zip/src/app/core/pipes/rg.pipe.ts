import { Pipe, PipeTransform } from '@angular/core';
import { Util } from '../utils/util';

@Pipe({
  name: 'rgPipe'
})
export class RgPipe implements PipeTransform {
  util = new Util();

  transform(value: any, ...args: any[]): any {
    return this.util.convertToRG(value);
  }
}
