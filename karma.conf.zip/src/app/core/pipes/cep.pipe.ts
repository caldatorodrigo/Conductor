import { Pipe, PipeTransform } from '@angular/core';
import { Util } from '../utils/util';

@Pipe({
  name: 'cepPipe'
})
export class CepPipe implements PipeTransform {
  util = new Util();

  transform(value: any, ...args: any[]): any {
    return this.util.convertToCEP(value);
  }
}
