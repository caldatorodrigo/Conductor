import { Pipe, PipeTransform } from '@angular/core';
import { Util } from '../utils/util';

@Pipe({
  name: 'formatCPF'
})
export class CpfPipe implements PipeTransform {

  util =  new Util();

  transform(value: string, ...args: any[]): any {
    return this.util.convertToCPF(value);
  }

  getDigitos(value) {
    return value.replace(/\D/g, '');
  }
}
