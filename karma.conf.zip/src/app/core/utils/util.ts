import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

export class Util {
  public static groupBy = (xs, key) => {
    return xs.reduce((rv, x) => {
      (rv[x[key]] = rv[x[key]] || []).push(x);
      return rv;
    }, {});
  };

  convertToCpf(num) {
    if (num) {
      num = num.toString();
      num = this.getDigitos(num);
      switch (num.length) {
        case 4:
          num = num.replace(/(\d+)(\d{3})/, '$1.$2');
          break;
        case 5:
          num = num.replace(/(\d+)(\d{3})/, '$1.$2');
          break;
        case 6:
          num = num.replace(/(\d+)(\d{3})/, '$1.$2');
          break;
        case 7:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, '$1.$2.$3');
          break;
        case 8:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, '$1.$2.$3');
          break;
        case 9:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, '$1.$2.$3');
          break;
        case 10:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{1})/, '$1.$2.$3-$4');
          break;
        case 11:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
          break;
      }
    }
    return num;
  }

  convertToNumeroBeneficio(num) {
    if (num) {
      num = num.toString();
      num = this.getDigitos(num);

      switch (num.length) {
        case 4:
          num = num.replace(/(\d+)(\d{3})/, '$1.$2');
          break;
        case 5:
          num = num.replace(/(\d+)(\d{3})/, '$1.$2');
          break;
        case 6:
          num = num.replace(/(\d+)(\d{3})/, '$1.$2');
          break;
        case 7:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, '$1.$2.$3');
          break;
        case 8:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, '$1.$2.$3');
          break;
        case 9:
          num = num.replace(/(\d+)(\d{3})(\d{3})/, '$1.$2.$3');
          break;
        case 10:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{1})/, '$1.$2.$3-$4');
          break;
        case 11:
          num = num.replace(/(\d+)(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
          break;
      }
    }
    return num;
  }

  getDigitos = value => value.replace(/\D/g, '');

  convertToCPF = cpf =>
    !cpf
      ? cpf
      : cpf
          .replace(/\D/g, '')
          .replace(/^(\d{3})(\d)/g, '$1.$2')
          .replace(/^(\d{3}\.\d{3})(\d)/g, '$1.$2')
          .replace(/^(\d{3}\.\d{3}.\d{3})(\d)/g, '$1-$2');

  convertToCEP = cep =>
    !cep
      ? cep
      : cep
          .replace(/\D/g, '')
          .replace(/^(\d{2})(\d)/g, '$1.$2')
          .replace(/^(\d{2}\.\d{3})(\d)/g, '$1-$2');

  convertToRG = rg =>
    !rg
      ? rg
      : rg
          .replace(/\D/g, '')
          .replace(/^(\d{1})(\d)/g, '$1.$2')
          .replace(/^(\d{1}\.\d{3})(\d)/g, '$1-$2');
}

export const compare = {
  uf: (a, b) => (!!a && !!b ? a.uf === b.uf : false),
  cidade: (a, b) => (!!a && !!b ? a.codCidade === b.codCidade : false),
  tipoResidencia: (a, b) =>
    !!a && !!b ? a.codTiporesidencia === b.codTiporesidencia : false,
  tipoEstadoCivil: (a, b) =>
    !!a && !!b ? a.codTipoestadocivil === b.codTipoestadocivil : false,
  tipoProfissao: (a, b) =>
    !!a && !!b ? a.codTipoprofissao === b.codTipoprofissao : false,
  tipoPatrimonio: (a, b) => (!!a && !!b ? a.codigo === b.codigo : false),
  tipoDocumento: (a, b) => (!!a && !!b ? a.codigo === b.codigo : false),
  pacoteTarifa: (a, b) => (!!a && !!b ? a.codPacote === b.codPacote : false)
};

export const util = {
  isEmptyNullOrUndefined: item => !item || item.length === 0 || item === null,
  onlyDigits: (item: string) => item.replace(/\D/g, ''),
  pipeMapArray: (obs: Observable<any>) =>
    obs.pipe(map(res => ( res && res.data ? res.data : []))),
  pipeMapObject: (obs: Observable<any>) =>
    obs.pipe(map(res => ( res && res.data ? res.data : res))),
  promiseMapArray: (obs: Observable<any>) =>
    obs.pipe(map(res => ( res && res.data ? res.data : []))).toPromise(),
  promiseMapObject: (obs: Observable<any>) =>
    obs.pipe(map(res => ( res && res.data ? res.data : res))).toPromise()
};
