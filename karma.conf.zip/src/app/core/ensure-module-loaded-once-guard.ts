export class EnsureModuleLoadedOnceGuard {
}
