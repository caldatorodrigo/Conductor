import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CpfPipe } from './pipes/cpf.pipe';
import { NumeroBeneficioPipe } from './pipes/numero-beneficio.pipe';
import { CepPipe } from './pipes/cep.pipe';
import { RgPipe } from './pipes/rg.pipe';
import { SafePipe } from './pipes/safe.pipe';

@NgModule({
  declarations: [CpfPipe, NumeroBeneficioPipe, CepPipe, SafePipe, RgPipe],
  imports: [CommonModule],
  exports: [CpfPipe, NumeroBeneficioPipe, CepPipe, SafePipe, RgPipe]
})
export class CoreModule {}
