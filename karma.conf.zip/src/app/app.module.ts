import { BrowserModule } from '@angular/platform-browser';
import { NgModule, LOCALE_ID } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReactiveFormsModule } from '@angular/forms';
import { BeneficioInssMainComponent } from './modulos/beneficio/components/beneficio-inss-main/beneficio-inss-main.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { HttpClientModule } from '@angular/common/http';
import {
  MatFormFieldModule,
  MatDialogModule,
  MatInputModule,
  MatButtonModule,
  MatTableModule,
  MatSlideToggleModule
} from '@angular/material';

import { BeneficioService } from './modulos/beneficio/services/beneficio.service';
import { SharedModule } from './shared/shared.module';
import { TratamentoComponent } from './modulos/filas/tratamento/tratamento.component';
import { TreeModule } from 'primeng/components/tree/tree';
import { TreeTableModule } from 'primeng/treetable';
import { TratamentoService } from './modulos/filas/tratamento.service';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { TableModule } from 'primeng/table';
import { PanelModule } from 'primeng/panel';
import { NgxPageScrollModule } from 'ngx-page-scroll';
import { NgxLoadingModule } from 'ngx-loading';
import { FichaCadastralModule } from './shared/modulos/ficha-cadastral/ficha-cadastral.module';
import { FichaCadastralComponent } from './shared/modulos/ficha-cadastral/components/ficha-cadastral/ficha-cadastral.component';
import { AnaliseComponent } from './modulos/filas/components/analise/analise.component';
import { MatTreeModule } from '@angular/material/tree';
import { MatIconModule } from '@angular/material/icon';
import { BeneficioModule } from './modulos/beneficio/beneficio.module';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatCardModule } from '@angular/material/card';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { ModalComponentComponent } from './shared/modulos/modal-component/modal-component.component';
import { ModalReprovaComponent } from './shared/modulos/modal-reprova/modal-reprova.component';
import { CoreModule } from './core/core.module';
import { SenhaCartaoComponent } from './shared/modulos/senha-cartao/senha-cartao.component';
import { PessoaModule } from './modulos/pessoa/pessoa.module';
import { interceptor } from './core/http/http-interceptor';
import { AlertService } from './shared/services/alert.service';
import { CdkTreeModule } from '@angular/cdk/tree';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FilasAnaliseModule } from './modulos/filas/filas-analise.module';
import { MomentModule } from 'ngx-moment';
import { registerLocaleData, DatePipe } from '@angular/common';
import ptBr from '@angular/common/locales/pt';
import { ContaCorrenteModule } from './modulos/conta-corrente/conta-corrente.module';
import { CapturaImagemComponent } from './modulos/captura-imagem/captura-imagem.component';
import { DigitalizacaoComponent } from './modulos/digitalizacao/components/digitalizacao/digitalizacao.component';
import { DigitalizacaoService } from './modulos/digitalizacao/services/digitalizacao.service';
import { CapturaImagemService } from './modulos/captura-imagem/services/captura-imagem.service';
import { WebcamModule } from './shared/modulos/webcam/webcam.module';
import { TreeComponent } from './modulos/testes/tree/tree.component';

registerLocaleData(ptBr);

@NgModule({
  declarations: [
    AppComponent,
    BeneficioInssMainComponent,
    TratamentoComponent,
    //AnaliseComponent,
    TreeComponent,
    DigitalizacaoComponent, 
    CapturaImagemComponent
  ],

  imports: [
    NgbModule,
    FormsModule,
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatFormFieldModule,
    MatDialogModule,
    MatInputModule,
    MatButtonModule,
    MatIconModule,
    HttpClientModule,
    ButtonsModule.forRoot(),
    SharedModule,
    TreeModule,
    TreeTableModule,
    ProgressSpinnerModule,
    TableModule,
    PanelModule,
    NgxPageScrollModule,
    NgxLoadingModule.forRoot({
      backdropBorderRadius: '3px',
      primaryColour: '#fdb913',
      secondaryColour: '#fdb913',
      tertiaryColour: '#fdb913',
      fullScreenBackdrop: true
    }),
    MatTreeModule,
    MatIconModule,
    BeneficioModule,
    MatSelectModule,
    MatRadioModule,
    MatCardModule,
    MatCheckboxModule,
    MatTableModule,
    CoreModule,
    PessoaModule,
    FichaCadastralModule,
    CdkTreeModule,
    MatSlideToggleModule,
    FlexLayoutModule,
    //FilasAnaliseModule,
    MomentModule,
    ContaCorrenteModule,
    WebcamModule
  ],

  entryComponents: [
    ModalComponentComponent,
    ModalReprovaComponent,
    SenhaCartaoComponent, 
    CapturaImagemComponent,
    DigitalizacaoComponent
  ],

  providers: [
    BeneficioService,
    TratamentoService,
    interceptor,
    AlertService,
    { provide: LOCALE_ID, useValue: 'pt-BR' },
    DigitalizacaoService, 
    CapturaImagemService,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
